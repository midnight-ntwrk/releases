export const toHex = (bytes: Uint8Array): string => Buffer.from(bytes).toString('hex');
