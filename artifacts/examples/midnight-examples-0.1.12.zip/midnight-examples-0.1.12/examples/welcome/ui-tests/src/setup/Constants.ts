export class Constants {
  static readonly INITIAL_EXTENSION_URL = 'chrome-extension://bjlhpephaokolembmpdcbobbpkjnoheb/app.html';
}
