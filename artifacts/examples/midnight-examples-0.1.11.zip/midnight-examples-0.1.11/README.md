# Midnight Example Applications

This is a multi-package repo containing example applications that are used to showcase Midnight and its capabilities.

## Details

Details of the contents of this repository can be found in [Midnight documentation](https://midnight-documentation.vercel.app/docs/)

## Requirements

Node.js - LTS/hydrogen

### Yarn authentication

Yarn will require authentication, one can get a token generated with a command:

```
yarn npm login -s midnight-ntwrk --always-auth
```

It will use configuration from [`.yarnrc.yml`](.yarnrc.yml) file to deduct registry
address, and then it will ask for credentials to our nexus, to add proper token in `~/.yarnrc.yml` file

Though, for unclear reasons, the generated configuration doesn't seem to work 
properly, changing the `~/.yarnrc.yml` to look like below should allow yarn to resolve all packages 
without need to entering token in the repository file:

```yml
npmRegistries:
  "https://nexus.midnight.tools/repository/npm-midnight-ntwrk":
    npmAuthToken: <NPM_TOKEN>
```

