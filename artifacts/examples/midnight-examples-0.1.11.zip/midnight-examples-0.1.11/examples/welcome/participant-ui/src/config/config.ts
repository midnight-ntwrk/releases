// eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
export const WELCOME_CONTRACT_ADDRESS = import.meta.env.VITE_CONTRACT_ADDRESS;
