// Compact should produce the expected length of vector inputs. Until then, we manually set the
// length to match the length the contract expects.
export const INITIAL_PARTICIPANTS_VECTOR_LENGTH = 5000;
