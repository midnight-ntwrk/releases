export interface Config {
  readonly organizerUrl: string;
  readonly participantUrl: string;
  readonly contractAddress: string;
  readonly publicKey: string;
  readonly nodeAddress: string;
  readonly indexerAddress: string;
  readonly proofServerAddress: string;
  readonly addedParticipant: string;
}

export class DevnetConfig implements Config {
  organizerUrl = 'https://devnet.dli01q5p71azl.amplifyapp.com';
  participantUrl = 'https://devnet.dpsp1qkpmb2uj.amplifyapp.com';

  contractAddress = '01000103894bd77b4ed0df8eb2df8ddec4eeb323fc92c61f281d5c7dd169868a75272f';
  publicKey = 'afbc3a626d53b0dbe4b28e293e2ae049713ccdc9b31cb060a91c23f956ec261d';

  nodeAddress = 'https://rpc.devnet.midnight.network';
  indexerAddress = 'https://indexer.devnet.midnight.network/api/v1/graphql';
  proofServerAddress = 'http://localhost:6300';

  addedParticipant = 'devnetParticipant';
}

export class AriadneQaConfig implements Config {
  organizerUrl = 'https://ariadneqa.d324b33wfeejma.amplifyapp.com';
  participantUrl = 'https://ariadneqa.d29q9bgedkr7t1.amplifyapp.com';

  contractAddress = '010001903724725a7d0634097ec219619796002e88046fdb7a9a59685c3a0289513d41';
  publicKey = 'afbc3a626d53b0dbe4b28e293e2ae049713ccdc9b31cb060a91c23f956ec261d';

  nodeAddress = 'http://node-01.topaz.dev.platform.midnight.network:9944';
  indexerAddress = 'https://pubsub.topaz.dev.platform.midnight.network/api/v1/graphql';
  proofServerAddress = 'http://localhost:6300';

  addedParticipant = 'ariadneQaParticipant';
}

export function getConfig(): Config {
  let config: Config;
  let env = '';
  if (process.env.TEST_ENV !== undefined) {
    env = process.env.TEST_ENV;
  } else {
    throw new Error('TEST_ENV environment variable is not defined.');
  }
  switch (env) {
    case 'devnet':
      config = new DevnetConfig();
      break;
    case 'ariadne-qa':
      config = new AriadneQaConfig();
      break;
    default:
      throw new Error(`Unknown env value=${env}`);
  }
  return config;
}
