export interface Wallet {
  name: string;
  password: string;
  mnemonics: string[];
  address: string;
}
