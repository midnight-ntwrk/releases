import { parseArgs, type TestConfig, LocalTestConfig } from './commons';
import path from 'path';
import { currentDir } from '../config';
import { createLogger } from '../logger-utils';
import { DockerComposeEnvironment, type StartedDockerComposeEnvironment, Wait } from 'testcontainers';
import * as api from '../api';
import * as Rx from 'rxjs';
import { nativeToken } from '@midnight-ntwrk/ledger';
import { type Wallet } from '@midnight-ntwrk/wallet-api';
import { type Resource } from '@midnight-ntwrk/wallet';
import { type CounterProviders } from '../common-types';

const logDir = path.resolve(currentDir, '..', 'logs', 'tests', `${new Date().toISOString()}.log`);
const logger = await createLogger(logDir);

let env: StartedDockerComposeEnvironment;
let dockerEnv: DockerComposeEnvironment;

let testConfig: TestConfig;
let wallet: Wallet & Resource;
let providers: CounterProviders;

describe('API', () => {
  beforeAll(async () => {
    api.setLogger(logger);
    if (process.env.RUN_ENV_TESTS !== undefined) {
      testConfig = parseArgs(['seed', 'env']);
      testConfig.dappConfig?.setNetworkId();
      logger.info(`Test wallet seed: ${testConfig.seed}`);
      logger.info('Proof server starting...');
      dockerEnv = new DockerComposeEnvironment(path.resolve(currentDir, '..'), 'proof-server.yml').withWaitStrategy(
        'proof-server',
        Wait.forLogMessage('Actix runtime found; starting in Actix runtime', 1),
      );
    } else {
      testConfig = new LocalTestConfig();
      testConfig.dappConfig?.setNetworkId();
      logger.info('Test containers starting...');
      dockerEnv = new DockerComposeEnvironment(path.resolve(currentDir, '..'), 'standalone.yml')
        .withWaitStrategy('proof-server', Wait.forLogMessage('Actix runtime found; starting in Actix runtime', 1))
        .withWaitStrategy('indexer', Wait.forLogMessage(/http4s v[\d.]+ on blaze v[\d.]+ started at /, 1));
    }
    env = await dockerEnv.up();
    logger.info('Test containers started');
    logger.info('Setting up wallet');
    wallet = await api.buildWalletAndWaitForFunds(testConfig.dappConfig, testConfig.seed);
    expect(wallet).not.toBeNull();
    const state = await Rx.firstValueFrom(wallet.state());
    expect(state.balances[nativeToken()].valueOf()).toBeGreaterThan(BigInt(0));
    providers = await api.configureProviders(wallet, testConfig.dappConfig);
  }, 5 * 60_000);

  afterAll(async () => {
    if (wallet !== undefined) {
      await wallet.close();
    }
    if (env !== undefined) {
      logger.info('Test containers closing');
      await env.down();
    }
  });

  it('should deploy the contract and increment the counter [@slow]', async () => {
    const counterContract = await api.deploy(providers);
    expect(counterContract).not.toBeNull();

    const counter = await api.displayCounterValue(providers, counterContract);
    expect(counter.counterValue).toEqual(BigInt(0));

    const response = await api.increment(counterContract);
    expect(response.txHash).toMatch(/[0-9a-f]{64}/);
    expect(response.blockHeight).toBeGreaterThan(BigInt(0));

    const counterAfter = await api.displayCounterValue(providers, counterContract);
    expect(counterAfter.counterValue).toEqual(BigInt(1));
    expect(counterAfter.contractAddress).toEqual(counter.contractAddress);
  });
});
