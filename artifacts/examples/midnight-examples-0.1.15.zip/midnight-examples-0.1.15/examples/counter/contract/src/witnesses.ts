// This is how we type an empty object.
export type CounterPrivateState = Record<string, never>;

export const witnesses = {};
