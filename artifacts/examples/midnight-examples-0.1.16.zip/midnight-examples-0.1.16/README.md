# Midnight Example Applications

This is a multi-package repo containing example applications that are used to showcase Midnight and its capabilities.

## Details

Details of the contents of this repository can be found in [Midnight documentation](https://docs.midnight.network/)

## Requirements

Node.js - LTS/hydrogen
