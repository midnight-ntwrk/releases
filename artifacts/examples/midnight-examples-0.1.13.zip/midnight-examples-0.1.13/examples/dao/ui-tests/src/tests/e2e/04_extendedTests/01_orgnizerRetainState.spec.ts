/* eslint-disable @typescript-eslint/strict-boolean-expressions */
/* eslint-disable  @typescript-eslint/no-floating-promises */
import { allure } from 'allure-playwright';
import test, { expect } from '@playwright/test';
import { LaceSetupPage } from 'lace/LaceSetupPage';
import { LaceMainPage } from 'lace/LaceMainPage';
import { NewContractPage } from 'dao/NewContractPage';
import { CommonPage } from 'dao/CommonPage';
import { MainPage } from 'dao/MainPage';
import { NewProposalPage } from 'dao/NewProposalPage';
import { ProposalPage } from 'dao/ProposalPage';
import { DaoDappConstants } from 'setup/DaoDappConstants';
import { ConnectorPage } from 'lace/ConnectorPage';
import { Services } from 'setup/Services';
import { testWalletOne } from 'setup/walletConfiguration';
import { getConfig } from 'setup/envConfig';
import bootstrap from 'setup/BootstrapExtension';
import { pino } from 'pino';

const logger = pino({
  transport: {
    target: 'pino-pretty',
  },
});

test.describe('DAO dApp. Extended Tests.', () => {
  test('01. Organizer is able to retain a state after closing a session @PM-8006', async ({ page }) => {
    allure.tms('PM-8006', `${Services.JIRA_URL}/PM-8006`);
    allure.epic('DAO dApp');
    allure.feature('UI');
    allure.story('User story: DAO dApp e2e flow');

    test.setTimeout(300000);
    let contractAddress: string;

    const DAO_URL = getConfig().daoUi;
    const NODE_ADDRESS = getConfig().nodeAddress;
    const PUBSUB_ADDRESS = getConfig().indexerAddress;
    const PROOF_SERVER_ADDRESS = getConfig().proofServerAddress;

    const TIMEOUT = 240000;
    const PROPOSAL_TITLE = 'Test PM-8006';
    // Organizer is a BENEFICIARY
    const BENEFICIARY_ADDRESS = testWalletOne.address;
    const POT_SIZE_1 = '1.00tDUST';

    // **************** ORGANIZER ****************
    const orgContext = await bootstrap(DaoDappConstants.INITIAL_EXTENSION_URL);
    const orgPage = orgContext.extPage;
    const orgBrowserContext = orgContext.context;

    const orgConnectorPage = new ConnectorPage(orgPage);
    const laceSetupPageOrg = new LaceSetupPage(orgPage);
    const laceMainPageOrg = new LaceMainPage(orgPage);
    const mainPageOrg = new MainPage(orgPage);
    const newContractPageOrg = new NewContractPage(orgPage);
    const commonPageOrg = new CommonPage(orgPage);
    const newProposalPageOrg = new NewProposalPage(orgPage);
    const proposalPageOrg = new ProposalPage(orgPage);

    await laceSetupPageOrg.restoreWallet(testWalletOne, NODE_ADDRESS, PUBSUB_ADDRESS, PROOF_SERVER_ADDRESS);
    await laceMainPageOrg.waitForSync();

    await test.step('1. Organizer. Open DAO page.', async () => {
      logger.info('1. Organizer. Open DAO page.');

      await orgPage.goto(DAO_URL);
      await orgConnectorPage.connectorAuthorizeAlways(orgBrowserContext);
    });

    await test.step('2. Organizer. Deploy New Contract and Join it.', async () => {
      logger.info('2. Organizer. Deploy New Contract and Join it.');

      await mainPageOrg.deployNewContractButton.click();
      await newContractPageOrg.deployNewContract();
      await orgConnectorPage.connectorSignTx(orgBrowserContext, TIMEOUT);

      await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });
      contractAddress = (await newContractPageOrg.contractAddressInput.getAttribute('value')) as string;

      await newContractPageOrg.joinContract();
      await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });
    });

    await test.step('3. Organizer. Publish New Proposal.', async () => {
      logger.info('3. Organizer. Publish New Proposal.');

      await newProposalPageOrg.createProposalButton.click();
      await orgPage.waitForTimeout(2000);
      await newProposalPageOrg.publishNewProposal(PROPOSAL_TITLE, BENEFICIARY_ADDRESS);
      await orgConnectorPage.connectorSignTx(orgBrowserContext, TIMEOUT);
      await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });

      logger.info('Verify data on the *New Proposal* page');
      expect(await proposalPageOrg.proposalTitle.textContent()).toBe(PROPOSAL_TITLE);
      expect(await proposalPageOrg.currentPhase.textContent()).toBe(DaoDappConstants.PHASE_COMMIT);
      expect(BENEFICIARY_ADDRESS).toContain(await proposalPageOrg.beneficiaryAddress.textContent());

      expect(await proposalPageOrg.commitsValue.textContent()).toBe('0');
      expect(await proposalPageOrg.revealValue.textContent()).toBe('0');
      expect(await proposalPageOrg.potSizeValue.textContent()).toBe(POT_SIZE_1);

      await expect(proposalPageOrg.progressToRevealButton).toBeVisible();
    });

    await test.step('4. Organizer. Open initial DAO page and join created contract.', async () => {
      logger.info('4. Organizer. Open initial DAO page and join created contract.');

      await orgPage.goto(DAO_URL);
      await mainPageOrg.joinProposal(contractAddress);

      logger.info('Verify data on the *New Proposal* page');
      await expect(proposalPageOrg.progressToRevealButton).toBeVisible({ timeout: TIMEOUT });
      expect(await proposalPageOrg.proposalTitle.textContent()).toBe(PROPOSAL_TITLE);
      expect(await proposalPageOrg.currentPhase.textContent()).toBe(DaoDappConstants.PHASE_COMMIT);
      expect(BENEFICIARY_ADDRESS).toContain(await proposalPageOrg.beneficiaryAddress.textContent());

      expect(await proposalPageOrg.commitsValue.textContent()).toBe('0');
      expect(await proposalPageOrg.revealValue.textContent()).toBe('0');
      expect(await proposalPageOrg.potSizeValue.textContent()).toBe(POT_SIZE_1);

      logger.info('Organizer`s State was retained');
    });
  });
});
