import type { Locator, Page } from '@playwright/test';
import { expect } from '@playwright/test';

export class LaceMainPage {
  readonly page: Page;
  readonly menuButton: Locator;
  readonly settingMenuItem: Locator;
  readonly walletStatus: Locator;
  readonly receiveButton: Locator;
  readonly currentAddress: Locator;

  constructor(page: Page) {
    this.page = page;
    this.menuButton = page.getByTestId('header-menu-button');
    this.settingMenuItem = page.getByTestId('header-menu-settings');
    this.walletStatus = page.locator('[data-testid="header-menu"] [data-testid="header-wallet-status"]');
    this.receiveButton = page.getByTestId('receive-button');
    this.currentAddress = page.getByTestId('address-card-address');
  }

  async openSettings(): Promise<void> {
    await this.menuButton.click();
    await this.settingMenuItem.click();
    expect(this.page.url().endsWith('/settings')).toBe(true);
  }

  async waitForSync(): Promise<void> {
    await this.menuButton.click();
    await expect(this.walletStatus).toHaveText('Synced', {
      timeout: 300000,
    });
  }

  async getCurrentWalletAddress(): Promise<string> {
    await this.receiveButton.click();
    await this.page.waitForTimeout(1000);
    return (await this.currentAddress.textContent()) as string;
  }
}
