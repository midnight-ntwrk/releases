import type { Locator, Page } from '@playwright/test';

export class LaceSettingsPage {
  readonly page: Page;
  readonly nodeSection: Locator;
  readonly nodeAddressInput: Locator;
  readonly saveNodeAddressButton: Locator;
  readonly proofServerSection: Locator;
  readonly proofServerAddressInput: Locator;
  readonly saveProofServerAddressButton: Locator;
  readonly pubSubSection: Locator;
  readonly pubSubAddressInput: Locator;
  readonly savePubSubAddressButton: Locator;

  constructor(page: Page) {
    this.page = page;
    // Node
    this.nodeSection = page.getByTestId('settings-wallet-midnight-address');
    this.nodeAddressInput = page.getByTestId('midnight-node-service-address-input');
    this.saveNodeAddressButton = page.getByTestId('save-midnight-node-service-address-button');
    // Proof Server
    this.proofServerSection = page.getByTestId('settings-wallet-midnight-proving-server-address');
    this.proofServerAddressInput = page.getByTestId('midnight-proving-service-address-input');
    this.saveProofServerAddressButton = page.getByTestId('[save-midnight-proving-service-address-button');
    // PubSub
    this.pubSubSection = page.getByTestId('settings-wallet-midnight-pubsub-address');
    this.pubSubAddressInput = page.getByTestId('midnight-pubsub-service-address-input');
    this.savePubSubAddressButton = page.getByTestId('save-midnight-pubsub-service-address-button');
  }

  async setNodeAddress(nodeAddress: string): Promise<void> {
    await this.nodeSection.click();
    await this.nodeAddressInput.fill(nodeAddress);
    await this.saveNodeAddressButton.click();
    await this.page.waitForTimeout(1000);
  }

  async setProofServerAddress(proofServerAddress: string): Promise<void> {
    await this.proofServerSection.click();
    await this.proofServerAddressInput.fill(proofServerAddress);
    await this.saveProofServerAddressButton.click();
    await this.page.waitForTimeout(1000);
  }

  async setPubSubAddress(pubfSubAddress: string): Promise<void> {
    await this.pubSubSection.click();
    await this.pubSubAddressInput.fill(pubfSubAddress);
    await this.savePubSubAddressButton.click();
    await this.page.waitForTimeout(1000);
  }
}
