/* eslint-disable @typescript-eslint/strict-boolean-expressions */
/* eslint-disable  @typescript-eslint/no-floating-promises */
import { allure } from 'allure-playwright';
import test, { expect } from '@playwright/test';
import { LaceSetupPage } from 'lace/LaceSetupPage';
import { LaceMainPage } from 'lace/LaceMainPage';
import { CommonPage } from 'dao/CommonPage';
import { MainPage } from 'dao/MainPage';
import { NewContractPage } from 'dao/NewContractPage';
import { NewProposalPage } from 'dao/NewProposalPage';
import { ProposalPage } from 'dao/ProposalPage';
import { DaoDappConstants } from 'setup/DaoDappConstants';
import { ConnectorPage } from 'lace/ConnectorPage';
import { Services } from 'setup/Services';
import { testWalletOne } from 'setup/walletConfiguration';
import bootstrap from 'setup/BootstrapExtension';
import { runProofServer } from 'setup/dockerSetup';
import { getConfig } from 'setup/envConfig';
import { pino } from 'pino';

const logger = pino({
  transport: {
    target: 'pino-pretty',
  },
});

test.describe('DAO dApp. Basic UI checks.', () => {
  test.beforeAll(async () => {
    if (process.env.CI) {
      await runProofServer();
    }
  });

  test('Basic UI checks @PM-7944', async ({ page }) => {
    allure.tms('PM-7944', `${Services.JIRA_URL}/PM-7944`);
    allure.epic('DAO dApp');
    allure.feature('UI');
    allure.story('User story: DAO dApp Smoke Test');

    test.setTimeout(600000);

    const DAO_URL = getConfig().daoUi;
    const NODE_ADDRESS = getConfig().nodeAddress;
    const PUBSUB_ADDRESS = getConfig().indexerAddress;
    const PROOF_SERVER_ADDRESS = getConfig().proofServerAddress;

    const PROPOSAL_TITLE = 'Test Title';
    const POT_SIZE = '1.00tDUST';
    const TIMEOUT = 180000;

    let contractAddress;

    // Restore Wallet
    const context1 = await bootstrap(DaoDappConstants.INITIAL_EXTENSION_URL);
    const page1 = context1.extPage;
    const browserContext = context1.context;

    const connectorPage1 = new ConnectorPage(page1);
    const laceSetupPage1 = new LaceSetupPage(page1);
    const laceMainPage1 = new LaceMainPage(page1);
    const commonPage = new CommonPage(page1);
    const mainPage = new MainPage(page1);
    const newContractPage = new NewContractPage(page1);
    const newProposalPage = new NewProposalPage(page1);
    const proposalPage = new ProposalPage(page1);

    await laceSetupPage1.restoreWallet(testWalletOne, NODE_ADDRESS, PUBSUB_ADDRESS, PROOF_SERVER_ADDRESS);
    await laceMainPage1.waitForSync();
    const BENEFICIARY_ADDRESS = await laceMainPage1.getCurrentWalletAddress();

    await page1.goto(DAO_URL);
    await connectorPage1.connectorAuthorizeAlways(browserContext);

    await test.step('1. Verify elements on the *Main* page', async () => {
      logger.info('Verify elements on the *Main* page');

      await page.waitForTimeout(3000);
      await expect(mainPage.contractAddressInput).toBeVisible();
      await expect(mainPage.contractAddressLabel).toHaveText(DaoDappConstants.CONTRACT_ADDRESS_LABEL);

      await expect(mainPage.joinButton).toBeDisabled();
      await expect(mainPage.deployNewContractButton).toBeEnabled();
    });

    await test.step('2. Verify elements on the *New Contract* page', async () => {
      logger.info('Verify elements on the *New Contract* page');

      await mainPage.deployNewContractButton.click();

      await expect(newContractPage.contractAddressInput).toBeVisible();
      await expect(newContractPage.contractAddressLabel).toHaveText(DaoDappConstants.CONTRACT_ADDRESS_LABEL);

      await expect(newContractPage.joinButton).toBeDisabled();
      await expect(newContractPage.deployNewContractButton).toBeEnabled();

      await expect(newContractPage.amountToFundInput).toBeVisible();
      expect(await newContractPage.amountToFundInput.getAttribute('value')).toBe('1');

      await expect(newContractPage.amountToBuyInput).toBeVisible();
      expect(await newContractPage.amountToBuyInput.getAttribute('value')).toBe('1');

      await expect(newContractPage.xButton).toBeVisible();
    });

    await test.step('3. Deploy Contract. Verify elements on the *New Contract* page', async () => {
      logger.info('Deploy Contract. Verify elements on the *New Contract* page');

      await newContractPage.deployNewContractButton.click();
      await commonPage.dialogYesButton.click();
      await connectorPage1.connectorSignTx(browserContext, TIMEOUT);

      await page1.bringToFront();
      await expect(commonPage.spinner).not.toBeVisible({ timeout: TIMEOUT });

      contractAddress = await newContractPage.contractAddressInput.getAttribute('value');

      await expect(newContractPage.joinButton).toBeEnabled();
      await expect(newContractPage.deployNewContractButton).toBeDisabled();

      expect(await newContractPage.amountToFundInput.getAttribute('value')).toBe('1');
      expect(await newContractPage.amountToBuyInput.getAttribute('value')).toBe('1');

      expect(await newContractPage.deployedContractAddressText.textContent()).toContain(contractAddress);
    });

    await test.step('4. Verify elements on the *New Proposal* page', async () => {
      logger.info('Verify elements on the *New Proposal* page');

      await newContractPage.joinContract();
      await expect(commonPage.spinner).not.toBeVisible({ timeout: TIMEOUT });

      await newProposalPage.createProposalButton.click();
      await page1.waitForTimeout(2000);

      expect(await newProposalPage.newProposalTitle.textContent()).toBe('New Proposal');
      await expect(newProposalPage.titleInput).toBeVisible();
      await expect(newProposalPage.beneficiaryAddressInput).toBeVisible();
      expect(await newProposalPage.seedFundingTitle.textContent()).toBe('Seed Funding Cost:');
      expect(await newProposalPage.seedFundingValue.textContent()).toBe(POT_SIZE);
      await expect(newProposalPage.cancelButton).toBeEnabled();
      await expect(newProposalPage.publishButton).toBeEnabled();
    });

    await test.step('5. Publish proposal with empty inputs', async () => {
      logger.info('Publish proposal with empty inputs');

      await newProposalPage.publishButton.click();
      expect(newProposalPage.page.url().endsWith('/proposal/create')).toBe(true);
    });

    await test.step('6. Publish proposal with Title only', async () => {
      logger.info('Publish proposal with Title only');

      await newProposalPage.titleInput.fill(PROPOSAL_TITLE);

      await newProposalPage.publishButton.click();
      expect(newProposalPage.page.url().endsWith('/proposal/create')).toBe(true);
    });

    await test.step('7. Publish proposal with Title and Address', async () => {
      logger.info('Publish proposal with Title and Address');

      await newProposalPage.beneficiaryAddressInput.fill(BENEFICIARY_ADDRESS);
      await page.waitForTimeout(1000);

      await newProposalPage.publishButton.click();
      await commonPage.dialogYesButton.click();
      await connectorPage1.connectorSignTx(browserContext, TIMEOUT);

      await page1.bringToFront();
      await expect(commonPage.spinner).not.toBeVisible({ timeout: TIMEOUT });
      await page1.waitForTimeout(5000);

      expect(proposalPage.page.url().endsWith('/proposal')).toBe(true);
    });

    await test.step('8. Verify elements on the *Proposal* page', async () => {
      logger.info('Verify elements on the *Proposal* page');

      expect(await proposalPage.proposalTitle.textContent()).toBe(PROPOSAL_TITLE);
      expect(await proposalPage.currentPhase.textContent()).toBe(DaoDappConstants.PHASE_COMMIT);
      /**
       * On the Proposal page only the coins part of address is displayed.
       * Reason:
       * It is a certain limitation of the way contracts interact with tokens.
       * Only the coins part of address is being collected and displayed.
       * It does not make much sense for contracts to know about the encryption keys.
       * Also people should withdraw their tokens from contracts in principle.
       */
      expect(BENEFICIARY_ADDRESS).toContain(await proposalPage.beneficiaryAddress.textContent());
      await expect(proposalPage.progressToRevealButton).toBeEnabled();

      await expect(proposalPage.statsTable).toBeVisible();
      expect(await proposalPage.commitsValue.textContent()).toBe('0');
      expect(await proposalPage.revealValue.textContent()).toBe('0');
      expect(await proposalPage.potSizeValue.textContent()).toBe(POT_SIZE);
    });
  });
});
