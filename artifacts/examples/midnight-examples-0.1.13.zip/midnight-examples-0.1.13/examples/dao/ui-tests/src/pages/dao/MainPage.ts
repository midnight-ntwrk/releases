import type { Locator, Page } from '@playwright/test';

export class MainPage {
  readonly page: Page;
  readonly dialogYesButton: Locator;
  readonly contractAddressInput: Locator;
  readonly contractAddressLabel: Locator;
  readonly joinButton: Locator;
  readonly deployNewContractButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.dialogYesButton = page.getByTestId('alert-dialog-accept-button');
    this.contractAddressInput = page.locator('#initialize-address-input');
    this.contractAddressLabel = page.locator('#initialize-address-input-label');
    this.joinButton = page.locator('.MuiBox-root button:nth-child(1)');
    this.deployNewContractButton = page.locator('.MuiBox-root button:nth-child(2)');
  }

  async joinProposal(contracAddress: string): Promise<void> {
    await this.contractAddressInput.fill(contracAddress);
    await this.joinButton.click();
    await this.dialogYesButton.click();
  }
}
