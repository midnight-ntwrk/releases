import type { Locator, Page } from '@playwright/test';

export class NewContractPage {
  readonly page: Page;
  readonly dialogYesButton: Locator;
  readonly contractAddressInput: Locator;
  readonly contractAddressLabel: Locator;
  readonly joinButton: Locator;
  readonly xButton: Locator;
  readonly amountToFundInput: Locator;
  readonly amountToFundFrame: Locator;
  readonly amountToFundErrorText: Locator;
  readonly amountToBuyInput: Locator;
  readonly amountToBuyFrame: Locator;
  readonly amountToBuyErrorText: Locator;
  readonly deployNewContractButton: Locator;
  readonly deployedContractAddressText: Locator;

  constructor(page: Page) {
    this.page = page;
    this.dialogYesButton = page.getByTestId('alert-dialog-accept-button');
    this.contractAddressInput = page.locator('#initialize-address-input');
    this.contractAddressLabel = page.locator('#initialize-address-input-label');
    this.joinButton = page.locator('.MuiBox-root > button');
    this.xButton = page.locator('.MuiBox-root form div:nth-child(1) button');
    this.amountToFundInput = page.locator('[data-testid="initialize-seed-tdust-input"] input');
    this.amountToFundFrame = page.locator('[data-testid="initialize-seed-tdust-input"] fieldset');
    this.amountToFundErrorText = page.locator('[data-testid="initialize-seed-tdust-input"] p');
    this.amountToBuyInput = page.locator('[data-testid="initialize-buy-in-tdust-input"] input');
    this.amountToBuyFrame = page.locator('[data-testid="initialize-buy-in-tdust-input"] fieldset');
    this.amountToBuyErrorText = page.locator('[data-testid="initialize-buy-in-tdust-input"] p');
    this.deployNewContractButton = page.locator('.MuiBox-root form div:nth-child(3) button');
    this.deployedContractAddressText = page.locator('.MuiTypography-body1');
  }

  async joinContract(): Promise<void> {
    await this.joinButton.click();
    await this.dialogYesButton.click();
  }

  async deployNewContract(): Promise<void> {
    await this.deployNewContractButton.click();
    await this.dialogYesButton.click();
  }
}
