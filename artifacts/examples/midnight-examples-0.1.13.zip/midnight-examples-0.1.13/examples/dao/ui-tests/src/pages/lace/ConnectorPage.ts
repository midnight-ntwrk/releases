/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-floating-promises */
import type { Locator, Page } from '@playwright/test';
import { expect } from '@playwright/test';

export class ConnectorPage {
  readonly page: Page;
  readonly connector: Locator;
  readonly authorizeButton: Locator;
  readonly alwaysButton: Locator;
  readonly signTxButton: Locator;
  readonly denyButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.connector = page.locator('#lace-popup');
    this.authorizeButton = page.getByTestId('connect-authorize-button');
    this.alwaysButton = page.getByTestId('connect-modal-accept-always');
    this.signTxButton = page.getByTestId('allow-dapp');
    this.denyButton = page.getByTestId('deny-dapp');
  }

  async connectorAuthorizeAlways(context: any): Promise<void> {
    const promise = await context.waitForEvent('page');
    const connectorPage = new ConnectorPage(promise);
    await connectorPage.authorizeButton.click();
    await connectorPage.alwaysButton.click();
  }

  async connectorSignTx(context: any, time: any): Promise<void> {
    const promise = await context.waitForEvent('page');
    const connectorPage = new ConnectorPage(promise);
    expect(connectorPage.signTxButton).toBeVisible({ timeout: time });
    await connectorPage.signTxButton.click();
  }
}
