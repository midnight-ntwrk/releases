/* eslint-disable @typescript-eslint/strict-boolean-expressions */
/* eslint-disable  @typescript-eslint/no-floating-promises */
import { allure } from 'allure-playwright';
import test, { expect } from '@playwright/test';
import { LaceSetupPage } from 'lace/LaceSetupPage';
import { LaceMainPage } from 'lace/LaceMainPage';
import { NewContractPage } from 'dao/NewContractPage';
import { CommonPage } from 'dao/CommonPage';
import { MainPage } from 'dao/MainPage';
import { NewProposalPage } from 'dao/NewProposalPage';
import { ProposalPage } from 'dao/ProposalPage';
import { DaoDappConstants } from 'setup/DaoDappConstants';
import { ConnectorPage } from 'lace/ConnectorPage';
import { BuyInPage } from 'dao/BuyInPage';
import { Services } from 'setup/Services';
import { testWalletOne, testWalletTwo } from 'setup/walletConfiguration';
import { getConfig } from 'setup/envConfig';
import bootstrap from 'setup/BootstrapExtension';
import { pino } from 'pino';

const logger = pino({
  transport: {
    target: 'pino-pretty',
  },
});

test.describe('DAO dApp. Extended Tests.', () => {
  test('04. Voter joins before Proposal creation @PM-8009', async ({ page }) => {
    allure.tms('PM-8009', `${Services.JIRA_URL}/PM-8009`);
    allure.epic('DAO dApp');
    allure.feature('UI');
    allure.story('User story: DAO dApp e2e flow');

    test.setTimeout(300000);
    let contractAddress: string;

    const DAO_URL = getConfig().daoUi;
    const NODE_ADDRESS = getConfig().nodeAddress;
    const PUBSUB_ADDRESS = getConfig().indexerAddress;
    const PROOF_SERVER_ADDRESS = getConfig().proofServerAddress;

    const TIMEOUT = 240000;
    const PROPOSAL_TITLE = 'Test PM-8009';
    // Organizer is a BENEFICIARY
    const BENEFICIARY_ADDRESS = testWalletOne.address;
    const POT_SIZE_1 = '1.00tDUST';

    // **************** ORGANIZER ****************
    const orgContext = await bootstrap(DaoDappConstants.INITIAL_EXTENSION_URL);
    const orgPage = orgContext.extPage;
    const orgBrowserContext = orgContext.context;

    const orgConnectorPage = new ConnectorPage(orgPage);
    const laceSetupPageOrg = new LaceSetupPage(orgPage);
    const laceMainPageOrg = new LaceMainPage(orgPage);
    const mainPageOrg = new MainPage(orgPage);
    const newContractPageOrg = new NewContractPage(orgPage);
    const commonPageOrg = new CommonPage(orgPage);
    const newProposalPageOrg = new NewProposalPage(orgPage);
    const proposalPageOrg = new ProposalPage(orgPage);

    logger.info('ORGANIZER');
    await laceSetupPageOrg.restoreWallet(testWalletOne, NODE_ADDRESS, PUBSUB_ADDRESS, PROOF_SERVER_ADDRESS);
    await laceMainPageOrg.waitForSync();

    await test.step('1. Organizer. Open DAO page.', async () => {
      logger.info('1. Organizer. Open DAO page.');

      await orgPage.goto(DAO_URL);
      await orgConnectorPage.connectorAuthorizeAlways(orgBrowserContext);
    });

    await test.step('2. Organizer. Deploy New Contract and Join it.', async () => {
      logger.info('2. Organizer. Deploy New Contract and Join it.');

      await mainPageOrg.deployNewContractButton.click();
      await newContractPageOrg.deployNewContract();
      await orgConnectorPage.connectorSignTx(orgBrowserContext, TIMEOUT);

      await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });
      contractAddress = (await newContractPageOrg.contractAddressInput.getAttribute('value')) as string;

      await newContractPageOrg.joinContract();
      await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });
    });

    // **************** VOTER ****************
    const voterContext = await bootstrap(DaoDappConstants.INITIAL_EXTENSION_URL);
    const voterPage = voterContext.extPage;
    const voterBrowserContext = voterContext.context;

    const voterConnectorPage = new ConnectorPage(orgPage);
    const laceSetupPageVoter = new LaceSetupPage(voterPage);
    const laceMainPageVoter = new LaceMainPage(voterPage);
    const mainPageVoter = new MainPage(voterPage);
    const commonPageVoter = new CommonPage(voterPage);
    const buyInPageVoter = new BuyInPage(voterPage);
    const proposalPageVoter = new ProposalPage(voterPage);

    logger.info('VOTER');
    await laceSetupPageVoter.restoreWallet(testWalletTwo, NODE_ADDRESS, PUBSUB_ADDRESS, PROOF_SERVER_ADDRESS);
    await laceMainPageVoter.waitForSync();

    await test.step('3. Voter. Join existing Contract.', async () => {
      logger.info('3. Voter. Join existing Contract.');

      await voterPage.bringToFront();
      await voterPage.goto(DAO_URL);
      await voterConnectorPage.connectorAuthorizeAlways(voterBrowserContext);

      await mainPageVoter.joinProposal(contractAddress);
      await expect(commonPageVoter.spinner).not.toBeVisible({ timeout: TIMEOUT });

      logger.info('No Proposal page is displayed');
      await expect(commonPageVoter.noProposalSpinner).toBeVisible();
      expect(await commonPageVoter.noProposalText.textContent()).toBe(DaoDappConstants.NO_PROPOSAL_TITLE);
    });

    await test.step('4. Organizer. Create and Publish New Proposal.', async () => {
      logger.info('4. Organizer. Create and Publish New Proposal.');

      await orgPage.bringToFront();

      await newProposalPageOrg.createProposalButton.click();
      await orgPage.waitForTimeout(2000);

      await newProposalPageOrg.publishNewProposal(PROPOSAL_TITLE, BENEFICIARY_ADDRESS);
      await orgConnectorPage.connectorSignTx(orgBrowserContext, TIMEOUT);
      await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });

      logger.info('Verify elements on the *New Proposal* page');
      expect(await proposalPageOrg.currentPhase.textContent()).toBe(DaoDappConstants.PHASE_COMMIT);
      expect(await proposalPageOrg.commitsValue.textContent()).toBe('0');
      expect(await proposalPageOrg.revealValue.textContent()).toBe('0');
      expect(await proposalPageOrg.potSizeValue.textContent()).toBe(POT_SIZE_1);
      await expect(proposalPageOrg.progressToRevealButton).toBeVisible();
    });

    await test.step('5. Voter. Verify Proposal page is displayed.', async () => {
      logger.info('5. Voter. Verify Proposal page is displayed.');

      await voterPage.bringToFront();

      expect(await proposalPageVoter.proposalTitle.textContent()).toBe(PROPOSAL_TITLE);
      expect(await proposalPageVoter.currentPhase.textContent()).toBe(DaoDappConstants.PHASE_COMMIT);
      expect(BENEFICIARY_ADDRESS).toContain(await proposalPageVoter.beneficiaryAddress.textContent());
      await expect(buyInPageVoter.buyInButton).toBeVisible();
      await expect(buyInPageVoter.commitVoteButton).toBeVisible();

      logger.info('Proposal page is displayed for Voter');
    });
  });
});
