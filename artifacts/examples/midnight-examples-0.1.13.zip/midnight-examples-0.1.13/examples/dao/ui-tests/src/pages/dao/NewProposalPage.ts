import { expect } from '@playwright/test';
import type { Locator, Page } from '@playwright/test';

export class NewProposalPage {
  readonly page: Page;
  readonly dialogYesButton: Locator;
  readonly createProposalButton: Locator;
  readonly newProposalTitle: Locator;
  readonly titleInput: Locator;
  readonly beneficiaryAddressInput: Locator;
  readonly seedFundingTitle: Locator;
  readonly seedFundingValue: Locator;
  readonly cancelButton: Locator;
  readonly publishButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.dialogYesButton = page.getByTestId('alert-dialog-accept-button');
    this.createProposalButton = page.getByTestId('noproposal-create-button');
    this.newProposalTitle = page.locator('h5');
    this.titleInput = page.locator('#topic');
    this.beneficiaryAddressInput = page.locator('#beneficiary');
    this.seedFundingTitle = page.locator('[data-testid="createproposal-funding-field"] p:nth-child(1)');
    this.seedFundingValue = page.locator('[data-testid="createproposal-funding-field"] p:nth-child(2)');
    this.cancelButton = page.getByTestId('createproposal-cancel-button');
    this.publishButton = page.getByTestId('createproposal-publish-button');
  }

  async cancelProposal(): Promise<void> {
    await this.cancelButton.click();
    expect(this.page.url().endsWith('/proposal')).toBe(true);
  }

  async publishNewProposal(title: string, address: string): Promise<void> {
    await this.titleInput.fill(title);
    await this.beneficiaryAddressInput.fill(address);
    await this.publishButton.click();
    await this.dialogYesButton.click();
  }
}
