export interface Config {
  readonly daoUi: string;
  readonly nodeAddress: string;
  readonly indexerAddress: string;
  readonly proofServerAddress: string;
}

export class DevnetConfig implements Config {
  daoUi = 'https://devnet.d2qqe76h7s7ysc.amplifyapp.com/';
  nodeAddress = 'https://rpc.devnet.midnight.network';
  indexerAddress = 'https://indexer.devnet.midnight.network/api/v1/graphql';
  proofServerAddress = 'http://localhost:6300';
}

export class AriadneQaConfig implements Config {
  daoUi = 'https://devnet.d2qqe76h7s7ysc.amplifyapp.com/';
  nodeAddress = 'https://rpc.ariadne-qa.dev.midnight.network';
  indexerAddress = 'https://indexer.ariadne-qa.dev.midnight.network/api/v1/graphql';
  proofServerAddress = 'http://localhost:6300';
}

export class LocalConfig implements Config {
  daoUi = 'http://localhost:8080';
  nodeAddress = 'http://localhost:9944';
  indexerAddress = 'http://localhost:8088/api/v1/graphql';
  proofServerAddress = 'http://localhost:6300';
}

export function getConfig(): Config {
  let config: Config;
  let env = '';
  if (process.env.TEST_ENV !== undefined) {
    env = process.env.TEST_ENV;
  } else {
    throw new Error('TEST_ENV environment variable is not defined.');
  }
  switch (env) {
    case 'devnet':
      config = new DevnetConfig();
      break;
    case 'ariadne-qa':
      config = new AriadneQaConfig();
      break;
    case 'undeployed':
      config = new LocalConfig();
      break;
    default:
      throw new Error(`Unknown env value=${env}`);
  }
  return config;
}
