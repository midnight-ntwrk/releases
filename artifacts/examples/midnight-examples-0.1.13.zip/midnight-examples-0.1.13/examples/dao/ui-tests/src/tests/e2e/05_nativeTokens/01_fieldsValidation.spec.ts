/* eslint-disable @typescript-eslint/strict-boolean-expressions */
/* eslint-disable  @typescript-eslint/no-floating-promises */
import { allure } from 'allure-playwright';
import test, { expect } from '@playwright/test';
import { LaceSetupPage } from 'lace/LaceSetupPage';
import { LaceMainPage } from 'lace/LaceMainPage';
import { NewContractPage } from 'dao/NewContractPage';
import { CommonPage } from 'dao/CommonPage';
import { MainPage } from 'dao/MainPage';
import { NewProposalPage } from 'dao/NewProposalPage';
import { ProposalPage } from 'dao/ProposalPage';
import { DaoDappConstants } from 'setup/DaoDappConstants';
import { ConnectorPage } from 'lace/ConnectorPage';
import { BuyInPage } from 'dao/BuyInPage';
import { Services } from 'setup/Services';
import { testWalletOne, testWalletTwo } from 'setup/walletConfiguration';
import { getConfig } from 'setup/envConfig';
import bootstrap from 'setup/BootstrapExtension';
import { pino } from 'pino';

const logger = pino({
  transport: {
    target: 'pino-pretty',
  },
});

test.describe('DAO dApp. Native Tokens.', () => {
  test('01. Fields Validation @PM-8637', async ({ page }) => {
    allure.tms('PM-8637', `${Services.JIRA_URL}/PM-8637`);
    allure.epic('DAO dApp');
    allure.feature('UI');
    allure.story('User story: DAO dApp e2e flow');

    test.setTimeout(300000);
    let contractAddress: string;

    const DAO_URL = getConfig().daoUi;
    const NODE_ADDRESS = getConfig().nodeAddress;
    const PUBSUB_ADDRESS = getConfig().indexerAddress;
    const PROOF_SERVER_ADDRESS = getConfig().proofServerAddress;

    const TIMEOUT = 240000;
    const PROPOSAL_TITLE = 'Test PM-8637';
    // Organizer is a BENEFICIARY
    const BENEFICIARY_ADDRESS = testWalletOne.address;

    // **************** ORGANIZER ****************
    const orgContext = await bootstrap(DaoDappConstants.INITIAL_EXTENSION_URL);
    const orgPage = orgContext.extPage;
    const orgBrowserContext = orgContext.context;

    const orgConnectorPage = new ConnectorPage(orgPage);
    const laceSetupPageOrg = new LaceSetupPage(orgPage);
    const laceMainPageOrg = new LaceMainPage(orgPage);
    const mainPageOrg = new MainPage(orgPage);
    const newContractPageOrg = new NewContractPage(orgPage);
    const commonPageOrg = new CommonPage(orgPage);
    const newProposalPageOrg = new NewProposalPage(orgPage);
    const proposalPageOrg = new ProposalPage(orgPage);

    logger.info('ORGANIZER');
    await laceSetupPageOrg.restoreWallet(testWalletOne, NODE_ADDRESS, PUBSUB_ADDRESS, PROOF_SERVER_ADDRESS);
    await laceMainPageOrg.waitForSync();

    await test.step('1. Organizer. Open DAO page.', async () => {
      logger.info('1. Organizer. Open DAO page.');

      await orgPage.goto(DAO_URL);
      await orgConnectorPage.connectorAuthorizeAlways(orgBrowserContext);
    });

    await test.step('2. Organizer. Deploy New Contract.', async () => {
      logger.info('2. Organizer. Deploy New Contract.');

      await mainPageOrg.deployNewContractButton.click();

      logger.info('*Contract Address* input is displayed and empty');
      await expect(newContractPageOrg.contractAddressInput).toBeVisible();
      expect(await newContractPageOrg.contractAddressInput.getAttribute('value')).toBe('');

      logger.info('*Amount of tDUST needed to fund a proposal* input is displayed and has default value *1*');
      await expect(newContractPageOrg.amountToFundInput).toBeVisible();
      expect(await newContractPageOrg.amountToFundInput.getAttribute('value')).toBe('1');

      logger.info('*Amount of tDUST needed to buy voting token* input is displayed and has default value *1*');
      await expect(newContractPageOrg.amountToBuyInput).toBeVisible();
      expect(await newContractPageOrg.amountToBuyInput.getAttribute('value')).toBe('1');

      logger.info('*Join* button is disabled');
      await expect(newContractPageOrg.joinButton).toBeVisible();
      await expect(newContractPageOrg.joinButton).toBeDisabled();

      logger.info('*Deploy new contract* button is enabled');
      await expect(newContractPageOrg.deployNewContractButton).toBeVisible();
      await expect(newContractPageOrg.deployNewContractButton).toBeEnabled();
    });

    await test.step('3. Organizer. Clear both inputs.', async () => {
      logger.info('3. Organizer. Clear both inputs.');

      await newContractPageOrg.amountToFundInput.clear();
      await newContractPageOrg.amountToBuyInput.clear();

      logger.info('*Join* button is disabled');
      await expect(newContractPageOrg.joinButton).toBeDisabled();

      logger.info('*Deploy new contract* button is disabled');
      await expect(newContractPageOrg.deployNewContractButton).toBeDisabled();

      logger.info('*Amount* inputs are highlighted');
      await expect(newContractPageOrg.amountToFundFrame).toHaveCSS('border-color', DaoDappConstants.RED_COLOUR);
      await expect(newContractPageOrg.amountToFundFrame).toHaveCSS('border-color', DaoDappConstants.RED_COLOUR);

      logger.info('*Amount* inputs have error text');
      expect(await newContractPageOrg.amountToFundErrorText.textContent()).toBe(DaoDappConstants.ERROR_TEXT_1);
      expect(await newContractPageOrg.amountToBuyErrorText.textContent()).toBe(DaoDappConstants.ERROR_TEXT_1);
    });

    await test.step('4. Organizer. Enter not expected values.', async () => {
      logger.info('4. Organizer. Enter not expected values.');

      const INVALID_DATA = [
        { string: 'abc', type: 'Letters' },
        { string: '!@#$%^&*()_+', type: 'Special symbols' },
        { string: '-1', type: 'Negative values' },
      ];

      for (const value of INVALID_DATA) {
        logger.info(`Type in ${value.type}`);

        await newContractPageOrg.amountToFundInput.fill(value.string);
        await newContractPageOrg.amountToBuyInput.fill(value.string);

        logger.info('Buttons are disabled');
        await expect(newContractPageOrg.joinButton).toBeDisabled();
        await expect(newContractPageOrg.deployNewContractButton).toBeDisabled();

        logger.info('Error text is displayed');
        await expect(newContractPageOrg.amountToFundFrame).toHaveCSS('border-color', DaoDappConstants.RED_COLOUR);
        await expect(newContractPageOrg.amountToFundFrame).toHaveCSS('border-color', DaoDappConstants.RED_COLOUR);
        expect(await newContractPageOrg.amountToFundErrorText.textContent()).toBe(DaoDappConstants.ERROR_TEXT_1);
        expect(await newContractPageOrg.amountToBuyErrorText.textContent()).toBe(DaoDappConstants.ERROR_TEXT_1);

        await newContractPageOrg.amountToFundInput.clear();
        await newContractPageOrg.amountToBuyInput.clear();
      }
    });

    await test.step('5. Organizer. Enter not expected and expected values.', async () => {
      logger.info('5. Organizer. Enter not expected and expected values.');

      await newContractPageOrg.amountToFundInput.fill('1');
      await newContractPageOrg.amountToBuyInput.fill('def');

      logger.info('Buttons are disabled');
      await expect(newContractPageOrg.joinButton).toBeDisabled();
      await expect(newContractPageOrg.deployNewContractButton).toBeDisabled();

      logger.info('Error text is displayed only for the 2nd input');
      await expect(newContractPageOrg.amountToFundErrorText).not.toBeVisible();
      expect(await newContractPageOrg.amountToBuyErrorText.textContent()).toBe(DaoDappConstants.ERROR_TEXT_1);
    });

    await test.step('6. Organizer. Enter expected values in both inputs.', async () => {
      logger.info('6. Organizer. Enter expected values in both inputs.');

      await newContractPageOrg.amountToFundInput.clear();
      await newContractPageOrg.amountToBuyInput.clear();

      await newContractPageOrg.amountToFundInput.fill('1');
      await newContractPageOrg.amountToBuyInput.fill('1');

      logger.info('Error text is not displayed');
      await expect(newContractPageOrg.amountToFundErrorText).not.toBeVisible();
      await expect(newContractPageOrg.amountToBuyErrorText).not.toBeVisible();

      logger.info('*Join* button is disabled');
      await expect(newContractPageOrg.joinButton).toBeDisabled();

      logger.info('*Deploy new contract* button is enabled');
      await expect(newContractPageOrg.deployNewContractButton).toBeEnabled();
    });

    await test.step('7. Organizer. Deploy new contract.', async () => {
      logger.info('7. Organizer. Deploy new contract.');

      await newContractPageOrg.deployNewContract();
      await orgConnectorPage.connectorSignTx(orgBrowserContext, TIMEOUT);

      await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });
      contractAddress = (await newContractPageOrg.contractAddressInput.getAttribute('value')) as string;

      logger.info('*Join* button is enabled');
      await expect(newContractPageOrg.joinButton).toBeEnabled();

      logger.info('*Deploy new contract* button is disabled');
      await expect(newContractPageOrg.deployNewContractButton).toBeDisabled();
    });

    await test.step('8. Organizer. Publish New Proposal.', async () => {
      logger.info('8. Organizer. Publish New Proposal.');

      await newContractPageOrg.joinContract();
      await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });

      await newProposalPageOrg.createProposalButton.click();
      await orgPage.waitForTimeout(2000);

      await newProposalPageOrg.publishNewProposal(PROPOSAL_TITLE, BENEFICIARY_ADDRESS);
      await orgConnectorPage.connectorSignTx(orgBrowserContext, TIMEOUT);

      await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });
      expect(await proposalPageOrg.currentPhase.textContent()).toBe(DaoDappConstants.PHASE_COMMIT);
    });

    // **************** VOTER ****************
    const voterContext = await bootstrap(DaoDappConstants.INITIAL_EXTENSION_URL);
    const voterPage = voterContext.extPage;
    const voterBrowserContext = voterContext.context;

    const voterConnectorPage = new ConnectorPage(orgPage);
    const laceSetupPageVoter = new LaceSetupPage(voterPage);
    const laceMainPageVoter = new LaceMainPage(voterPage);
    const mainPageVoter = new MainPage(voterPage);
    const commonPageVoter = new CommonPage(voterPage);
    const buyInPageVoter = new BuyInPage(voterPage);

    logger.info('VOTER');
    await laceSetupPageVoter.restoreWallet(testWalletTwo, NODE_ADDRESS, PUBSUB_ADDRESS, PROOF_SERVER_ADDRESS);
    await laceMainPageVoter.waitForSync();

    await test.step('9. Voter. Join Proposal.', async () => {
      logger.info('9. Voter. Join Proposal.');

      await voterPage.bringToFront();
      await voterPage.goto(DAO_URL);
      await voterConnectorPage.connectorAuthorizeAlways(voterBrowserContext);

      await mainPageVoter.joinProposal(contractAddress);
      await expect(commonPageVoter.spinner).not.toBeVisible({ timeout: TIMEOUT });
    });

    await test.step('10. Voter. Verify Commit page.', async () => {
      logger.info('10. Voter. Verify Commit page.');

      expect(await buyInPageVoter.amountInput.getAttribute('value')).toBe('1');

      logger.info('*Cast your vote* option is not selected');
      await expect(buyInPageVoter.selectedRadioButton).not.toBeVisible();

      logger.info('*Buy-in* button is enabled');
      await expect(buyInPageVoter.buyInButton).toBeEnabled();

      logger.info('*Commit Vote* button is disabled');
      await expect(buyInPageVoter.commitVoteButton).toBeDisabled();
    });

    await test.step('11. Voter. *Amount* input - delete value.', async () => {
      logger.info('11. Voter. *Amount* input - delete value.');

      await buyInPageVoter.amountInput.clear();

      logger.info('Error is displayed');
      await expect(buyInPageVoter.amountFrame).toHaveCSS('border-color', DaoDappConstants.RED_COLOUR);
      expect(await buyInPageVoter.amountErrorText.textContent()).toBe(DaoDappConstants.ERROR_TEXT_2);
      logger.info('*Buy-in* button is disabled');
      await expect(buyInPageVoter.buyInButton).toBeDisabled();
    });

    await test.step('12. Voter. *Amount* input - type in unexpected values.', async () => {
      logger.info('12. Voter. *Amount* input - type in unexpected values.');

      const INVALID_DATA = [
        { string: 'abc', type: 'Letters' },
        { string: '!@#$%^&*()_+', type: 'Special symbols' },
        { string: '-1', type: 'Negative value' },
        { string: '1.5', type: 'Float value' },
      ];

      for (const value of INVALID_DATA) {
        logger.info(`Type in ${value.type}`);

        await buyInPageVoter.amountInput.fill(value.string);

        logger.info('Error is displayed');
        await expect(buyInPageVoter.amountFrame).toHaveCSS('border-color', DaoDappConstants.RED_COLOUR);
        expect(await buyInPageVoter.amountErrorText.textContent()).toBe(DaoDappConstants.ERROR_TEXT_2);
        logger.info('*Buy-in* button is disabled');
        await expect(buyInPageVoter.buyInButton).toBeDisabled();

        await buyInPageVoter.amountInput.clear();
      }
    });

    await test.step('13. Voter. *Amount* input - type in expected value.', async () => {
      logger.info('13. Voter. *Amount* input - type in expected value.');

      await buyInPageVoter.amountInput.fill('1');
      logger.info('*Buy-in* button is enabled');
      await expect(buyInPageVoter.buyInButton).toBeEnabled();
      await expect(buyInPageVoter.commitVoteButton).toBeDisabled();
    });

    await test.step('14. Voter. Select *Approve* option.', async () => {
      logger.info('14. Voter. Select *Approve* option.');

      await buyInPageVoter.approveRadioButton.click();
      logger.info('*Commit Vote* button is enabled');
      await expect(buyInPageVoter.commitVoteButton).toBeEnabled();
    });
  });
});
