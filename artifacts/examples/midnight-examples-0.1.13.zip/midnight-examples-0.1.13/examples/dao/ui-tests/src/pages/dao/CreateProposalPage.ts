import type { Locator, Page } from '@playwright/test';

export class CreateProposalPage {
  readonly page: Page;
  readonly createProposalButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.createProposalButton = page.getByTestId('noproposal-create-button');
  }
}
