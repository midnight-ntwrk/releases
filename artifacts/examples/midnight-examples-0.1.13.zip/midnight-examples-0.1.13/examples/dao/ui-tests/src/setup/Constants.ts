export class Constants {
  static readonly EXTENSION_URL = 'chrome-extension://bjlhpephaokolembmpdcbobbpkjnoheb';

  // Phases
  static readonly COMMIT_PHASE = 'Commit';
}
