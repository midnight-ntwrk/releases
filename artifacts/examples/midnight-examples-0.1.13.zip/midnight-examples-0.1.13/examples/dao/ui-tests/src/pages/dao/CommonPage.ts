import type { Locator, Page } from '@playwright/test';

export class CommonPage {
  readonly page: Page;
  readonly spinner: Locator;
  readonly noProposalSpinner: Locator;
  readonly noProposalText: Locator;
  readonly dialogYesButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.spinner = page.getByTestId('backdrop-loader-spinner');
    this.noProposalSpinner = page.getByTestId('noproposal-loader');
    this.noProposalText = page.getByTestId('noproposal-title');
    this.dialogYesButton = page.getByTestId('alert-dialog-accept-button');
  }
}
