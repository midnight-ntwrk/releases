import type { Locator, Page } from '@playwright/test';

export class ProposalPage {
  readonly page: Page;
  readonly proposalTitle: Locator;
  readonly currentPhase: Locator;
  readonly beneficiaryAddress: Locator;
  readonly progressToRevealButton: Locator;
  readonly endProposalButton: Locator;
  readonly cashOutButton: Locator;
  readonly revealVoteButton: Locator;
  readonly statsTable: Locator;
  readonly commitsValue: Locator;
  readonly revealValue: Locator;
  readonly potSizeValue: Locator;
  readonly resultsTableRowYes: Locator;
  readonly yesVoteNumber: Locator;
  readonly yesPercentage: Locator;
  readonly yesPercentageLabel: Locator;

  constructor(page: Page) {
    this.page = page;
    this.proposalTitle = page.locator('h5:nth-child(1)');
    this.currentPhase = page.locator('[data-test-id="proposal-state"] p:nth-child(2)');
    this.beneficiaryAddress = page.locator('[data-test-id="proposal-beneficiary"] p:nth-child(2)');

    // BUTTONS
    // Organizer
    this.progressToRevealButton = page.getByTestId('commit-button');
    this.endProposalButton = page.getByTestId('reveal-button');
    this.cashOutButton = page.getByTestId('cash-out-button');
    // Voter
    this.revealVoteButton = page.getByTestId('vote-reveal-button');

    // Stats Table
    this.statsTable = page.locator('[data-test-id="votes-table-body"]');
    this.commitsValue = page.locator('[data-test-id="votes-table-body"] tr:nth-child(1) td:nth-child(2)');
    this.revealValue = page.locator('[data-test-id="votes-table-body"] tr:nth-child(2) td:nth-child(2)');
    this.potSizeValue = page.locator('[data-test-id="votes-table-body"] tr:nth-child(3) td:nth-child(2)');

    // Results Table
    // YES row
    this.resultsTableRowYes = page.locator('[data-test-id="results-table-body"] tr:nth-child(1)');
    this.yesVoteNumber = page.locator('[data-test-id="results-table-body"] tr:nth-child(1) td:nth-child(2)');
    this.yesPercentage = page.locator('[data-test-id="results-table-body"] tr:nth-child(1) td:nth-child(3)');
    this.yesPercentageLabel = page.locator('[data-test-id="results-table-body"] tr:nth-child(1) td:nth-child(3) p');
  }
}
