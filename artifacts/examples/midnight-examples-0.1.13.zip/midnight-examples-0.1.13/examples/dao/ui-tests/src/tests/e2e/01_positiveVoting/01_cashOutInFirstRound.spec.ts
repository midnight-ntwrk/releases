// When test will be unblocked - need to refactor steps - to reduce code amount

// /* eslint-disable @typescript-eslint/strict-boolean-expressions */
// /* eslint-disable  @typescript-eslint/no-floating-promises */
// import { allure } from 'allure-playwright';
// import test, { expect } from '@playwright/test';
// import { LaceSetupPage } from 'lace/LaceSetupPage';
// import { LaceMainPage } from 'lace/LaceMainPage';
// import { NewContractPage } from 'dao/NewContractPage';
// import { CommonPage } from 'dao/CommonPage';
// import { MainPage } from 'dao/MainPage';
// import { NewProposalPage } from 'dao/NewProposalPage';
// import { ProposalPage } from 'dao/ProposalPage';
// import { DaoDappConstants } from 'setup/DaoDappConstants';
// import { ConnectorPage } from 'lace/ConnectorPage';
// import { CreateProposalPage } from 'dao/CreateProposalPage';
// import { BuyInPage } from 'dao/BuyInPage';
// import { Services } from 'setup/Services';
// import { testWalletOne, testWalletTwo } from 'setup/walletConfiguration';
// import { getConfig } from 'setup/envConfig';
// import bootstrap from 'setup/BootstrapExtension';
// import { pino } from 'pino';

// const logger = pino({
//   transport: {
//     target: 'pino-pretty',
//   },
// });

// test.describe('DAO dApp. Voting Process.', () => {
//   test('01. Possible to CASH OUT in the 1-st round @PM-7949', async ({ page }) => {
//     allure.tms('PM-7949', `${Services.JIRA_URL}/PM-7949`);
//     allure.epic('DAO dApp');
//     allure.feature('UI');
//     allure.story('User story: DAO dApp e2e flow');

//     test.setTimeout(1200000);
//     let contractAddress: string;

//     const DAO_URL = getConfig().daoUi;
//     const NODE_ADDRESS = getConfig().nodeAddress;
//     const PUBSUB_ADDRESS = getConfig().indexerAddress;
//     const PROOF_SERVER_ADDRESS = getConfig().proofServerAddress;

//     const TIMEOUT = 240000;
//     const PROPOSAL_TITLE = 'Test PM-7949';
//     // Organizer is a BENEFICIARY
//     const BENEFICIARY_ADDRESS = testWalletOne.address;
//     const POT_SIZE_1 = '1.00tDUST';
//     const POT_SIZE_2 = '2.00tDUST';

//     // **************** ORGANIZER ****************
//     const orgContext = await bootstrap(DaoDappConstants.INITIAL_EXTENSION_URL);
//     const orgPage = orgContext.extPage;
//     const orgBrowserContext = orgContext.context;

//     const laceSetupPageOrg = new LaceSetupPage(orgPage);
//     const laceMainPageOrg = new LaceMainPage(orgPage);
//     const mainPageOrg = new MainPage(orgPage);
//     const newContractPageOrg = new NewContractPage(orgPage);
//     const commonPageOrg = new CommonPage(orgPage);
//     const newProposalPageOrg = new NewProposalPage(orgPage);
//     const proposalPageOrg = new ProposalPage(orgPage);
//     const createProposalPageOrg = new CreateProposalPage(orgPage);

//     logger.info('ORGANIZER');
//     await laceSetupPageOrg.restoreWallet(testWalletOne, NODE_ADDRESS, PUBSUB_ADDRESS, PROOF_SERVER_ADDRESS);
//     await laceMainPageOrg.waitForSync();

//     await test.step('1. Organizer. Open DAO page.', async () => {
//       logger.info('1. Organizer. Open DAO page.');

//       await orgPage.bringToFront();
//       await orgPage.goto(DAO_URL);

//       // ORGANIZER Connector
//       const orgPagePromise = await orgBrowserContext.waitForEvent('page');
//       const orgConnectorPage = new ConnectorPage(orgPagePromise);
//       await orgConnectorPage.authorizeAlways();
//     });

//     await test.step('2. Organizer. Deploy New Contract.', async () => {
//       logger.info('2. Organizer. Deploy New Contract.');

//       await mainPageOrg.deployNewContractButton.click();
//       await newContractPageOrg.deployNewContractButton.click();
//       await commonPageOrg.dialogYesButton.click();

//       // ORGANIZER Connector
//       const orgPagePromise = await orgBrowserContext.waitForEvent('page');
//       const orgConnectorPage = new ConnectorPage(orgPagePromise);
//       await orgConnectorPage.signTxButton.click();

//       await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });
//       contractAddress = (await newContractPageOrg.contractAddressInput.getAttribute('value')) as string;

//       await newContractPageOrg.joinButton.click();
//       await commonPageOrg.dialogYesButton.click();
//       await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });
//     });

//     await test.step('3. Organizer. Publish New Proposal.', async () => {
//       logger.info('3. Organizer. Publish New Proposal.');

//       await newProposalPageOrg.createProposalButton.click();
//       await orgPage.waitForTimeout(2000);

//       await newProposalPageOrg.publishNewProposal(PROPOSAL_TITLE, BENEFICIARY_ADDRESS);
//       await commonPageOrg.dialogYesButton.click();

//       // ORGANIZER Connector
//       const orgPagePromise = await orgBrowserContext.waitForEvent('page');
//       const orgConnectorPage = new ConnectorPage(orgPagePromise);
//       await expect(orgConnectorPage.signTxButton).toBeVisible({ timeout: TIMEOUT });
//       await orgConnectorPage.signTxButton.click();

//       await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });

//       logger.info('Verify elements on the *New Proposal* page');
//       expect(await proposalPageOrg.currentPhase.textContent()).toBe(DaoDappConstants.PHASE_COMMIT);
//       expect(await proposalPageOrg.commitsValue.textContent()).toBe('0');
//       expect(await proposalPageOrg.revealValue.textContent()).toBe('0');
//       expect(await proposalPageOrg.potSizeValue.textContent()).toBe(POT_SIZE_1);
//     });

//     // **************** VOTER ****************
//     const voterContext = await bootstrap(DaoDappConstants.INITIAL_EXTENSION_URL);
//     const voterPage = voterContext.extPage;
//     const voterBrowserContext = voterContext.context;

//     const laceSetupPageVoter = new LaceSetupPage(voterPage);
//     const laceMainPageVoter = new LaceMainPage(voterPage);
//     const mainPageVoter = new MainPage(voterPage);
//     const commonPageVoter = new CommonPage(voterPage);
//     const buyInPageVoter = new BuyInPage(voterPage);
//     const proposalPageVoter = new ProposalPage(voterPage);

//     logger.info('VOTER');
//     await laceSetupPageVoter.restoreWallet(testWalletTwo, NODE_ADDRESS, PUBSUB_ADDRESS, PROOF_SERVER_ADDRESS);
//     await laceMainPageVoter.waitForSync();

//     await test.step('4. Voter. Join Proposal.', async () => {
//       logger.info('4. Voter. Join Proposal.');

//       await voterPage.bringToFront();
//       await voterPage.goto(DAO_URL);

//       // VOTER Connector
//       const voterPagePromise = await voterBrowserContext.waitForEvent('page');
//       const voterConnectorPage = new ConnectorPage(voterPagePromise);
//       await voterConnectorPage.authorizeAlways();

//       await mainPageVoter.joinProposal(contractAddress);
//       await commonPageVoter.dialogYesButton.click();
//       await expect(commonPageVoter.spinner).not.toBeVisible({ timeout: TIMEOUT });
//     });

//     await test.step('5. Voter. Buy-in Native Tokens.', async () => {
//       logger.info('5. Voter. Buy-in Native Tokens.');

//       await buyInPageVoter.buyInButton.click();
//       await commonPageVoter.dialogYesButton.click();

//       /**
//        * After clicking YES button we will get `bui_in.prover` background request (with prover key), which has size 185 MB.
//        * It affects Playwright tests and they fail with error
//        * `Error: Cannot create a string longer than 0x1fffffe8 characters`
//        */

//       // VOTER Connector
//       const voterPagePromise = await voterBrowserContext.waitForEvent('page');
//       const voterConnectorPage = new ConnectorPage(voterPagePromise);
//       await expect(voterConnectorPage.signTxButton).toBeVisible({ timeout: TIMEOUT });
//       await voterConnectorPage.signTxButton.click();

//       await expect(commonPageVoter.spinner).not.toBeVisible({ timeout: TIMEOUT });
//     });

//     await test.step('6. Voter. Commit *Approve* vote.', async () => {
//       logger.info('6. Voter. Commit *Approve* vote.');

//       await buyInPageVoter.approveRadioButton.click();
//       await buyInPageVoter.commitVoteButton.click();
//       await commonPageVoter.dialogYesButton.click();

//       // VOTER Connector
//       const voterPagePromise = await voterBrowserContext.waitForEvent('page');
//       const voterConnectorPage = new ConnectorPage(voterPagePromise);
//       await expect(voterConnectorPage.signTxButton).toBeVisible({ timeout: TIMEOUT });
//       await voterConnectorPage.signTxButton.click();

//       await expect(commonPageVoter.spinner).not.toBeVisible({ timeout: TIMEOUT });
//     });

//     await test.step('7. Organizer. Verify *Proposal* page.', async () => {
//       logger.info('7. Organizer. Verify *Proposal* page.');

//       await orgPage.bringToFront();

//       logger.info('Verify elements on the *New Proposal* page');
//       expect(await proposalPageOrg.currentPhase.textContent()).toBe(DaoDappConstants.PHASE_COMMIT);
//       expect(await proposalPageOrg.commitsValue.textContent()).toBe('1');
//       expect(await proposalPageOrg.revealValue.textContent()).toBe('0');
//       expect(await proposalPageOrg.potSizeValue.textContent()).toBe(POT_SIZE_2);
//     });

//     await test.step('8. Organizer. Progress to Reveal.', async () => {
//       logger.info('8. Organizer. Progress to Reveal.');

//       await proposalPageOrg.progressToRevealButton.click();
//       await commonPageOrg.dialogYesButton.click();

//       // ORGANIZER Connector
//       const orgPagePromise = await orgBrowserContext.waitForEvent('page');
//       const orgConnectorPage = new ConnectorPage(orgPagePromise);
//       await expect(orgConnectorPage.signTxButton).toBeVisible({ timeout: TIMEOUT });
//       await orgConnectorPage.signTxButton.click();

//       await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });
//       expect(await proposalPageOrg.currentPhase.textContent()).toBe(DaoDappConstants.PHASE_REVEAL);
//       await expect(proposalPageOrg.endProposalButton).toBeVisible();
//     });

//     await test.step('9. Voter. Verify *Proposal* page.', async () => {
//       logger.info('9. Voter. Verify *Proposal* page.');

//       await voterPage.bringToFront();
//       expect(await proposalPageVoter.currentPhase.textContent()).toBe(DaoDappConstants.PHASE_REVEAL);
//       await expect(proposalPageVoter.revealVoteButton).toBeVisible();
//     });

//     await test.step('10. Voter. Reveal Vote.', async () => {
//       logger.info('10. Voter. Reveal Vote.');

//       await proposalPageVoter.revealVoteButton.click();
//       await commonPageVoter.dialogYesButton.click();

//       // VOTER Connector
//       const voterPagePromise = await voterBrowserContext.waitForEvent('page');
//       const voterConnectorPage = new ConnectorPage(voterPagePromise);
//       await expect(voterConnectorPage.signTxButton).toBeVisible({ timeout: TIMEOUT });
//       await voterConnectorPage.signTxButton.click();

//       await expect(commonPageVoter.spinner).not.toBeVisible({ timeout: TIMEOUT });
//       await expect(proposalPageVoter.revealVoteButton).not.toBeVisible();
//     });

//     await test.step('11. Organizer. Verify *Proposal* page.', async () => {
//       logger.info('11. Organizer. Verify *Proposal* page.');

//       await orgPage.bringToFront();

//       logger.info('Verify elements on the *Proposal* page');
//       expect(await proposalPageOrg.currentPhase.textContent()).toBe(DaoDappConstants.PHASE_REVEAL);
//       expect(await proposalPageOrg.commitsValue.textContent()).toBe('1');
//       expect(await proposalPageOrg.revealValue.textContent()).toBe('1');
//       expect(await proposalPageOrg.potSizeValue.textContent()).toBe(POT_SIZE_2);

//       await expect(proposalPageOrg.endProposalButton).toBeVisible();
//     });

//     await test.step('12. Organizer. End Proposal.', async () => {
//       logger.info('12. Organizer. End Proposal.');

//       await proposalPageOrg.endProposalButton.click();
//       await commonPageOrg.dialogYesButton.click();

//       // ORGANIZER Connector
//       const orgPagePromise = await orgBrowserContext.waitForEvent('page');
//       const orgConnectorPage = new ConnectorPage(orgPagePromise);
//       await expect(orgConnectorPage.signTxButton).toBeVisible({ timeout: TIMEOUT });
//       await orgConnectorPage.signTxButton.click();

//       logger.info('Verify elements on the *Proposal* page');
//       expect(await proposalPageOrg.currentPhase.textContent()).toBe(DaoDappConstants.PHASE_ENDED);
//       expect(await proposalPageOrg.commitsValue.textContent()).toBe('1');
//       expect(await proposalPageOrg.revealValue.textContent()).toBe('1');
//       expect(await proposalPageOrg.potSizeValue.textContent()).toBe(POT_SIZE_2);

//       await expect(proposalPageOrg.resultsTableRowYes).toHaveCSS('background-color', DaoDappConstants.GREEN_COLOUR);
//       expect(await proposalPageOrg.yesVoteNumber.textContent()).toBe('1');
//       expect(await proposalPageOrg.yesVoteNumber.textContent()).toBe('100.00%');
//       expect(await proposalPageOrg.yesPercentageLabel.textContent()).toContain('Awaiting Claim');
//       // Organizer is a BENEFICIARY
//       await expect(proposalPageOrg.cashOutButton).toBeVisible();
//     });

//     await test.step('13. Voter. Verify *Proposal* page.', async () => {
//       logger.info('13. Voter. Verify *Proposal* page.');

//       await voterPage.bringToFront();

//       logger.info('Verify elements on the *Proposal* page');
//       expect(await proposalPageVoter.currentPhase.textContent()).toBe(DaoDappConstants.PHASE_ENDED);
//       expect(await proposalPageVoter.commitsValue.textContent()).toBe('1');
//       expect(await proposalPageVoter.revealValue.textContent()).toBe('1');
//       expect(await proposalPageVoter.potSizeValue.textContent()).toBe(POT_SIZE_2);

//       await expect(proposalPageVoter.resultsTableRowYes).toHaveCSS('background-color', DaoDappConstants.GREEN_COLOUR);
//       expect(await proposalPageVoter.yesVoteNumber.textContent()).toBe('1');
//       expect(await proposalPageVoter.yesVoteNumber.textContent()).toBe('100.00%');
//       expect(await proposalPageVoter.yesPercentageLabel.textContent()).toContain('Awaiting Claim');
//       await expect(proposalPageVoter.cashOutButton).not.toBeVisible();
//     });

//     await test.step('14. Organizer. Cash Out.', async () => {
//       logger.info('14. Organizer. Cash Out.');

//       await orgPage.bringToFront();
//       await proposalPageOrg.cashOutButton.click();

//       await commonPageOrg.dialogYesButton.click();

//       // ORGANIZER Connector
//       const orgPagePromise = await orgBrowserContext.waitForEvent('page');
//       const orgConnectorPage = new ConnectorPage(orgPagePromise);
//       await expect(orgConnectorPage.signTxButton).toBeVisible({ timeout: TIMEOUT });
//       await orgConnectorPage.signTxButton.click();

//       await expect(createProposalPageOrg.createProposalButton).toBeVisible();
//     });

//     await test.step('15. Organizer. Verify diaplayed page.', async () => {
//       logger.info('15. Organizer. Verify diaplayed page.');

//       await voterPage.bringToFront();

//       await expect(commonPageVoter.noProposalSpinner).toBeVisible();
//       expect(await commonPageVoter.noProposalText.textContent()).toBe(DaoDappConstants.NO_PROPOSAL_TITLE);
//     });
//   });
// });
