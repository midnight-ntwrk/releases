/* eslint-disable @typescript-eslint/strict-boolean-expressions */
/* eslint-disable  @typescript-eslint/no-floating-promises */
import { allure } from 'allure-playwright';
import test, { expect } from '@playwright/test';
import { LaceSetupPage } from 'lace/LaceSetupPage';
import { LaceMainPage } from 'lace/LaceMainPage';
import { NewContractPage } from 'dao/NewContractPage';
import { CommonPage } from 'dao/CommonPage';
import { MainPage } from 'dao/MainPage';
import { NewProposalPage } from 'dao/NewProposalPage';
import { ProposalPage } from 'dao/ProposalPage';
import { DaoDappConstants } from 'setup/DaoDappConstants';
import { ConnectorPage } from 'lace/ConnectorPage';
import { BuyInPage } from 'dao/BuyInPage';
import { Services } from 'setup/Services';
import { testWalletOne, testWalletTwo } from 'setup/walletConfiguration';
import { getConfig } from 'setup/envConfig';
import bootstrap from 'setup/BootstrapExtension';
import { pino } from 'pino';

const logger = pino({
  transport: {
    target: 'pino-pretty',
  },
});

test.describe('DAO dApp. Native Tokens.', () => {
  test('03. Impossible to commit vote without Voting token @PM-8639', async ({ page }) => {
    allure.tms('PM-8639', `${Services.JIRA_URL}/PM-8639`);
    allure.epic('DAO dApp');
    allure.feature('UI');
    allure.story('User story: DAO dApp e2e flow');

    test.setTimeout(600000);
    let contractAddress: string;

    const DAO_URL = getConfig().daoUi;
    const NODE_ADDRESS = getConfig().nodeAddress;
    const PUBSUB_ADDRESS = getConfig().indexerAddress;
    const PROOF_SERVER_ADDRESS = getConfig().proofServerAddress;

    const TIMEOUT = 240000;
    const PROPOSAL_TITLE = 'Test PM-8639';
    // Organizer is a BENEFICIARY
    const BENEFICIARY_ADDRESS = testWalletOne.address;

    // **************** ORGANIZER ****************
    const orgContext = await bootstrap(DaoDappConstants.INITIAL_EXTENSION_URL);
    const orgPage = orgContext.extPage;
    const orgBrowserContext = orgContext.context;

    const orgConnectorPage = new ConnectorPage(orgPage);
    const laceSetupPageOrg = new LaceSetupPage(orgPage);
    const laceMainPageOrg = new LaceMainPage(orgPage);
    const mainPageOrg = new MainPage(orgPage);
    const newContractPageOrg = new NewContractPage(orgPage);
    const commonPageOrg = new CommonPage(orgPage);
    const newProposalPageOrg = new NewProposalPage(orgPage);
    const proposalPageOrg = new ProposalPage(orgPage);

    logger.info('ORGANIZER');
    await laceSetupPageOrg.restoreWallet(testWalletOne, NODE_ADDRESS, PUBSUB_ADDRESS, PROOF_SERVER_ADDRESS);
    await laceMainPageOrg.waitForSync();

    await test.step('1. Organizer. Open DAO page.', async () => {
      logger.info('1. Organizer. Open DAO page.');

      await orgPage.goto(DAO_URL);
      await orgConnectorPage.connectorAuthorizeAlways(orgBrowserContext);
    });

    await test.step('2. Organizer. Deploy New Contract.', async () => {
      logger.info('2. Organizer. Deploy New Contract.');

      await mainPageOrg.deployNewContractButton.click();
      await newContractPageOrg.deployNewContract();
      await orgConnectorPage.connectorSignTx(orgBrowserContext, TIMEOUT);

      await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });
      contractAddress = (await newContractPageOrg.contractAddressInput.getAttribute('value')) as string;

      await newContractPageOrg.joinContract();
      await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });
    });

    await test.step('3. Organizer. Publish New Proposal.', async () => {
      logger.info('3. Organizer. Publish New Proposal.');

      await newProposalPageOrg.createProposalButton.click();
      await orgPage.waitForTimeout(2000);

      await newProposalPageOrg.publishNewProposal(PROPOSAL_TITLE, BENEFICIARY_ADDRESS);
      await orgConnectorPage.connectorSignTx(orgBrowserContext, TIMEOUT);

      await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });
      expect(await proposalPageOrg.currentPhase.textContent()).toBe(DaoDappConstants.PHASE_COMMIT);
    });

    // **************** VOTER ****************
    const voterContext = await bootstrap(DaoDappConstants.INITIAL_EXTENSION_URL);
    const voterPage = voterContext.extPage;
    const voterBrowserContext = voterContext.context;

    const voterConnectorPage = new ConnectorPage(orgPage);
    const laceSetupPageVoter = new LaceSetupPage(voterPage);
    const laceMainPageVoter = new LaceMainPage(voterPage);
    const mainPageVoter = new MainPage(voterPage);
    const commonPageVoter = new CommonPage(voterPage);
    const buyInPageVoter = new BuyInPage(voterPage);

    logger.info('VOTER');
    await laceSetupPageVoter.restoreWallet(testWalletTwo, NODE_ADDRESS, PUBSUB_ADDRESS, PROOF_SERVER_ADDRESS);
    await laceMainPageVoter.waitForSync();

    await test.step('4. Voter. Join Proposal.', async () => {
      logger.info('4. Voter. Join Proposal.');

      await voterPage.bringToFront();
      await voterPage.goto(DAO_URL);
      await voterConnectorPage.connectorAuthorizeAlways(voterBrowserContext);

      await mainPageVoter.joinProposal(contractAddress);
      await expect(commonPageVoter.spinner).not.toBeVisible({ timeout: TIMEOUT });
    });

    await test.step('5. Voter. Commit Vote without native token Buy-in.', async () => {
      logger.info('5. Voter. Commit Vote without native token Buy-in.');

      await buyInPageVoter.approveRadioButton.click();
      await buyInPageVoter.commitVoteButton.click();
      await commonPageVoter.dialogYesButton.click();

      // VOTER Connector (didn't use Connector's methods, because we need to perform assertion on Connector page)
      const voterPagePromise = await voterBrowserContext.waitForEvent('page');
      const voterConnectorPage = new ConnectorPage(voterPagePromise);

      await expect(voterConnectorPage.signTxButton).toBeDisabled();
      expect(await voterConnectorPage.connector.textContent()).toContain(DaoDappConstants.INSUFFICIENT_BALANCE_ERROR);

      await voterConnectorPage.denyButton.click();
      await expect(commonPageOrg.spinner).not.toBeVisible({ timeout: TIMEOUT });
      await expect(buyInPageVoter.commitVoteButton).toBeDisabled();
      logger.info('Committing vote was not performed.');
    });
  });
});
