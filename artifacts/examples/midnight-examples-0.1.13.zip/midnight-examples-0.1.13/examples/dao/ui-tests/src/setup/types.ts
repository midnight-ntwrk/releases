export interface Wallet {
  mnemonics: string[];
  password: string;
  address: string;
  name: string;
}
