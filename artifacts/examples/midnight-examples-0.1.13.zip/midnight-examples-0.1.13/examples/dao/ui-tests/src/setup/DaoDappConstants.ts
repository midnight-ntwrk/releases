export class DaoDappConstants {
  // Updated
  static readonly INITIAL_EXTENSION_URL = 'chrome-extension://bjlhpephaokolembmpdcbobbpkjnoheb/app.html';
  static readonly TARGET_URL = 'http://127.0.0.1:8080';
  static readonly CONTRACT_ADDRESS_LABEL = 'Contract address to join *';
  static readonly NO_PROPOSAL_TITLE = 'Waiting for the organizer to start the proposal.';

  static readonly PHASE_COMMIT = 'Commit';
  static readonly PHASE_REVEAL = 'Reveal';
  static readonly PHASE_ENDED = 'Ended';

  static readonly GREEN_COLOUR = 'rgb(157, 213, 91)';
  static readonly RED_COLOUR = 'rgb(211, 47, 47)';

  static readonly ERROR_TEXT_1 = 'Please enter a non-negative amount of tDUST';
  static readonly ERROR_TEXT_2 = 'Amount of tokens you buy needs to be a positive integer';
  static readonly INSUFFICIENT_BALANCE_ERROR = 'Insufficient balance for token';
}
