import type { Locator, Page } from '@playwright/test';

export class BuyInPage {
  readonly page: Page;
  readonly amountInput: Locator;
  readonly amountFrame: Locator;
  readonly amountErrorText: Locator;
  readonly buyInButton: Locator;
  readonly selectedRadioButton: Locator;
  readonly approveRadioButton: Locator;
  readonly commitVoteButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.amountInput = page.locator('#buyin-amount');
    this.amountFrame = page.locator('[inputmode="numeric"] fieldset');
    this.amountErrorText = page.locator('[inputmode="numeric"] p');
    this.buyInButton = page.getByTestId('buy-in-button');
    this.selectedRadioButton = page.getByTestId('.Mui-checkedexist');
    this.approveRadioButton = page.locator('[data-test-id="proposal-vote-radio"] label:nth-child(1)');
    this.commitVoteButton = page.getByTestId('vote-commit-button');
  }
}
