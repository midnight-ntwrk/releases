# E2E tests for DAO dApp

The main purpose of E2E tests is to simulate the real user scenarios and to validate the functionality of application under test.

## Tech stack

E2E tests are developed using:

* [Playwright](https://playwright.dev) framework
* [Page Object Model](https://playwright.dev/docs/pom)

## The process of E2E tests creation and running

* Design test cases
* Set up test environment
* Run tests
* Analyze results

### Design test cases

Test cases are designed in a way to cover all potential E2E flows.
Part of tests are validating UI elements, while other tests are covering E2E scenarios.

The list of existing Test cases is stored in [Confluence](https://input-output.atlassian.net/wiki/spaces/MN/pages/3741220932/Existing+Automated+Test+Cases).
All Test cases have links to original Jira tickets with Xray Test cases.

### Set up test environment

Due to regular changes in DAO dApp application, an actual way of environment setup is described in [Confluence](https://input-output.atlassian.net/wiki/spaces/MN/pages/3776544815/DAO+dApp+test+environment+setup)

### Run tests

Rename [.env.example](https://github.com/input-output-hk/midnight-example-applications/blob/main/packages/dao-ui-tests/.env.example) file to `.env` (make changes in contents if needed) and run `direnv allow` to load environment variables and enter nix devShell (please consult [direnv installation page](https://direnv.net/docs/installation.html)).

Run all test files related to DAO dApp:

`yarn test-e2e`

Run a single test:

`npx playwright test <specPath>`

### Analyze results

If the test fails, logs in the console will provide detailed information where an error occurred.

## Code examples

### Example of logs

Example of logs for failed tests:

```text
1) tests/e2e/daoDapp/02_revealYes.spec.ts:11:3 › DAO dApp. E2E flows. › Voter votes `Yes` with REVEALING his vote @PM-5395 

    Error: Timed out 20000ms waiting for expect(received).toBeVisible()
    Call log:
      - expect.toBeVisible with timeout 20000ms
      - waiting for locator('[data-testid="noproposal-create-button"]')
      - waiting for locator('[data-testid="noproposal-create-button"]')

      30 |
      31 |       await mainPageOrg.goto(DaoDappConstants.ORGANISER_PATH)
    > 32 |       await expect(mainPageOrg.createProposalButton).toBeVisible()
         |                                                      ^
      33 |     })
      34 |
      35 |     await test.step('2. Open Create Proposal page.', async () => {

        at file:${path}/midnight-e2e-tests/tests/e2e/daoDapp/02_revealYes.spec.ts:32:54
        at file:${path}/midnight-e2e-tests/tests/e2e/daoDapp/02_revealYes.spec.ts:28:5
```

### Example of test file

Example of test which verifies elements on the Main page:

```ts
test.describe('DAO dApp. Basic UI checks.', () => {
  test('Main page - Basic UI checks @PM-5295', async ({mainPage}) => {
    allure.tms('PM-5295', `${Services.JIRA_URL}/PM-5295}`)
    allure.epic('DAO dApp')
    allure.feature('UI')
    allure.story('User story: DAO dApp e2e flow')

    await test.step('Open Micro DAO dApp', async () => {
      await mainPage.goto(DaoDappConstants.ORGANISER_PATH)
    })

    await test.step('Verify elements on the Main page', async () => {
      await expect(mainPage.logo).toBeVisible()
      expect(await mainPage.daoTitle.textContent()).toBe(DaoDappConstants.LOGO_TITLE)
      expect(await mainPage.noProposalsTitle.textContent()).toBe(
        DaoDappConstants.NO_PROPOSALS_TITLE,
      )
      await expect(mainPage.createProposalButton).toBeVisible()
    })
  })
});
```

### Example of PageObject file

Example of PageObject file which is used in test above:

```ts
export class MainPage {
  readonly page: Page
  readonly logo: Locator
  readonly daoTitle: Locator
  readonly connectedToTitle: Locator
  readonly noProposalsTitle: Locator
  readonly createProposalButton: Locator
  readonly noProposalLoader: Locator
  readonly noProposalTitle: Locator
  readonly url: string

  constructor(page: Page) {
    this.page = page
    this.url = Services.getInstance().getDaoDappUrl()
    this.logo = page.locator('[data-testid="header-logo"] [alt="logo-image"]')
    this.daoTitle = page.locator('[data-testid="header-logo"] h4')
    this.noProposalsTitle = page.locator('[data-testid="noproposal-title"]')
    this.createProposalButton = page.locator('[data-testid="noproposal-create-button"]')
    this.noProposalLoader = page.locator('[data-testid="noproposal-loader"]')
    this.noProposalTitle = page.locator('[data-testid="noproposal-title"]')
  }

  async goto(path?: string): Promise<null | Response> {
    if (typeof path !== 'undefined') {
      return await this.page.goto(`${this.url}${path}`)
    }
    return await this.page.goto(`${this.url}`)
  }
}

```
