#!/usr/bin/env sh

echo "Shutting down node"
kill -9 "$(lsof -t -i:5205)"

echo "Shutting down organizer\'s wallet server"
kill -9 "$(lsof -t -i:5206)"

echo "Shutting down voter\'s wallet server"
kill -9 "$(lsof -t -i:5207)"

echo "Shutting down organizer\'s DAO instance"
kill -9 "$(lsof -t -i:8001)"

echo "Shutting down voter\'s DAO instance"
kill -9 "$(lsof -t -i:8002)"
