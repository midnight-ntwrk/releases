#!/usr/bin/env sh

echo "Shutting down UI"
kill -9 "$(lsof -t -i:8080)"
