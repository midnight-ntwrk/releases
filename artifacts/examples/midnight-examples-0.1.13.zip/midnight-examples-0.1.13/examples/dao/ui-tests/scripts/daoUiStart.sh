#!/usr/bin/env sh
export NPM_TOKEN=$1
EXAMPLES_ROOT=$2

cd "$EXAMPLES_ROOT" || exit 1

cd packages/dao-server || exit; nohup npm run start-node &
sleep 5
cd ../wallet-server || exit; (yes | nohup npm run start -- --wallet=1 --port=5206) &
sleep 3
cd ../dao-server || exit; nohup npm run start -- --walletPort=5206 --serverPort=8001 &
sleep 5
cd ../wallet-server || exit; (yes | nohup npm run start -- --wallet=2 --port=5207) &
sleep 3
cd ../dao-server || exit; nohup npm run start -- --walletPort=5207 --serverPort=8002 &

sleep 3
echo this is the end
