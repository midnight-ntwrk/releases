#!/usr/bin/env sh
export NPM_TOKEN=$1
EXAMPLES_ROOT=$2

cd "$EXAMPLES_ROOT" || exit 1

. /home/app/.nix-profile/etc/profile.d/nix.sh
nix build
nix run .#prebuild

# start web server before all tests - doesn't need to be restarted in between tests, plus Playwright has an issue running http-server binary
cd packages/ui || exit; nohup npm run host > ui-start.log &

sleep 5
cat ui-start.log
echo this is the end
