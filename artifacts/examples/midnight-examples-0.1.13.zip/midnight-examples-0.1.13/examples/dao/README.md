# DAO example Midnight DApp

A **DAO**, or `Decentralized Autonomous Organization` is a community-led entity with no central authority.
Ultimately, a DAO is governed entirely by its members, who collectively make critical decisions about the project's future, such as technical upgrades and treasury allocations.

Micro DAO example allows Organizer to publish and voters to vote via DAO dApp.
All votes and activities through Midnight DAO are private, making it entirely different from traditional DAOs.
Example DAO dApp enable users to vote without revealing their identities.
The idea is to show a use case that effectively uses private transactions and voting leveraging Compact.

There are 3 (possibly overlapping) roles present:

1. Organizer - who sets up proposals and provides seed funds for them
2. Voter - who can vote on proposals after buying in
3. Beneficiary - who withdraws pot in case of voting in favor of a proposal

The contract lifecycle follows this diagram:
```mermaid
graph LR;
  start(" ") -- deploy --> Setup
  Setup -- set topic by organizer --> Commit
  Commit -- advance by organizer --> Reveal
  Reveal -- advance by organizer --> Final
  Final -- advance by organizer in case of negative voting  --> Setup
  Final -- withdraw pot by beneficiary in case of positive voting --> Setup
  
  Setup -- buy in --> Setup
  Commit -- buy in --> Commit
  Reveal -- buy in --> Reveal
  Final -- buy in --> Final
```

For a particular voter - buy in allows to vote only in current or next commit phase.
Buying in while contract is in reveal or final phase requires waiting for a next round

## Code structure

This example is split into a couple of packages:

  - `contract` - it contains contract implementation, and necessary surrounding 
    code for unit testing it (like witnesses implementation); There, the `micro-dao.acd` 
    and `micro-dao.test.ts` files seem to be great starting point for reading.
  - `midnight-js` - midnight.js integration, including integration tests which 
    use testcontainers to run whole Midnight stack. By design, all building blocks 
    should already be defined in `contract` package. This package is really only 
    about connecting them together in a way, that uses Midnight.js to issue real transactions 
  - `dapp` and `ui-tests` - UI, the most top-level integration and e2e tests
  - `api` and `api-testing` - internal API definition for a boundary between UI and contract/chain interaction. 
    The way it is defined allows to run the same set of tests as unit tests for contract, 
    as well as integration tests on Midnight.js, probably even e2e tests would be possible 
    to be implemented that way. Given the UI is implemented in a big part against this API; 
    It is also possible to use an in-memory fake implementation to work on UI (though 
    certain changes in code would be required for that) 
  - `helpers` - various helpers used across the rest of the codebase. Most notably - 
    `Resource` and `Bloc` - implementation for managing lifecycle of objects that 
    require setup and teardown, and a form of observable mutable reference


## Quick start


### 1. Preparation (to prebuild and fetch dependencies)

```shell
yarn
yarn build
```

---

### 2. Run node and rest of stack

```shell
docker compose up
```

---

### 3. Initialize a wallet

A JS snippet like below can be used to provide tokens to a specified address:
```ts
import {WalletBuilder} from '@midnight-ntwrk/wallet';
import * as rx from 'rxjs';
import * as ledger from '@midnight-ntwrk/ledger';
import { setNetworkId, networkId } from '@midnight-ntwrk/midnight-js-network-id';

// This seed receives tokens minted in the genesis block in local setup
const GENESIS_MINT_WALLET_SEED = '0000000000000000000000000000000000000000000000000000000000000042';
const receiverAddress = '<enter receiver wallet address>'

setNetworkId(networkId.undeployed);

const wallet = await WalletBuilder.buildFromSeed(
  `http://localhost:8088/api/v1/graphql`, //indexer HTTP
  `ws://localhost:8088/api/v1/graphql/ws`, //indexer WebSockets
  `http://localhost:6300`, // proving server
  `http://localhost:9944`, // node
  GENESIS_MINT_WALLET_SEED,
);
wallet.start();

// Let's wait for the wallet to observe the tokens
await rx.firstValueFrom(wallet.state().pipe(filter(state => (state.balances[ledger.nativeToken()] ?? 0n) > 0n)));

const recipe = await wallet.transferTransaction([{ type: ledger.nativeToken(), amount: 20_000_000n, receiverAddress }]);
const transaction = await wallet.proveTransaction(recipe);
await wallet.submitTransaction(transaction);
```

---

### 4. Serve the DAO Dapp

```shell
yarn dao-dapp
```

It should print the exact address the DApp is available on. By default, it is  `http://localhost:8080`

By default it will target "Undeployed" network. Setting environment variable 
`VITE_NETWORK_ID` (or adjusting the `.env` file in `examples/dao/dapp` directory) 
with value `devnet` allows to target devnet configuration.

---

### 5. Open UI in browser.

Open a browser and go to URL previous steps prints.


## Deployment

A DApp is essentially a static website. There are a couple of things to remember 
about when preparing the artifacts, but otherwise any method for hosting will be just fine.

In particular, taking a look into `dao-dapp` package, one can see a sequence 
of steps in order to deploy a DApp:
  - Generic, Source code preprocessing and bundling
  - Midnight-specific, Copying ZK keys
  - Generic, hosting the results

### Source code preprocessing and bundling

A standard practice in front-end ecosystem is preprocessing of files served to browser.
At a cost of a build step, it may introduce many benefits, most notably:
- JS code packaged in an as optimal way as the tooling can prepare with provided sources
- All referenced assets being copied over to the output directory
- Asset names normalization to help browsers with cache management
- Clearing resulting bundle out of unused code

In this case the DApp code is written in TypeScript, and it needs to be type-checked 
as well as compiled into JavaScript. The build tool used in this particular 
case - Vite - does not perform type checking of TypeScript files for performance 
and architectural reasons, so TypeScript compiler needs to be invoked separately
for type-checking.

Vite, which is being used in this example, is known for a quite a good 
performance and overall developer experience. No difficulties are 
expected when using other tools like webpack, rollup or parcel. Just their 
configuration and capabilities will differ.

### Copying ZK keys

This is really the only Midnight-DApp specific step when it comes to preparing a DApp for deployment.

To let the `FetchZkConfigProvider` resolve ZK keys, they need to be accessible 
to user's browser at a location that the provider can be configured with. 
So they are copied into the `dist` directory (where rest of the bundle lives too), 
maintaining the structure - `keys` directory into `dist/keys` and `zkir` into `dist/zkir`. 
This allows to instantiate the provider using following snippet:
```ts
import { FetchZkConfigProvider } from '@midnight-ntwrk/midnight-js-fetch-zk-config-provider';

const zkConfigProvider = new FetchZkConfigProvider(window.location.origin, fetch.bind(window));
```

`window.location.origin` refers to the formatted _origin_ of a loaded page, that 
is a triplet consisting of:
  - the scheme (http/https)
  - the host name
  - the port

If the DApp is served from an `https://example.com` domain (so the origin is 
also `https://example.com`), when calling `set_topic` circuit, such configured 
`FetchZkConfigProvider` is going to look at following paths, and all of them 
need to be available to the user's browser:
  - `https://example.com/keys/set_topic.verifier`
  - `https://example.com/keys/set_topic.prover`
  - `https://example.com/zkir/set_topic.zkir`

Which, in most cases is more than enough. But in case of more complex 
structures, like using multiple contracts simultaneously or the DApp being a part 
of a bigger webpage, one needs to be careful about the exact `FetchZkConfigProvider` 
configuration and location of ZK keys.

#### Related links

##### Origin

  - https://developer.mozilla.org/en-US/docs/Web/API/Location/origin
  - https://developer.mozilla.org/en-US/docs/Glossary/Origin
  - https://developer.mozilla.org/en-US/docs/Web/Security/Same-origin_policy

### Hosting

Once everything is ready, in most cases, there will be a `dist` directory created, with more or less following contents:
```
./dist
├── anonymousUser.png
├── assets
│  └── index-13b16e17.js
├── icon.png
├── index.html
├── keys
│  ├── advance.prover
│  ├── advance.verifier
│  ...
│  ├── vote_reveal.prover
│  └── vote_reveal.verifier
├── midnight-logo.png
└── zkir
   ├── advance.zkir
   ...
   └── vote_reveal.zkir
```
There is prepared `index.html` in this directory, all images, and ZK keys too.

Such prepared directory can be directly hosted by a web-server of choice. 
The script `start` there uses the `http-server` package to serve the `dist` directory 
using a very simple, local http server. 
