import { pipe } from 'fp-ts/function';
import { block } from './functions.js';

export interface Allocated<T> {
  value: T;
  teardown: () => Promise<void>;
}

/**
 * A type, which handles resource allocation and deallocation, also in presence of errors
 * For it to work well, it's important to always suspend side effects, so, e.g. all promises need to be wrapped in thunks, etc.
 * It's inspired a lot by Scala's cats-effect Resource type
 *
 * Once created, the preferred way of utilizing a `Resource` is through `Resource.use` function
 * as it makes sure necessary allocation and deallocation is properly orchestrated around passed callback
 */
export interface Resource<T> {
  /**
   * The most low-level representation of a resource
   * Prepare the value to use, and teardown manually later. Particularly useful in tests or to build other combinators on top of it
   */
  allocate: () => Promise<Allocated<T>>;
}
export const Resource = block(() => {
  /**
   * Create a `Resource` by providing async setup and teardown functions.
   *
   * In many ways this function is basis for other ones
   */
  const make = <T>(setup: () => Promise<T>, teardown: (t: T) => Promise<void>): Resource<T> => ({
    allocate: () => setup().then((value) => ({ value, teardown: () => teardown(value) })),
  });

  /**
   * Create a `Resource` by providing syn setup and teardown functions
   */
  const makeSync = <T>(setup: () => T, teardown: (t: T) => void): Resource<T> =>
    make(
      () => Promise.resolve(setup()),
      (t) => Promise.resolve(teardown(t)),
    );

  /**
   * Convert a thunk returning `Promise` to a `Resource`.
   *
   * This function has a noop teardown. Use `make` when teardown is needed
   */
  const fromPromise = <T>(thunk: () => Promise<T>): Resource<T> => {
    return {
      allocate: () => thunk().then((value) => ({ value, teardown: () => Promise.resolve(undefined) })),
    };
  };

  /**
   * Create a `Resource` out of single, sync value.
   *
   * This function has a noop teardown. Use `make` or `makeSync` when teardown is needed
   */
  const from = <T>(thunk: () => T): Resource<T> => {
    return fromPromise(() => {
      try {
        return Promise.resolve(thunk());
      } catch (e) {
        return Promise.reject(e);
      }
    });
  };

  /**
   * Initialize `Resource` to be used. Requires manual call to `Allocated.teardown` in order to clean up.
   *
   * For that reason it is a discouraged method in general use and `use` is the preferred one.
   * `allocate` is particularly useful though in testing or when used in frameworks that encourage
   * resource through various kinds of hooks. For example in testing needed resources may be prepared
   * in `beforeEach`/`beforeAll` hooks and cleaned up in `afterEach`/`afterAll` ones.
   * @param resource - Resource to initialize
   */

  const allocate = <T>(resource: Resource<T>): Promise<Allocated<T>> => resource.allocate();

  /**
   * The most preferred way of utilizing a `Resource` object.
   *
   * Automatically schedules setup and teardown functions around passed callback to ensure
   * the resource is used only as long as needed
   */
  const use =
    <T, S>(cb: (t: T) => Promise<S>) =>
    (resource: Resource<T>): Promise<S> =>
      resource.allocate().then((allocated) => cb(allocated.value).finally(() => allocated.teardown()));

  /**
   * Given a value held in resource, convert it to some other value, returning a new resource.
   * In other words - regular `map` known from rx.js or arrays, but for `Resource`
   */
  const map =
    <T, S>(cb: (t: T) => S) =>
    (resource: Resource<T>): Resource<S> => ({
      allocate: () =>
        resource.allocate().then((allocated) => ({
          ...allocated,
          value: cb(allocated.value),
        })),
    });

  /**
   * Like a `map`, but the new value is returned in a `Promise` instead
   */
  const mapAsync =
    <T, S>(cb: (t: T) => Promise<S>) =>
    (resource: Resource<T>): Resource<S> => ({
      allocate: () =>
        resource.allocate().then((allocated) =>
          cb(allocated.value).then((value) => ({
            ...allocated,
            value,
          })),
        ),
    });

  /**
   * Combine 2 resources through passed callback, making the result value from callback to be returned from resulting `Resource`
   *
   * Importantly - it ensures proper order of execution of setup and teardown, that is in example below the expected output is:
   * ```
   * A setup
   * B setup
   * use
   * B teardown
   * A teardown
   * ```
   *
   * ```ts
   * const loggingResource = (tag: string) => Resource.makeSync<void>(
   *   () => {console.log(`${tag} setup`)},
   *   () => {console.log(`${tag} teardown`)}
   * );
   *
   * pipe(
   *   loggingResource('A'),
   *   Resource.flatMap(() => loggingResource('B')),
   *   Resource.use(() => {
   *     console.log('use');
   *     return Promise.resolve();
   *   }),
   * )
   * ```
   */
  const flatMap =
    <T, S>(cb: (t: T) => Resource<S>) =>
    (resource: Resource<T>): Resource<S> => ({
      allocate: () =>
        resource.allocate().then((tAllocated) =>
          cb(tAllocated.value)
            .allocate()
            .then(
              (sAllocated): Allocated<S> => ({
                value: sAllocated.value,
                teardown: () => sAllocated.teardown().finally(() => tAllocated.teardown()),
              }),
            ),
        ),
    });

  /**
   * Combine 2 resources together by returning a tuple of both values
   */
  const zip =
    <S>(sResource: Resource<S>) =>
    <T>(tResource: Resource<T>): Resource<[T, S]> =>
      pipe(
        tResource,
        flatMap((t) =>
          pipe(
            sResource,
            map((s) => [t, s]),
          ),
        ),
      );

  /**
   * Combine 2 resources together into a tuple,
   * where first element is the one from original resource, and the other - value from resource produced by callback
   * @param cb - factory for a new resource
   */
  const mproduct =
    <A, B>(cb: (a: A) => Resource<B>) =>
    (resource: Resource<A>): Resource<[A, B]> =>
      pipe(
        resource,
        flatMap((a) =>
          pipe(
            cb(a),
            map((b) => [a, b]),
          ),
        ),
      );

  return { fromPromise, from, make, makeSync, use, allocate, map, mapAsync, flatMap, zip, mproduct };
});
