import { Observable, scan, shareReplay, Subject } from 'rxjs';
import { Logger, noopLogger } from './logging.js';
import { Resource } from './resource.js';
import { StateUpdate } from './types.js';

/**
 * Bloc is a state management pattern that originated in Dart/flutter ecosystem (at least under this name).
 * It can be thought of as taking the best out of Elm/Redux-like approach and Angular's services, that is:
 *   - it has a single, immutable, but observable state
 *   - changes to state can only be originated through well-defined entrypoints, preferably as pure functions
 *   - entrypoints for changing state can perform all sorts of logic and side-effects if really needed
 *   - by composing Blocs of different kind it is possible to derive new state, that is more suitable
 *     for consumption in UI, all it takes is rx.js operators
 */
export abstract class Bloc<T> {
  /**
   * Because of ongoing subscription to data, it is preferred to wrap `Bloc` instances
   * into a `Resource`, which will take care of teardown
   * @param bloc - thunk to create specific Bloc instance
   */
  static asResource<B extends Bloc<unknown>>(bloc: () => B): Resource<B> {
    return Resource.makeSync(bloc, (bloc: B) => {
      bloc.complete();
    });
  }

  /**
   * Internal queue of scheduled updates to state.
   *
   * Using functions directly allows for low-ceremony implementation when needed, as well as it doesn't
   * take much effort to turn these into async functions if async semantically blocking updates are needed
   */
  #stateChanges = new Subject<StateUpdate<T>>();

  #logger: Logger;

  /**
   * Public observable state. In principle, it should be the only source of state for components outside Bloc
   */
  state$: Observable<T>;

  /**
   * Initializes the state and internal subscription.
   * Uses the fact that everything flows through `#stateChanges` to start the state
   * as well as means for completion.
   *
   * It's protected to let implementations decide how they should be initialized.
   * @protected
   */
  protected constructor(initialState: T, logger: Logger = noopLogger) {
    this.#logger = logger;
    this.state$ = this.#stateChanges.pipe(
      scan((prev: T, update: StateUpdate<T>) => {
        logger.trace('Performing state update');
        return update(prev);
      }, initialState),
      shareReplay(1),
    );
    this.state$.subscribe({
      next: (state) => logger.trace({ state }, 'New Bloc State'),
      error: (error: unknown) => logger.error(error, 'Bloc state error'),
      complete: () => logger.debug('Bloc state completed'),
    });
    this.#stateChanges.next((a) => a); // to run the state
  }

  /**
   * Update state by putting update function on the `#stateChanges` queue.
   *
   * Additionally, it wraps whole process into an observable, which gets notified
   * at the moment of performing actual state update. There is certain possibility of a race
   * if one compares observable returned here with `$state`, but in most cases it should not matter.
   * @param cb - function to update the state
   * @param name - update name for logging
   * @protected
   */
  protected updateState(cb: StateUpdate<T>, name?: string): Observable<void> {
    this.#logger.trace({ name }, `State update ${name || ''} scheduled`);
    return new Observable((observer) => {
      this.#logger.trace({ name }, `State update ${name || ''} subscribed`);
      this.#stateChanges.next((prev) => {
        this.#logger.trace({ name, state: prev }, `Performing state update`);
        const next = cb(prev);
        this.#logger.trace({ name, previousState: prev, newState: next }, `State update done`);
        setTimeout(() => {
          observer.next();
          observer.complete();
        }, 0);
        return next;
      });
    });
  }

  /**
   * Stop state subscriptions to allow a graceful teardown and garbage collection
   * @protected
   */
  protected complete(): void {
    this.#logger.debug({ message: "Completing Bloc's state observable" });
    this.#stateChanges.complete();
  }
}
