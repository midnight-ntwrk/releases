export * from './ProposalDetails';
