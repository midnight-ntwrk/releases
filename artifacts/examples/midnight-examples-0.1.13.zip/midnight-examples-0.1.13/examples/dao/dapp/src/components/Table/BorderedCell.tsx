import { type ReactNode, type ReactElement } from 'react';
import { TableCell } from '@mui/material';

interface BorderedCellProps {
  children: ReactNode;
  isBold?: boolean;
}

export const BorderedCell = ({ children, isBold }: BorderedCellProps): ReactElement => {
  return (
    <TableCell
      sx={{
        border: '1px solid',
        borderColor: '#ddd',
        fontWeight: isBold === true ? 600 : 500,
      }}
    >
      {children}
    </TableCell>
  );
};
