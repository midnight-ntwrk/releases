import { type ReactElement } from 'react';
import { Outlet } from 'react-router-dom';
import { Box } from '@mui/material';

import { useAppContext } from '../../hooks';
import { Header } from './Header';
import { BackdropLoader } from '../Loader';

export const MainLayout = (): ReactElement => {
  const { isLoading, isClientInitialized } = useAppContext();

  if (!isClientInitialized) {
    return <Box>Initializing...</Box>;
  }

  return (
    <Box>
      <Header />
      {isLoading && <BackdropLoader />}
      <Box sx={{ py: 4, px: 6 }}>
        <Outlet />
      </Box>
    </Box>
  );
};
