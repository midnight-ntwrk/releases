import { test, expect } from '@playwright/experimental-ct-react';
import { BackdropLoader } from './BackdropLoader';

test.describe('BackdropLoader component tests', () => {
  test('BackdropLoader test', async ({ mount, page }) => {
    const spinner = page.locator('[data-testid="backdrop-loader-spinner"]');
    const title = page.locator('[data-testid="backdrop-loader-title"]');

    const component = await mount(<BackdropLoader />);

    await expect(component).toBeEnabled();

    await expect(spinner).toHaveCSS('width', '40px');
    await expect(spinner).toHaveCSS('height', '40px');

    await expect(title).toHaveText('Please wait');
    await expect(title).toHaveCSS('font-weight', '500');
  });
});
