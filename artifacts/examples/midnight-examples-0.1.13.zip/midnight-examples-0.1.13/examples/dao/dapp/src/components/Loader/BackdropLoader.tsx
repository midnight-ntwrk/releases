import { type ReactElement } from 'react';
import { Backdrop, Box, CircularProgress, Typography, useTheme } from '@mui/material';

import { MISC } from '../../locale';

interface BackdropLoaderProps {
  title?: string;
}

export const BackdropLoader = ({ title }: BackdropLoaderProps): ReactElement => {
  const theme = useTheme();

  return (
    <Backdrop sx={{ color: 'white', zIndex: theme.zIndex.drawer + 1 }} open>
      <Box sx={{ textAlign: 'center' }}>
        <CircularProgress data-testid="backdrop-loader-spinner" color="inherit" />
        <Typography data-testid="backdrop-loader-title" sx={{ mt: 2 }} color="inherit" variant="h6">
          {MISC.pleaseWait}
        </Typography>
        {title != null ? (
          <Typography data-testid="backdrop-loader-subtitle" sx={{ mt: 2 }} color="inherit" variant="h6">
            {title}
          </Typography>
        ) : (
          ''
        )}
      </Box>
    </Backdrop>
  );
};
