export const TRANSACTION_TIMEOUT = 5 * 60 * 1000;
