import { type ReactElement } from 'react';
import { Table, TableContainer, TableRow, TableBody, Typography } from '@mui/material';
import { BorderedCell } from './BorderedCell';

type StringOrNumber = string | number;

interface TableRowData {
  title: StringOrNumber;
  value: StringOrNumber;
  testId?: string;
}

interface StatsTableProps {
  title: string;
  data: TableRowData[];
}

export const StatsTable = ({ title, data }: StatsTableProps): ReactElement => {
  return (
    <>
      <Typography variant="h6" sx={{ mb: 1 }} fontWeight={600}>
        {title}
      </Typography>
      <TableContainer sx={{ mb: 4 }}>
        <Table data-test-id="vote-table">
          <TableBody data-test-id="votes-table-body">
            {data.map((row) => (
              <TableRow key={row.title}>
                <BorderedCell isBold>{row.title}</BorderedCell>
                <BorderedCell data-test-id={row.testId}>{row.value}</BorderedCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </>
  );
};
