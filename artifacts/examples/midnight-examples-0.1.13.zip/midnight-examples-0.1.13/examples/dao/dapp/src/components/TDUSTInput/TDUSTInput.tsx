import { FormControl, InputLabel, TextField } from '@mui/material';
import React, { type ReactElement, useEffect, useState } from 'react';
import { TDUST_INPUT } from '../../locale';
import { TDUST } from '../../TDUST';

export type AmountOrError = { error: false; value: TDUST } | { error: true; message: string };

export interface TDUSTInputProps {
  label: string;
  id: string;
  onChange: (amount: AmountOrError) => void;
}

export const TDUSTInput = (props: TDUSTInputProps): ReactElement => {
  const [amountValueRaw, setAmountValueRaw] = useState<string>('1');
  const [amount, setAmount] = useState<AmountOrError>({
    error: false,
    value: TDUST.ONE,
  });

  useEffect(() => {
    try {
      const parsed = TDUST.fromString(amountValueRaw);
      if (parsed.tokens.isNegative()) {
        setAmount({
          error: true,
          message: TDUST_INPUT.amountError,
        });
      } else {
        setAmount({
          error: false,
          value: parsed,
        });
      }
    } catch (e) {
      setAmount({ error: true, message: TDUST_INPUT.amountError });
    }
  }, [amountValueRaw]);

  useEffect(() => {
    props.onChange(amount);
  }, [amount]);

  return (
    <FormControl sx={{ display: 'flex' }}>
      <InputLabel htmlFor={props.id}></InputLabel>
      <TextField
        label={props.label}
        id={props.id}
        data-testid={props.id}
        inputMode="numeric"
        error={amount.error}
        helperText={amount.error ? amount.message : null}
        value={amountValueRaw}
        onChange={(ev) => {
          setAmountValueRaw(ev.target.value);
        }}
      />
    </FormControl>
  );
};
