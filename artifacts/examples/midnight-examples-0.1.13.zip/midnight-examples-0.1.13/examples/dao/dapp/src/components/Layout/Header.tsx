import { AppBar, Box, useTheme } from '@mui/material';
import { type ReactElement } from 'react';
import { useNavigate } from 'react-router-dom';

export const Header = (): ReactElement => {
  const theme = useTheme();
  const navigate = useNavigate();

  return (
    <AppBar
      position="static"
      data-testid="header"
      sx={{
        backgroundColor: theme.palette.primary.light,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}
    >
      <Box
        sx={{
          display: 'flex',
          px: 6,
          py: 2.2,
          cursor: 'pointer',
          alignItems: 'center',
        }}
        onClick={() => {
          navigate('/');
        }}
        data-testid="header-logo"
      >
        <img src="/midnight-logo.png" alt="logo-image" height={66} />
      </Box>
    </AppBar>
  );
};
