import { test, expect } from '@playwright/experimental-ct-react';
import { NoProposal } from './NoProposal';

test.describe('No Proposal component tests', () => {
  const titleText = 'No Proposal Title';
  const buttonText = 'Button Title';

  test('No Proposal test', async ({ mount, page }) => {
    const title = page.locator('[data-testid="noproposal-title"]');
    const button = page.locator('[data-testid="noproposal-create-button"]');

    const component = await mount(
      <NoProposal isOrganizer title={titleText} buttonTitle={buttonText} handleButtonClick={() => undefined} />,
    );

    await expect(component).toBeEnabled();

    await expect(title).toContainText(titleText);
    await expect(button).toContainText(buttonText);
    await expect(button).toHaveCSS('background-color', 'rgb(46, 125, 50)');
  });
});
