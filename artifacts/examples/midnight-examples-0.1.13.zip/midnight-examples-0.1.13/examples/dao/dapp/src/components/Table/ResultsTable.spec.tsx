import { test, expect } from '@playwright/experimental-ct-react';
import { ResultsTable } from './ResultsTable';

test.describe('Results Table component tests', () => {
  const YES_VOTES_NUMBER = 1;
  const NO_VOTES_NUMBER = 0;

  test('Results Table test', async ({ mount, page }) => {
    const headerOptionCell = page.locator('[data-test-id="results-table-head"] th:nth-child(1)');
    const headerVotesCell = page.locator('[data-test-id="results-table-head"] th:nth-child(2)');
    const headerPercentageCell = page.locator('[data-test-id="results-table-head"] th:nth-child(3)');

    const bodyYesOptionCell = page.locator('[data-test-id="results-table-body"] tr:nth-child(1) td:nth-child(1)');
    const bodyYesVotesCell = page.locator('[data-test-id="results-table-body"] tr:nth-child(1) td:nth-child(2)');
    // const bodyYesPercentageCell = page.locator('[data-test-id="results-table-body"] tr:nth-child(1) td:nth-child(3)');

    const bodyNoOptionCell = page.locator('[data-test-id="results-table-body"] tr:nth-child(2) td:nth-child(1)');
    const bodyNoVotesCell = page.locator('[data-test-id="results-table-body"] tr:nth-child(2) td:nth-child(2)');
    // const bodyNoPercentageCell = page.locator('[data-test-id="results-table-body"] tr:nth-child(2) td:nth-child(3)');

    const component = await mount(
      <ResultsTable
        votingState={{
          state: 'commit',
          votesYes: YES_VOTES_NUMBER,
          votesNo: NO_VOTES_NUMBER,
          proposal: { topic: '', beneficiary: '' },
          committed: 1,
          revealed: 1,
        }}
      />,
    );

    await expect(component).toBeEnabled();

    await expect(headerOptionCell).toHaveText('Option');
    await expect(headerVotesCell).toHaveText('No. of votes');
    await expect(headerPercentageCell).toHaveText('Percentage');

    await expect(bodyYesOptionCell).toHaveText('Yes');
    await expect(bodyYesVotesCell).toHaveText(YES_VOTES_NUMBER.toString());
    // TBD bodyYesPercentageCell

    await expect(bodyNoOptionCell).toHaveText('No');
    await expect(bodyNoVotesCell).toHaveText(NO_VOTES_NUMBER.toString());
    // TBD bodyNoPercentageCell
  });
});
