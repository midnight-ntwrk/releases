import { createTheme } from '@mui/material';

export const theme = createTheme({
  typography: {
    fontFamily: 'Helvetica',
    allVariants: {
      color: '#222222',
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
        },
      },
    },
  },
  palette: {
    primary: {
      main: '#222222',
      light: '#3C286E',
    },
    secondary: {
      main: '#ffffff',
    },
    success: {
      main: '#85CB33',
      contrastText: '#ffffff',
    },
    text: {
      primary: '#222222',
    },
  },
});
