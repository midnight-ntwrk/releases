import type { ContractAddress } from '@midnight-ntwrk/compact-runtime';
import {
  type ActionId,
  Actions,
  AsyncActionStates,
  type Ballot,
  type DaoConfig,
  type DaoState,
  type Proposal,
  States,
} from '@midnight-ntwrk/dao-api';
import { defaultConfig, EphemeralStateBloc } from '@midnight-ntwrk/dao-contract';
import semver from 'semver';
import { pipe, Resource } from '@midnight-ntwrk/dao-helpers';
import {
  type Config,
  DaoMidnightJSAPI,
  type MidnightJSDaoProviders,
  SubscribablePrivateStateProviderDecorator,
  webCryptoCryptography,
} from '@midnight-ntwrk/dao-midnight-js';
import type { DAppConnectorAPI, DAppConnectorWalletAPI, ServiceUriConfig } from '@midnight-ntwrk/dapp-connector-api';
import '@midnight-ntwrk/dapp-connector-api';
import type { CoinInfo, TransactionId } from '@midnight-ntwrk/ledger';
import { Transaction } from '@midnight-ntwrk/ledger';
import { FetchZkConfigProvider } from '@midnight-ntwrk/midnight-js-fetch-zk-config-provider';
import { httpClientProofProvider } from '@midnight-ntwrk/midnight-js-http-client-proof-provider';
import { indexerPublicDataProvider } from '@midnight-ntwrk/midnight-js-indexer-public-data-provider';
import { levelPrivateStateProvider } from '@midnight-ntwrk/midnight-js-level-private-state-provider';
import {
  type BalancedTransaction,
  createBalancedTx,
  type UnbalancedTransaction,
} from '@midnight-ntwrk/midnight-js-types';
import { Buffer } from 'buffer';
import type * as pino from 'pino';
import { createContext, type ReactElement, type ReactNode, useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { concatMap, filter, firstValueFrom, interval, map, of, take, tap, throwError, timeout } from 'rxjs';
import { TRANSACTION_TIMEOUT } from '../config/timeouts';

import { useErrorContext } from '../hooks/useErrorContext';

/**
 * This file is really the entrypoint to Midnight for the rest of the UI - it initializes and exposes
 * Midnight.js (or possibly other) DAO API implementation. Most of the contents of this file is:
 *   - Establishing wallet connection through a DApp connector (function `connectToWallet`)
 *   - Initializing Midnight.JS providers (function `prepareProviders`)
 *   - Exposing the API in a form that is easily consumable in a React.js code (function `AppProvider`) - good
 *     examples of using that are the pages `CreateProposal` and `Initialize`
 */

type DispatchActionTypes =
  | { type: typeof Actions.advance }
  | { type: typeof Actions.initProposal; payload: Proposal }
  | { type: typeof Actions.buyIn; payload: { amount: bigint } }
  | { type: typeof Actions.commit; payload: Ballot }
  | { type: typeof Actions.reveal }
  | { type: typeof Actions.cashOut }
  | { type: 'deploy'; payload: DaoConfig }
  | { type: 'join'; payload: ContractAddress };

export interface AppContextTypes {
  state: DaoState | undefined;
  config: DaoConfig;
  deployedContractAddress: ContractAddress | null;
  isClientInitialized: boolean;
  isLoading: boolean;
  dispatch: (action: DispatchActionTypes) => Promise<ActionId | undefined>;
}
export const AppContext = createContext<AppContextTypes | undefined>(undefined);

const prepareProviders = (
  logger: pino.Logger,
  wallet: DAppConnectorWalletAPI,
  uris: ServiceUriConfig,
  config: Config,
): Resource<MidnightJSDaoProviders> => {
  const forWho = 'user';
  return pipe(
    EphemeralStateBloc.init(logger.child({ what: 'Ephemeral state', forWho })),
    Resource.mapAsync(async (ephemeralStateBloc): Promise<MidnightJSDaoProviders> => {
      const instanceLogger = logger.child({ forWho });
      const privateStateStoreName = forWho;
      instanceLogger.trace({ privateStateStoreName }, 'Private state location ready');
      const walletLogger = instanceLogger.child({ what: 'Wallet provider' });
      const walletState = await wallet.state();
      return {
        logging: instanceLogger,
        crypto: webCryptoCryptography(window.crypto),
        privateStateProvider: new SubscribablePrivateStateProviderDecorator(
          instanceLogger.child({
            what: 'Subscribable Private State Decorator',
            storeName: privateStateStoreName,
          }),
          levelPrivateStateProvider({
            midnightDbName: forWho,
            privateStateStoreName,
          }),
        ),
        zkConfigProvider: new FetchZkConfigProvider(window.location.origin, fetch.bind(window)),
        ephemeralState: ephemeralStateBloc,
        proofProvider: httpClientProofProvider(uris.proverServerUri),
        publicDataProvider: indexerPublicDataProvider(uris.indexerUri, uris.indexerWsUri),
        walletProvider: {
          coinPublicKey: walletState.coinPublicKey,
          balanceTx(tx: UnbalancedTransaction, newCoins: CoinInfo[]): Promise<BalancedTransaction> {
            const txId = tx.tx.identifiers()[0];
            return pipe(
              of(tx),
              tap(() => {
                walletLogger.debug(
                  { tx, txId, newCoins: newCoins.map((coin) => ({ value: coin.value, type: coin.type })) },
                  'Balancing transaction',
                );
              }),
              concatMap((unbalanced) => wallet.balanceTransaction(unbalanced.tx, newCoins)),
              tap(() => {
                walletLogger.trace({ txId }, 'Proving transaction');
              }),
              concatMap((txToProve) => wallet.proveTransaction(txToProve)),
              tap(() => {
                walletLogger.trace({ txId }, 'Tx proven');
              }),
              map((proven) => createBalancedTx(Transaction.deserialize(proven.serialize()))),
              timeout({
                first: config.transactionTimeout,
                with: () => throwError(() => new Error('Transaction was not balanced by wallet within 3 minutes')),
              }),
              (x) => firstValueFrom(x),
            );
          },
        },
        midnightProvider: {
          submitTx(tx: BalancedTransaction): Promise<TransactionId> {
            const txId = tx.tx.identifiers()[0];
            return pipe(
              of(tx),
              tap(() => {
                walletLogger.debug({ txId }, 'Submitting transaction');
              }),
              concatMap((balanced) => wallet.submitTransaction(balanced.tx)),
              tap(() => {
                walletLogger.debug({ txId }, 'Transaction submitted');
              }),
              timeout({
                first: config.transactionTimeout,
                with: () => throwError(() => new Error('Transaction was not balanced by wallet within 3 minutes')),
              }),
              (x) => firstValueFrom(x),
            );
          },
        },
      };
    }),
  );
};

/**
 * Connects to wallet using DApp connector
 * It does so through polling, as the script may be injected with a delay.
 * It also checks the exposed API version to ensure wallet provides a compatible one
 * At the end - it collects configuration (location of indexer, node, proving server) from wallet and wallet itself
 * to proceed with further initialization
 */
const connectToWallet = (): Promise<{ wallet: DAppConnectorWalletAPI; uris: ServiceUriConfig }> => {
  const compatibleConnectorAPIVersion = '1.x';
  return pipe(
    interval(100),
    map(() => window.midnight?.mnLace),
    tap((maybeLace) => {
      console.log('Checking Wallet presence...', maybeLace);
    }),
    filter((maybeAPI: DAppConnectorAPI | undefined): maybeAPI is DAppConnectorAPI => maybeAPI !== undefined),
    concatMap((api) =>
      semver.satisfies(api.apiVersion, compatibleConnectorAPIVersion)
        ? of(api)
        : throwError(
            () =>
              new Error(
                `Incompatible wallet version. Expected ${compatibleConnectorAPIVersion}, got ${api.apiVersion}`,
              ),
          ),
    ),
    tap((lace) => {
      console.log('Wallet is present, connecting...', lace);
    }),
    take(1),
    timeout({ first: 1_000, with: () => throwError(() => new Error('Could not find wallet')) }),
    concatMap(async (api) => {
      const isEnabled = await api.isEnabled();
      console.log('Connection status', isEnabled);
      return api;
    }),
    timeout({ first: 5_000, with: () => throwError(() => new Error('Wallet does not respond')) }),
    concatMap(async (api: DAppConnectorAPI) => {
      const wallet = await api.enable();
      console.log('Obtained wallet connection');
      const uris = await api.serviceUriConfig();

      return { wallet, uris };
    }),
    (x) => firstValueFrom(x),
  );
};

const initDaoApiEntryPoint = async (
  walletApi: DAppConnectorWalletAPI,
  uris: ServiceUriConfig,
  config: Config,
  logger: pino.Logger,
): Promise<APIEntrypoint> => {
  const allocatedApi = await pipe(
    prepareProviders(logger, walletApi, uris, config),
    Resource.map((providers) => new APIEntrypoint(providers, config)),
    Resource.allocate,
  );
  return allocatedApi.value;
};

class APIEntrypoint {
  constructor(
    private readonly providers: MidnightJSDaoProviders,
    private readonly config: Config,
  ) {}

  deploy(config: DaoConfig): Promise<DaoMidnightJSAPI> {
    return DaoMidnightJSAPI.deploy(
      'user',
      this.providers,
      { ...this.config, dao: config },
      Buffer.from(this.providers.walletProvider.coinPublicKey, 'hex'),
    );
  }

  join(address: ContractAddress): Promise<DaoMidnightJSAPI> {
    return DaoMidnightJSAPI.join(
      'user',
      this.providers,
      this.config,
      Buffer.from(this.providers.walletProvider.coinPublicKey, 'hex'),
      address,
    );
  }
}

export const AppProvider = ({ children, logger }: { children: ReactNode; logger: pino.Logger }): ReactElement => {
  const [state, setState] = useState<DaoState>();
  const [config, setConfig] = useState<Config & { dao: DaoConfig }>({
    dao: defaultConfig,
    transactionTimeout: TRANSACTION_TIMEOUT,
  });
  const [currentApi, setCurrentApi] = useState<DaoMidnightJSAPI | APIEntrypoint | null>(null);
  const [deployedContractAddress, setDeployedContractAddress] = useState<ContractAddress | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isClientInitialized, setIsClientInitialized] = useState(false);
  const { setErrorMessage } = useErrorContext();

  const navigate = useNavigate();
  const location = useLocation();

  const initDaoAPI = (daoAPI: DaoMidnightJSAPI): void => {
    setCurrentApi(daoAPI);
    daoAPI.config$.subscribe((config) => {
      setConfig({ dao: config, transactionTimeout: TRANSACTION_TIMEOUT });
    });

    daoAPI.state$.subscribe({
      next: (state) => {
        logger.debug('Received next DAO state');
        setState(state);
      },
      error: (error) => {
        logger.error(error);
        if (error instanceof Error) {
          setErrorMessage(error.message);
        } else {
          setErrorMessage('State received an unexpected error.');
        }
      },
    });
  };

  const initContract = async (initFn: () => Promise<DaoMidnightJSAPI>): Promise<undefined> => {
    try {
      setIsLoading(true);
      const daoApi = await initFn();
      initDaoAPI(daoApi);
      navigate('/proposal');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    console.log('Initializing Midnight connection');
    connectToWallet()
      .then(({ wallet, uris }) => initDaoApiEntryPoint(wallet, uris, config, logger))
      .then((apiEntrypoint) => {
        setCurrentApi(apiEntrypoint);
        setIsClientInitialized(true);
      })
      .catch((error) => {
        setErrorMessage('Error while connecting to Wallet: Wallet not found, unresponsive or connection was rejected');
        console.error('error connecting to lace', error);
      });
  }, []);

  useEffect(() => {
    if (state?.actions != null && isLoading) {
      const { latest } = state.actions;

      if (latest != null) {
        const latestAction = state.actions.all[latest];

        if (latestAction.status !== AsyncActionStates.inProgress) {
          setIsLoading(false);

          if (latestAction.status === AsyncActionStates.error) {
            setErrorMessage(latestAction.error);
          }
        }
      } else {
        setIsLoading(false);
      }
    } else {
      setIsLoading(false);
    }

    if (state?.state === States.initialized && location.pathname !== '/proposal') {
      navigate('/proposal');
    }
  }, [state]);

  const dispatch = async (action: DispatchActionTypes): Promise<ActionId | undefined> => {
    // We should do a different context for fish, deploy, and join
    setIsLoading(true);

    try {
      switch (action.type) {
        case Actions.initProposal:
          if (currentApi instanceof DaoMidnightJSAPI) {
            return await currentApi.initProposal(action.payload);
          } else {
            return undefined;
          }
        case Actions.advance:
          if (currentApi instanceof DaoMidnightJSAPI) {
            return await currentApi.advance();
          } else {
            return undefined;
          }
        case Actions.buyIn:
          if (currentApi instanceof DaoMidnightJSAPI) {
            return await currentApi.buyIn(action.payload.amount);
          } else {
            return undefined;
          }
        case Actions.commit:
          if (currentApi instanceof DaoMidnightJSAPI) {
            return await currentApi.voteCommit(action.payload);
          } else {
            return undefined;
          }
        case Actions.reveal:
          if (currentApi instanceof DaoMidnightJSAPI) {
            return await currentApi.voteReveal();
          } else {
            return undefined;
          }
        case Actions.cashOut:
          if (currentApi instanceof DaoMidnightJSAPI) {
            return await currentApi.cashOut();
          } else {
            return undefined;
          }
        case 'deploy':
          if (currentApi instanceof APIEntrypoint) {
            try {
              const result = await currentApi.deploy(action.payload);
              setDeployedContractAddress(result.contract.finalizedDeployTxData.contractAddress);
              return;
            } finally {
              setIsLoading(false);
            }
          } else {
            return undefined;
          }
        case 'join':
          if (currentApi instanceof APIEntrypoint) {
            await initContract(() => currentApi.join(action.payload));
            return;
          } else {
            return undefined;
          }

        default:
          return 'Action type does not exist';
      }
    } catch (error) {
      if (error instanceof Error) {
        console.error(error);
        setErrorMessage(error.message);
      }
    }
  };

  return (
    <AppContext.Provider
      value={{
        state,
        config: config.dao,
        isClientInitialized,
        deployedContractAddress,
        dispatch,
        isLoading,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};
