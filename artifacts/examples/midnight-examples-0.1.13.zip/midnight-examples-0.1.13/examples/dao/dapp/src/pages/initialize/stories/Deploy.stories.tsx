import type { Meta, StoryObj } from '@storybook/react';
import { Deploy } from '../Deploy';

const meta: Meta<typeof Deploy> = {
  component: Deploy,
};

export default meta;
type Story = StoryObj<typeof Deploy>;

/*
 *👇 Render functions are a framework specific feature to allow you control on how the component renders.
 * See https://storybook.js.org/docs/api/csf
 * to learn how to use render functions.
 */
export const Default: Story = {
  args: {
    disabled: false,
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
  },
};
