import { type Voting, VotingStates } from '@midnight-ntwrk/dao-api';
import { type ReactElement } from 'react';
import { Table, TableContainer, TableHead, TableRow, TableBody, Typography, useTheme } from '@mui/material';
import { percentage } from '../../helpers/percentage';

import { BorderedCell } from './BorderedCell';
import { PROPOSAL_PAGE } from '../../locale';

interface ResultsTableProps {
  votingState: Voting;
}

const percent = (value: number): string => {
  const theNr = value === 0 || Number.isNaN(value) ? '0' : value.toFixed(2);
  return `${theNr}%`;
};

export const ResultsTable = ({ votingState }: ResultsTableProps): ReactElement => {
  const theme = useTheme();
  const summary = percentage({ votesYes: votingState.votesYes, votesNo: votingState.votesNo });

  return (
    <TableContainer>
      <Typography variant="h6" fontWeight={600}>
        {PROPOSAL_PAGE.results}
      </Typography>
      <Table sx={{ mt: 1 }} data-test-id="results-table">
        <TableHead data-test-id="results-table-head">
          <TableRow>
            <BorderedCell isBold>Option</BorderedCell>
            <BorderedCell isBold>No. of votes</BorderedCell>
            <BorderedCell isBold>Percentage</BorderedCell>
          </TableRow>
        </TableHead>
        <TableBody data-test-id="results-table-body">
          <TableRow
            sx={{
              backgroundColor: votingState.state === VotingStates.finalCashOut ? theme.palette.success.light : '',
            }}
          >
            <BorderedCell>Yes</BorderedCell>
            <BorderedCell data-test-id="results-table-yes-count">{votingState.votesYes}</BorderedCell>
            <BorderedCell data-test-id="results-table-yes-percentage">
              {percent(summary.shares.votesYes)}
              {votingState.state === VotingStates.finalCashOut && (
                <Typography
                  variant="body1"
                  fontSize={'0.75rem'}
                  color="white"
                  sx={{
                    backgroundColor: '#F77F00',
                    px: 0.5,
                    py: 0.2,
                    borderRadius: 1,
                    display: 'inline-block',
                    float: 'right',
                  }}
                >
                  {PROPOSAL_PAGE.awaitingClaim}
                </Typography>
              )}
            </BorderedCell>
          </TableRow>
          <TableRow
            sx={{
              backgroundColor: votingState.state === VotingStates.finalNegative ? theme.palette.error.light : '',
            }}
          >
            <BorderedCell>No</BorderedCell>
            <BorderedCell data-test-id="results-table-no-count">{votingState.votesNo}</BorderedCell>
            <BorderedCell data-test-id="results-table-no-percentage">{percent(summary.shares.votesNo)}</BorderedCell>
          </TableRow>
        </TableBody>
      </Table>
    </TableContainer>
  );
};
