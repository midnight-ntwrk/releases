import type { ReactElement } from 'react';
import { Typography } from '@mui/material';
import { type VotingState, VotingStates } from '@midnight-ntwrk/dao-api';

import { PROPOSAL_PAGE } from '../../locale';

interface ProposalDetailsProps {
  state: VotingState;
  beneficiary: string | undefined;
}

interface MaskedState {
  title: string;
  backgroundColor: string;
}

const maskState = (state: VotingState): MaskedState => {
  switch (state) {
    case VotingStates.commit:
      return {
        title: 'Commit',
        backgroundColor: '#85CB33',
      };
    case VotingStates.reveal:
      return {
        title: 'Reveal',
        backgroundColor: '#F77F00',
      };
    case VotingStates.finalCashOut:
    case VotingStates.finalNegative:
      return {
        title: 'Ended',
        backgroundColor: '#D62828',
      };
    default:
      return {
        title: '',
        backgroundColor: '',
      };
  }
};

export const ProposalDetails = ({ state, beneficiary }: ProposalDetailsProps): ReactElement => {
  const maskedState = maskState(state);

  return (
    <>
      <Typography
        variant="body1"
        component="h6"
        sx={{ mb: 1, display: 'flex', alignItems: 'center' }}
        data-test-id="proposal-state"
      >
        <Typography sx={{ mr: 0.5 }} fontWeight={600}>
          {PROPOSAL_PAGE.currentPhase}
        </Typography>
        <Typography
          sx={{
            backgroundColor: maskedState.backgroundColor,
            color: '#ffffff',
            px: 1,
            fontSize: 15,
            borderRadius: 0.8,
          }}
        >
          {maskedState.title}
        </Typography>
      </Typography>
      <Typography
        variant="body1"
        component="h6"
        sx={{ mb: 1, display: 'flex', alignItems: 'center' }}
        data-test-id="proposal-beneficiary"
      >
        <Typography sx={{ mr: 0.5 }} fontWeight={600}>
          {PROPOSAL_PAGE.beneficiary}
        </Typography>
        <Typography sx={{ overflowWrap: 'anywhere' }}>{beneficiary}</Typography>
      </Typography>
    </>
  );
};
