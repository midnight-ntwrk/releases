import { type DaoConfig } from '@midnight-ntwrk/dao-api';
import { Box, Button, FormControl, Grid, InputLabel, TextField, Typography } from '@mui/material';
import React, { type ReactElement, useEffect, useState } from 'react';
import { useAlertContext } from '../../hooks';
import { PROPOSAL_PAGE } from '../../locale';
import { TDUST } from '../../TDUST';

export const BuyIn = (props: {
  onBuyIn: (data: { amount: bigint }) => void;
  config: DaoConfig;
  tokenType: string;
}): ReactElement => {
  const { askForConfirmation } = useAlertContext();
  const [amountValueRaw, setAmountValueRaw] = useState<string>('1');
  const [amount, setAmount] = useState<{ error: false; value: bigint } | { error: true; message: string }>({
    error: false,
    value: 1n,
  });

  useEffect(() => {
    try {
      const parsed = BigInt(amountValueRaw);
      if (parsed < 1) {
        setAmount({
          error: true,
          message: PROPOSAL_PAGE.buyInAmountError,
        });
      } else {
        setAmount({
          error: false,
          value: parsed,
        });
      }
    } catch (e) {
      setAmount({ error: true, message: PROPOSAL_PAGE.buyInAmountError });
    }
  }, [amountValueRaw]);

  return (
    <Box
      component="form"
      onSubmit={(ev) => {
        ev.preventDefault();
        askForConfirmation({
          title: PROPOSAL_PAGE.buyInConfirmationTitle,
          callback: (confirmed: boolean) => {
            if (confirmed && !amount.error) {
              props.onBuyIn({ amount: BigInt(amount.value) });
            }
          },
        });
      }}
    >
      <Typography variant="h6" gutterBottom={true}>
        {PROPOSAL_PAGE.buyInHeader}
      </Typography>
      <Typography gutterBottom={true}>{PROPOSAL_PAGE.buyInDescription(props.tokenType)}</Typography>
      <Grid container direction="row" alignItems={'center'} spacing={2}>
        <Grid item>
          <FormControl>
            <InputLabel htmlFor="buyin-amount"></InputLabel>
            <TextField
              label={PROPOSAL_PAGE.buyInAmount}
              id="buyin-amount"
              inputMode="numeric"
              error={amount.error}
              helperText={amount.error ? amount.message : null}
              value={amountValueRaw}
              onChange={(ev) => {
                setAmountValueRaw(ev.target.value);
              }}
            />
          </FormControl>
        </Grid>
        <Grid item>
          <Button
            variant="contained"
            type="submit"
            sx={{ px: 3, mr: 2 }}
            data-testid="buy-in-button"
            disableElevation
            disabled={amount.error}
          >
            {PROPOSAL_PAGE.buyInButton(
              TDUST.fromAtomsBigInt(BigInt(props.config.buyInCoins) * (amount.error ? 1n : amount.value)),
            )}
          </Button>
        </Grid>
      </Grid>
    </Box>
  );
};
