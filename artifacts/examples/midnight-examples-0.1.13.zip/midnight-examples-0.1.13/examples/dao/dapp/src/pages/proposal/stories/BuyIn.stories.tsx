import { sampleTokenType } from '@midnight-ntwrk/compact-runtime';
import { defaultConfig } from '@midnight-ntwrk/dao-contract';
import type { Meta, StoryObj } from '@storybook/react';
import { BuyIn } from '../BuyIn';

const meta: Meta<typeof BuyIn> = {
  component: BuyIn,
};

export default meta;
type Story = StoryObj<typeof BuyIn>;

/*
 *👇 Render functions are a framework specific feature to allow you control on how the component renders.
 * See https://storybook.js.org/docs/api/csf
 * to learn how to use render functions.
 */
export const Default: Story = {
  args: {
    config: defaultConfig,
    tokenType: sampleTokenType(),
  },
};
