import { test, expect } from '@playwright/experimental-ct-react';
import { ErrorNotification } from './ErrorNotification';

test.describe('Error Notification component tests', () => {
  const message = 'Error Message';

  test('Error Notification test', async ({ mount, page }) => {
    const errorMessage = page.locator('[role="presentation"]');

    const component = await mount(<ErrorNotification errorMessage={message} clearErrorMessage={() => undefined} />);

    await expect(component).toBeEnabled();

    await expect(errorMessage).toHaveText(message);
  });
});
