import BigNumber from 'bignumber.js';

export class InvalidTDUSTInput extends Error {
  constructor(public readonly input: string) {
    super(`Could not parse ${input} to ${TDUST.SYMBOL}`);
  }
}
export class TDUST {
  static readonly #BN = BigNumber.clone({ DECIMAL_PLACES: 6 });

  static ONE = TDUST.fromAtomsNumber(10 ** 6);
  static SYMBOL = 'tDUST';

  static fromAtomsNumber(numberOfTokens: number): TDUST {
    return new TDUST(TDUST.#BN(numberOfTokens));
  }

  static fromAtomsBigInt(numberOfTokens: bigint): TDUST {
    return new TDUST(TDUST.#BN(numberOfTokens.toString(10)));
  }

  static fromString(amountOfTDUST: string): TDUST {
    const parsed = TDUST.#BN(amountOfTDUST, 10).times(TDUST.ONE.tokens).integerValue();
    if (parsed.isNaN() || !parsed.isInteger()) {
      throw new InvalidTDUSTInput(amountOfTDUST);
    }
    return new TDUST(parsed);
  }

  constructor(public readonly tokens: BigNumber) {}

  toNumberOfAtoms(): number {
    return this.tokens.toNumber();
  }

  toString(): string {
    const value = this.tokens.dividedBy(TDUST.ONE.tokens).toFixed(2);
    return `${value}${TDUST.SYMBOL}`;
  }
}
