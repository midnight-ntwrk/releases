import { type ReactElement } from 'react';
import { Typography, Divider } from '@mui/material';

interface HeadingProps {
  title: string | undefined;
  testId?: string;
}

export const Heading = ({ title, testId }: HeadingProps): ReactElement => {
  return (
    <>
      <Typography variant="h5" fontWeight={600} sx={{ mb: 3 }} data-testid={testId}>
        {title}
      </Typography>
      <Divider sx={{ mb: 3 }} />
    </>
  );
};
