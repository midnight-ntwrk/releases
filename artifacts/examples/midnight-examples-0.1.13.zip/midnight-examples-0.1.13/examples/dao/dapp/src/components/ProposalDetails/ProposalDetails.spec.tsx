import { test, expect } from '@playwright/experimental-ct-react';
import { ProposalDetails } from './ProposalDetails';

test.describe('Proposal Details component tests', () => {
  const PHASE_TITLE = 'Current phase:';
  const STATE_COMMIT = 'commit';
  const STATE_CASHOUT = 'final_cash_out';
  const STATE_NEGATIVE = 'final_negative';
  const STATE_REVEAL = 'reveal';
  const BENEFICIARY_TITLE = 'Beneficiary:';
  const BENEFICIARY_VALUE = '0x000000000000000001';

  test('Current pase == *Commit* test', async ({ mount, page }) => {
    const phaseTitle = page.locator('[data-test-id="proposal-state"] p:nth-child(1)');
    const phaseState = page.locator('[data-test-id="proposal-state"] p:nth-child(2)');
    const beneficiaryTitle = page.locator('[data-test-id="proposal-beneficiary"] p:nth-child(1)');
    const beneficiaryValue = page.locator('[data-test-id="proposal-beneficiary"] p:nth-child(2)');

    const component = await mount(<ProposalDetails state={STATE_COMMIT} beneficiary={BENEFICIARY_VALUE} />);

    await expect(component).toBeEnabled();

    await expect(phaseTitle).toHaveText(PHASE_TITLE);
    await expect(phaseState).toHaveText('Commit');
    await expect(phaseState).toHaveCSS('background-color', 'rgb(133, 203, 51)');

    await expect(beneficiaryTitle).toHaveText(BENEFICIARY_TITLE);
    await expect(beneficiaryValue).toHaveText(BENEFICIARY_VALUE);
  });

  test('Current pase == *final_cash_out* test', async ({ mount, page }) => {
    const phaseTitle = page.locator('[data-test-id="proposal-state"] p:nth-child(1)');
    const phaseState = page.locator('[data-test-id="proposal-state"] p:nth-child(2)');
    const beneficiaryTitle = page.locator('[data-test-id="proposal-beneficiary"] p:nth-child(1)');
    const beneficiaryValue = page.locator('[data-test-id="proposal-beneficiary"] p:nth-child(2)');

    const component = await mount(<ProposalDetails state={STATE_CASHOUT} beneficiary={BENEFICIARY_VALUE} />);

    await expect(component).toBeEnabled();

    await expect(phaseTitle).toHaveText(PHASE_TITLE);
    await expect(phaseState).toHaveText('Ended');
    await expect(phaseState).toHaveCSS('background-color', 'rgb(214, 40, 40)');

    await expect(beneficiaryTitle).toHaveText(BENEFICIARY_TITLE);
    await expect(beneficiaryValue).toHaveText(BENEFICIARY_VALUE);
  });

  test('Current pase == *final_negative* test', async ({ mount, page }) => {
    const phaseTitle = page.locator('[data-test-id="proposal-state"] p:nth-child(1)');
    const phaseState = page.locator('[data-test-id="proposal-state"] p:nth-child(2)');
    const beneficiaryTitle = page.locator('[data-test-id="proposal-beneficiary"] p:nth-child(1)');
    const beneficiaryValue = page.locator('[data-test-id="proposal-beneficiary"] p:nth-child(2)');

    const component = await mount(<ProposalDetails state={STATE_NEGATIVE} beneficiary={BENEFICIARY_VALUE} />);

    await expect(component).toBeEnabled();

    await expect(phaseTitle).toHaveText(PHASE_TITLE);
    await expect(phaseState).toHaveText('Ended');
    await expect(phaseState).toHaveCSS('background-color', 'rgb(214, 40, 40)');

    await expect(beneficiaryTitle).toHaveText(BENEFICIARY_TITLE);
    await expect(beneficiaryValue).toHaveText(BENEFICIARY_VALUE);
  });

  test('Current pase == *reveal* test', async ({ mount, page }) => {
    const phaseTitle = page.locator('[data-test-id="proposal-state"] p:nth-child(1)');
    const phaseState = page.locator('[data-test-id="proposal-state"] p:nth-child(2)');
    const beneficiaryTitle = page.locator('[data-test-id="proposal-beneficiary"] p:nth-child(1)');
    const beneficiaryValue = page.locator('[data-test-id="proposal-beneficiary"] p:nth-child(2)');

    const component = await mount(<ProposalDetails state={STATE_REVEAL} beneficiary={BENEFICIARY_VALUE} />);

    await expect(component).toBeEnabled();

    await expect(phaseTitle).toHaveText(PHASE_TITLE);
    await expect(phaseState).toHaveText('Reveal');
    await expect(phaseState).toHaveCSS('background-color', 'rgb(247, 127, 0)');

    await expect(beneficiaryTitle).toHaveText(BENEFICIARY_TITLE);
    await expect(beneficiaryValue).toHaveText(BENEFICIARY_VALUE);
  });
});
