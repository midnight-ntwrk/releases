import { type ReactElement, useEffect } from 'react';
import { FormControlLabel, Radio, RadioGroup, Typography } from '@mui/material';

interface VotingFormProps {
  title: string;
  vote: string;
  handleChange: (vote: string) => void;
}

export const VotingForm = ({ title, vote, handleChange }: VotingFormProps): ReactElement => {
  useEffect(() => {
    return () => {
      handleChange('');
    }; // Reset voting state on unmount in case there's another proposal
  }, []);

  return (
    <>
      <Typography variant="body1" fontWeight={600}>
        {title}
      </Typography>
      <RadioGroup
        name="vote"
        value={vote}
        onChange={(event, vote) => {
          handleChange(vote);
        }}
        data-test-id="proposal-vote-radio"
        sx={{ mb: 1, display: 'inline-flex' }}
      >
        <FormControlLabel value="yes" control={<Radio />} label="Approve" />
        <FormControlLabel value="no" control={<Radio />} label="Disapprove" />
      </RadioGroup>
    </>
  );
};
