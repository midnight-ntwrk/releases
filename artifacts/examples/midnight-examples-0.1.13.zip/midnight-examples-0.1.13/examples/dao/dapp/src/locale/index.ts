import { TDUST } from '../TDUST';

export const INITIALIZE_PAGE = {
  deploy: 'Deploy new contract',
  buyInDust: `Amount of ${TDUST.SYMBOL} needed to buy voting token`,
  seedDust: `Amount of ${TDUST.SYMBOL} needed to fund a proposal`,
  address: 'Contract address to join',
  join: 'Join',
};

export const PROPOSALS_PAGE = {
  noProposal: "Let's get started by creating a new proposal",
  createButton: 'Create proposal',
  noProposalVoter: 'Waiting for the organizer to start the proposal.',
};

export const PROPOSAL_PAGE = {
  currentPhase: 'Current phase:',
  beneficiary: 'Beneficiary:',
  createdBy: 'Created by',
  winningAddress: 'Winning (Yes) address:',
  stats: 'Stats',
  pot: 'Pot Size',
  fundingDst: `Funding ${TDUST.SYMBOL}`,
  seedFunding: 'Seed funding',
  voterFunds: 'Voter funds',
  total: 'Total',
  commit: 'Commits',
  reveal: 'Reveals',
  buyInHeader: 'Buy-in',
  buyInAmount: 'Amount',
  buyInButton: (amount: TDUST) => `Buy-in for ${amount.toString()}`,
  buyInDescription: (type: string) =>
    `You can buy tokens, which allow you to vote on proposals in this DAO. When bought, the tokens of type ${type} will appear in your wallet. One token represents a right to vote on one proposal and will be deducted from your balance when committing to a vote.`,
  buyInAmountError: 'Amount of tokens you buy needs to be a positive integer',
  commitButton: 'Commit Vote',
  revealVoteButton: 'Reveal Vote',
  revealButton: 'Progress to Reveal',
  endProposalButton: 'End Proposal',
  cashOutButton: 'Cash Out',
  cashOutTitle: 'Congratulations! The majority of voters have voted to pass this proposal.',
  cashOutText: 'You can now cash out the pot using the button below.',
  castVote: 'Cast your vote',
  results: 'Results',
  awaitingClaim: 'Awaiting Claim',
  advanceConfirmationTitle: 'Do you really want to advance?',
  buyInConfirmationTitle: 'Do you really want to buy in?',
  revealVoteConfirmationTitle: 'Do you really want to reveal your vote?',
  commitVoteConfirmationTitle: 'Do you really want to commit your vote?',
  cashOutConfirmationTitle: 'Do you really want to cash out?',
};

export const CREATE_PROPOSAL = {
  pageTitle: 'New Proposal',
  titleLabel: 'Title',
  questionLabel: 'Proposed question',
  beneficiary: 'Beneficiary Address',
  fundingLabel: 'Seed Funding Cost:',
  cancel: 'Cancel',
  publish: 'Publish',
  dialogTitle: 'Do you want to publish this proposal?',
  dialogText: (amount: TDUST) => `Publishing will cost you ${amount.toString()}, which will be the seed fund.`,
  loaderTitle: 'Please sign the Transaction in your wallet',
};

export const HEADER = {
  connectedTo: 'Connected to:',
  logoTitle: 'Micro DAO',
};

export const MISC = {
  yes: 'Yes',
  no: 'No',
  pleaseWait: 'Please wait',
};

export const TDUST_INPUT = {
  amountError: 'Please enter a non-negative amount of tDUST',
};
