import { type DaoConfig } from '@midnight-ntwrk/dao-api';
import { Box, Button, TextField, Typography } from '@mui/material';
import { type ReactElement, useEffect, useState } from 'react';
import { useAlertContext, useAppContext } from '../../hooks';
import { INITIALIZE_PAGE } from '../../locale';
import { Deploy } from './Deploy';

export const Initialize = (): ReactElement => {
  const [joinAddress, setJoinAddress] = useState<string | null>(null);
  const [joinAddressFocus, setJoinAddressFocus] = useState(false);
  const { dispatch, deployedContractAddress } = useAppContext();
  const { askForConfirmation } = useAlertContext();

  useEffect(() => {
    if (joinAddress == null && deployedContractAddress != null) {
      setJoinAddress(deployedContractAddress);
    }
  }, [joinAddress, deployedContractAddress]);

  const handleDeploy = async (config: DaoConfig): Promise<void> => {
    await dispatch({ type: 'deploy', payload: config });
  };

  const handleJoin = (): void => {
    if (joinAddress == null || joinAddress === '') {
      return undefined;
    }

    askForConfirmation({
      title: 'Join',
      text: 'Do you want to join an existing contract?',
      callback: async () => {
        await dispatch({ type: 'join', payload: joinAddress });
      },
    });
  };

  return (
    <>
      <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', gap: 2 }}>
        <Box>
          <TextField
            id="initialize-address-input"
            data-testid="initialize-address-input"
            label={INITIALIZE_PAGE.address}
            fullWidth
            value={joinAddress}
            focused={joinAddressFocus || (joinAddress != null && joinAddress.length > 0)}
            onChange={(e) => {
              setJoinAddress(e.target.value);
            }}
            onFocus={() => {
              setJoinAddressFocus(true);
            }}
            onBlur={() => {
              setJoinAddressFocus(false);
            }}
            required
          />
        </Box>
        <Box sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'flex-start' }}>
          <Button
            variant="contained"
            sx={{ px: 3, mr: 2 }}
            onClick={() => {
              handleJoin();
            }}
            disabled={joinAddress == null || joinAddress === ''}
          >
            {INITIALIZE_PAGE.join}
          </Button>
          <Deploy onSubmit={handleDeploy} disabled={deployedContractAddress != null} />
        </Box>
        <Box>
          {deployedContractAddress != null && (
            <Typography variant="body1">Deployed contract address: {deployedContractAddress}</Typography>
          )}
        </Box>
      </Box>
    </>
  );
};
