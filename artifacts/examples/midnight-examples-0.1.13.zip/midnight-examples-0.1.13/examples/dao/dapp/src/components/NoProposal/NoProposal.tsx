import { type ReactElement, type MouseEvent } from 'react';
import { Box, Button, CircularProgress, Typography } from '@mui/material';
import { Heading } from '../Heading';

interface NoProposalProps {
  isOrganizer: boolean;
  title: string;
  buttonTitle: string;
  handleButtonClick: (event: MouseEvent<HTMLButtonElement>) => void;
}

export const NoProposal = ({ isOrganizer, title, buttonTitle, handleButtonClick }: NoProposalProps): ReactElement => (
  <Box
    data-testid="noproposal"
    sx={
      !isOrganizer
        ? { display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', height: '70vh' }
        : {}
    }
  >
    {isOrganizer ? (
      <>
        <Heading title={title} testId="noproposal-title" />
        <Button
          variant="contained"
          sx={{ px: 5 }}
          color="success"
          onClick={handleButtonClick}
          data-testid="noproposal-create-button"
        >
          {buttonTitle}
        </Button>
      </>
    ) : (
      <>
        <CircularProgress color="primary" data-testid="noproposal-loader" sx={{ mb: 4 }} />
        <Typography variant="h5" data-testid="noproposal-title">
          {title}
        </Typography>
      </>
    )}
  </Box>
);
