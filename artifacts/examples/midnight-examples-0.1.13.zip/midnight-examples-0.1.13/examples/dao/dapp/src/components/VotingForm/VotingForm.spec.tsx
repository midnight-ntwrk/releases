import { test, expect } from '@playwright/experimental-ct-react';
import { VotingForm } from './VotingForm';

test.describe('Voting Form component tests', () => {
  const title = 'Voting Form Title';
  const voteYes = 'yes';
  const voteNo = 'no';

  test('Default Form test', async ({ mount, page }) => {
    const radioGroup = page.locator('[data-test-id="proposal-vote-radio"]');
    const radioYes = page.locator('[value="yes"]');
    const radioYesLabel = page.locator('[data-test-id="proposal-vote-radio"] label:nth-child(1)');
    const radioNo = page.locator('[value="no"]');
    const radioNoLabel = page.locator('[data-test-id="proposal-vote-radio"] label:nth-child(2)');

    const component = await mount(<VotingForm title={title} vote="" handleChange={() => undefined} />);

    await expect(component).toBeEnabled();
    await expect(component).toContainText(title);

    await expect(radioGroup).toBeVisible();

    await expect(radioYes).toBeVisible();
    await expect(radioYes).not.toBeChecked();
    await expect(radioYesLabel).toHaveText('Approve');

    await expect(radioNo).toBeVisible();
    await expect(radioNo).not.toBeChecked();
    await expect(radioNoLabel).toHaveText('Disapprove');
  });

  test('*Yes* option selected test', async ({ mount, page }) => {
    const radioYes = page.locator('[value="yes"]');
    const radioNo = page.locator('[value="no"]');

    const component = await mount(<VotingForm title={title} vote={voteYes} handleChange={() => undefined} />);

    await expect(component).toBeEnabled();

    await expect(radioYes).toBeChecked();
    await expect(radioNo).not.toBeChecked();
  });

  test('*No* option selected test', async ({ mount, page }) => {
    const radioYes = page.locator('[value="yes"]');
    const radioNo = page.locator('[value="no"]');

    const component = await mount(<VotingForm title={title} vote={voteNo} handleChange={() => undefined} />);

    await expect(component).toBeEnabled();

    await expect(radioYes).not.toBeChecked();
    await expect(radioNo).toBeChecked();
  });
});
