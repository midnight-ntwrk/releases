import { type ChangeEvent, type ReactElement, useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Divider, Typography, TextField, Button } from '@mui/material';
import { Actions } from '@midnight-ntwrk/dao-api';

import { CREATE_PROPOSAL } from '../../locale';
import { Heading } from '../../components';
import { useAlertContext, useAppContext } from '../../hooks';
import { TDUST } from '../../TDUST';

interface ProposalForm {
  topic: string;
  beneficiary: string;
}

export const CreateProposal = (): ReactElement => {
  const navigate = useNavigate();
  const { dispatch, config } = useAppContext();
  const { askForConfirmation } = useAlertContext();

  const [proposalForm, setProposalForm] = useState<ProposalForm>({
    topic: '',
    beneficiary: '',
  });

  const handleInputChange = (event: ChangeEvent<HTMLInputElement>): void => {
    const { id, value } = event.target;

    setProposalForm({ ...proposalForm, [id]: value });
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>): void => {
    event.preventDefault();

    askForConfirmation({
      title: CREATE_PROPOSAL.dialogTitle,
      text: CREATE_PROPOSAL.dialogText(TDUST.fromAtomsNumber(config.seedCoins)),
      callback: async (confirmed) => {
        if (confirmed) {
          const { topic, beneficiary } = proposalForm;

          await dispatch({
            type: Actions.initProposal,
            payload: {
              topic,
              beneficiary,
            },
          });
        }
      },
    });
  };

  return (
    <>
      <Box component="form" onSubmit={handleSubmit}>
        <Heading title={CREATE_PROPOSAL.pageTitle} data-testId="createproposal-title" />
        <TextField
          sx={{ mb: 5 }}
          id="topic"
          data-testid="createproposal-title-input"
          label={CREATE_PROPOSAL.titleLabel}
          fullWidth
          value={proposalForm.topic}
          onChange={handleInputChange}
          required
        />
        <TextField
          sx={{ mb: 3 }}
          id="beneficiary"
          data-testid="createproposal-address-input"
          label={CREATE_PROPOSAL.beneficiary}
          fullWidth
          value={proposalForm.beneficiary}
          onChange={handleInputChange}
          required
        />
        <Typography variant="h6" data-testid="createproposal-funding-field" sx={{ mb: 3, display: 'flex' }}>
          <Typography variant="body1" fontWeight={600} sx={{ mr: 0.5 }}>
            {CREATE_PROPOSAL.fundingLabel}
          </Typography>
          <Typography variant="body1">{TDUST.fromAtomsNumber(config.seedCoins).toString()}</Typography>
        </Typography>
        <Divider sx={{ mb: 4 }} />
        <Box sx={{ display: 'flex', justifyContent: 'end' }}>
          <Button
            variant="contained"
            data-testid="createproposal-cancel-button"
            sx={{ px: 3, mr: 2 }}
            disableElevation
            onClick={() => {
              navigate('/proposal');
            }}
          >
            {CREATE_PROPOSAL.cancel}
          </Button>
          <Button
            variant="contained"
            data-testid="createproposal-publish-button"
            color="success"
            sx={{ px: 3 }}
            disableElevation
            type="submit"
          >
            {CREATE_PROPOSAL.publish}
          </Button>
        </Box>
      </Box>
    </>
  );
};
