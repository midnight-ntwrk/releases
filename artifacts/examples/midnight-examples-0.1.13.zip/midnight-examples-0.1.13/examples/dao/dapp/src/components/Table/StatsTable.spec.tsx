import { test, expect } from '@playwright/experimental-ct-react';
import { StatsTable } from './StatsTable';

test.describe('Stats Table component tests', () => {
  const tableTitle = 'Stats Table Title';
  const cellTitle = 'Cell Title';
  const cellValue = 'Value';

  test('Stats Table test', async ({ mount, page }) => {
    const title = page.locator('h6');
    const cell1 = page.locator('[data-test-id="votes-table-body"] td:nth-child(1)');
    const cell2 = page.locator('[data-test-id="votes-table-body"] td:nth-child(2)');

    const component = await mount(<StatsTable title={tableTitle} data={[{ title: cellTitle, value: cellValue }]} />);

    await expect(component).toBeEnabled();

    await expect(title).toHaveText(tableTitle);
    await expect(cell1).toHaveText(cellTitle);
    await expect(cell2).toHaveText(cellValue);
  });
});
