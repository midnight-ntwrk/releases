export const percentage = <T extends Record<string, number>>(input: T): { total: number; shares: T } => {
  const entries = Object.entries(input);
  const allEntriesValid = entries.every(([, value]) => Number.isFinite(value) && value >= 0);
  const sum = entries.reduce((acc, [, value]) => acc + value, 0);
  const results = entries.map(([key, value]) => {
    const result = allEntriesValid && sum > 0 ? (100 * value) / sum : NaN;
    return [key, result];
  });
  const shares = Object.fromEntries(results) as T;
  return {
    total: allEntriesValid ? sum : NaN,
    shares,
  };
};
