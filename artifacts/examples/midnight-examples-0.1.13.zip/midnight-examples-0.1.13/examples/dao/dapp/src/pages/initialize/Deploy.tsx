import { type DaoConfig } from '@midnight-ntwrk/dao-api';
import CloseIcon from '@mui/icons-material/Close';
import { Button, Grid, IconButton } from '@mui/material';
import React, { type ReactElement, useEffect, useState } from 'react';
import { type AmountOrError, TDUSTInput } from '../../components/TDUSTInput/TDUSTInput';
import { useAlertContext, useErrorContext } from '../../hooks';
import { INITIALIZE_PAGE } from '../../locale';

type State = 'open' | 'closed';
type CollectedConfig = {
  [K in keyof DaoConfig]: AmountOrError;
};
const collectedToConfig = (input: CollectedConfig): DaoConfig => {
  const collectValue = (key: keyof DaoConfig): number => {
    const value = input[key];
    if (value.error) {
      throw new Error(`${key} error: ${value.message}`);
    } else {
      return value.value.toNumberOfAtoms();
    }
  };
  const seedCoins = collectValue('seedCoins');
  const buyInCoins = collectValue('buyInCoins');

  return {
    seedCoins,
    buyInCoins,
  };
};

export const Deploy = (props: { onSubmit: (config: DaoConfig) => void; disabled: boolean }): ReactElement => {
  const { askForConfirmation } = useAlertContext();
  const { setErrorMessage } = useErrorContext();
  const [state, setState] = useState<State>('closed');
  const [internalDisabled, setInternalDisabled] = useState(false);
  const [collectedConfig, setCollectedConfig] = useState<CollectedConfig>({
    seedCoins: { error: true, message: '' },
    buyInCoins: { error: true, message: '' },
  });

  useEffect(() => {
    try {
      collectedToConfig(collectedConfig);
      setInternalDisabled(false);
    } catch (e) {
      setInternalDisabled(true);
    }
  }, [collectedConfig]);

  const doSubmit = (): void => {
    try {
      const config = collectedToConfig(collectedConfig);
      askForConfirmation({
        title: 'Deploy',
        text: 'Do you want to deploy the contract?',
        callback: (confirmed: boolean) => {
          if (confirmed) {
            props.onSubmit(config);
          }
        },
      });
    } catch (e) {
      setErrorMessage(e instanceof Error ? e.message : 'Could not prepare deployment');
    }
  };

  switch (state) {
    case 'closed':
      return (
        <Button
          variant="contained"
          sx={{ px: 3, mr: 2 }}
          disabled={props.disabled}
          onClick={() => {
            setState('open');
          }}
        >
          {INITIALIZE_PAGE.deploy}
        </Button>
      );
    case 'open':
      return (
        <Grid
          container
          spacing={2}
          direction="row"
          alignItems="baseline"
          component="form"
          onSubmit={(ev) => {
            ev.preventDefault();
            doSubmit();
          }}
        >
          <Grid item>
            <IconButton
              onClick={() => {
                setState('closed');
              }}
            >
              <CloseIcon />
            </IconButton>
          </Grid>
          <Grid item xs={3}>
            <Grid container direction="column" spacing={2} justifyContent="stretch">
              <Grid item>
                <TDUSTInput
                  label={INITIALIZE_PAGE.seedDust}
                  id="initialize-seed-tdust-input"
                  onChange={(amount) => {
                    setCollectedConfig((prev) => ({ ...prev, seedCoins: amount }));
                  }}
                />
              </Grid>
              <Grid item>
                <TDUSTInput
                  label={INITIALIZE_PAGE.buyInDust}
                  id="initialize-buy-in-tdust-input"
                  onChange={(amount) => {
                    setCollectedConfig((prev) => ({ ...prev, buyInCoins: amount }));
                  }}
                />
              </Grid>
            </Grid>
          </Grid>
          <Grid item>
            <Button
              variant="contained"
              type="submit"
              sx={{ px: 3, mr: 2 }}
              disabled={props.disabled || internalDisabled}
            >
              {INITIALIZE_PAGE.deploy}
            </Button>
          </Grid>
        </Grid>
      );
  }
};
