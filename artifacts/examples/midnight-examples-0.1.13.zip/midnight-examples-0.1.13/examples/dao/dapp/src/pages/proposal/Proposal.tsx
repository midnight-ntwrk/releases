import { type ReactElement, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BeneficiaryStates,
  OrganizerStates,
  VotingStates,
  States,
  VoterStates,
  Actions,
  type Voting,
} from '@midnight-ntwrk/dao-api';
import { Button, Divider, Grid, Typography } from '@mui/material';
import { ResultsTable, StatsTable, NoProposal, ProposalDetails, Heading, VotingForm } from '../../components';

import { useAlertContext, useAppContext } from '../../hooks';
import { PROPOSAL_PAGE, PROPOSALS_PAGE } from '../../locale';
import { TDUST } from '../../TDUST';
import { BuyIn } from './BuyIn';

export const Proposal = (): ReactElement | null => {
  const { state, config, isLoading, dispatch } = useAppContext();
  const { askForConfirmation } = useAlertContext();
  const navigate = useNavigate();
  const [vote, setVote] = useState('');

  if (isLoading && (state == null || state.state === States.setup)) {
    return null;
  }

  let votingState: Voting | undefined;
  let beneficiaryState;

  if (state != null && state.state === States.initialized) {
    votingState = state.voting;
    beneficiaryState = state.beneficiary;
  }

  const isOrganizer = state?.organizer?.state !== OrganizerStates.notAnOrganizer;
  const isFinalStage =
    votingState?.state === VotingStates.finalNegative || votingState?.state === VotingStates.finalCashOut;

  const isBeneficiary = beneficiaryState?.state !== BeneficiaryStates.notBeneficiary;
  const beneficiaryCanCashOut = beneficiaryState?.state === BeneficiaryStates.finalCanCashOut;

  return (
    <>
      {votingState == null || state == null ? (
        <NoProposal
          title={isOrganizer ? PROPOSALS_PAGE.noProposal : PROPOSALS_PAGE.noProposalVoter}
          buttonTitle={PROPOSALS_PAGE.createButton}
          isOrganizer={isOrganizer}
          handleButtonClick={() => {
            navigate('/proposal/create');
          }}
        />
      ) : (
        <>
          <Heading title={votingState.proposal?.topic} />
          <Grid container alignItems="flex-start" spacing={5}>
            <Grid container item sx={{ flexDirection: 'column' }} data-test-id="proposal-page">
              <Grid item>
                <ProposalDetails state={votingState?.state} beneficiary={votingState?.proposal.beneficiary} />
              </Grid>

              {isOrganizer || (!isOrganizer && isFinalStage) ? (
                <Grid item xs={12} md={8} lg={6} xl={4}>
                  <StatsTable
                    title={PROPOSAL_PAGE.stats}
                    data={[
                      {
                        title: PROPOSAL_PAGE.commit,
                        value: votingState.committed,
                      },
                      {
                        title: PROPOSAL_PAGE.reveal,
                        value: votingState.revealed,
                      },
                      {
                        title: PROPOSAL_PAGE.pot,
                        value: TDUST.fromAtomsNumber(state.pot ?? 0).toString(),
                      },
                    ]}
                  />
                </Grid>
              ) : null}

              <Grid container item sx={{ mt: 2, display: 'flex', flexDirection: 'column' }}>
                <Divider sx={{ mb: 4 }} />
                {!isOrganizer && state.voter.state === VoterStates.canCommit && (
                  <Grid item sx={{ mb: 2 }}>
                    <BuyIn
                      onBuyIn={(data) => {
                        void dispatch({
                          type: Actions.buyIn,
                          payload: data,
                        });
                      }}
                      config={config}
                      tokenType={state.tokenType}
                    />
                    <VotingForm
                      title={`${PROPOSAL_PAGE.castVote}:`}
                      vote={vote}
                      handleChange={(value) => {
                        setVote(value);
                      }}
                    />
                  </Grid>
                )}

                <Grid item>
                  {isOrganizer ? (
                    state.organizer.state === OrganizerStates.canAdvance && (
                      <Button
                        variant="contained"
                        sx={{ px: 3, mb: isFinalStage ? 3 : 0 }}
                        data-testid={`${votingState.state}-button`}
                        disableElevation
                        onClick={() => {
                          askForConfirmation({
                            title: PROPOSAL_PAGE.advanceConfirmationTitle,
                            callback: (confirmed) => {
                              if (confirmed) {
                                void dispatch({
                                  type: Actions.advance,
                                });
                              }
                            },
                          });
                        }}
                      >
                        {votingState.state === VotingStates.commit
                          ? PROPOSAL_PAGE.revealButton
                          : PROPOSAL_PAGE.endProposalButton}
                      </Button>
                    )
                  ) : !isFinalStage ? (
                    <>
                      {state.voter.state === VoterStates.initial && state.voter.canBuyIn && (
                        <BuyIn
                          onBuyIn={(data) => {
                            void dispatch({
                              type: Actions.buyIn,
                              payload: data,
                            });
                          }}
                          config={config}
                          tokenType={state.tokenType}
                        />
                      )}
                      {state.voter.state === VoterStates.canCommit && (
                        <>
                          <Button
                            variant="contained"
                            sx={{ px: 3, mr: 2 }}
                            data-testid="vote-commit-button"
                            disableElevation
                            disabled={vote.length === 0}
                            onClick={() => {
                              askForConfirmation({
                                title: PROPOSAL_PAGE.commitVoteConfirmationTitle,
                                callback: (confirmed) => {
                                  if (confirmed) {
                                    void dispatch({
                                      type: Actions.commit,
                                      payload: vote === 'yes',
                                    });
                                  }
                                },
                              });
                            }}
                          >
                            {PROPOSAL_PAGE.commitButton}
                          </Button>
                        </>
                      )}
                      {state.voter.state === VoterStates.canReveal && (
                        <Button
                          variant="contained"
                          sx={{ px: 3 }}
                          data-testid="vote-reveal-button"
                          disableElevation
                          onClick={() => {
                            askForConfirmation({
                              title: PROPOSAL_PAGE.revealVoteConfirmationTitle,
                              callback: (confirmed) => {
                                if (confirmed) {
                                  void dispatch({
                                    type: Actions.reveal,
                                  });
                                }
                              },
                            });
                          }}
                        >
                          {PROPOSAL_PAGE.revealVoteButton}
                        </Button>
                      )}
                    </>
                  ) : null}

                  {isFinalStage && <ResultsTable votingState={votingState} />}

                  {isFinalStage && isBeneficiary && beneficiaryCanCashOut && (
                    <>
                      <Typography variant="h5" sx={{ mt: 4 }}>
                        {PROPOSAL_PAGE.cashOutTitle}
                      </Typography>
                      <Typography variant="body1" color="grey" sx={{ pt: 1 }}>
                        {PROPOSAL_PAGE.cashOutText}
                      </Typography>
                      <Button
                        variant="contained"
                        sx={{ px: 4, mt: 2 }}
                        data-testid="cash-out-button"
                        disabled={beneficiaryState?.state === BeneficiaryStates.cashingOut}
                        size="large"
                        disableElevation
                        onClick={() => {
                          askForConfirmation({
                            title: PROPOSAL_PAGE.cashOutConfirmationTitle,
                            callback: (confirmed) => {
                              if (confirmed) {
                                void dispatch({
                                  type: Actions.cashOut,
                                });
                              }
                            },
                          });
                        }}
                      >
                        {PROPOSAL_PAGE.cashOutButton}
                      </Button>
                    </>
                  )}
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </>
      )}
    </>
  );
};
