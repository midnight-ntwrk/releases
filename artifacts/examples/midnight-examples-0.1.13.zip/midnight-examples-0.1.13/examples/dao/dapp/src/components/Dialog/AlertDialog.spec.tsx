import { test, expect } from '@playwright/experimental-ct-react';
import { AlertDialog } from './AlertDialog';

test.describe('Alert Dialog component tests', () => {
  const title = 'Alert Dialog Title';
  const text = 'Alert Dialog Text';

  test('Alert Dialog test', async ({ mount, page }) => {
    const dialogTitle = page.locator('#alert-dialog-title');
    const dialogContent = page.locator('[aria-describedby="alert-dialog-title"]');
    const noButton = page.locator('[data-testid="alert-dialog-cancel-button"]');
    const yesButton = page.locator('[data-testid="alert-dialog-accept-button"]');

    const component = await mount(
      <AlertDialog isOpen={true} title={title} text={text} handleClose={() => undefined} />,
    );

    await expect(component).toBeEnabled();

    await expect(dialogTitle).toContainText(title);
    await expect(dialogTitle).toHaveCSS('color', 'rgb(34, 34, 34)');

    await expect(dialogContent).toContainText(text);
    await expect(noButton).toContainText('No');
    await expect(yesButton).toContainText('Yes');
  });
});
