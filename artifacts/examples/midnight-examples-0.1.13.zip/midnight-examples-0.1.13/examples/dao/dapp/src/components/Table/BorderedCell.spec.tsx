import { test, expect } from '@playwright/experimental-ct-react';
import { BorderedCell } from './BorderedCell';

test.describe('Bordered Cell component tests', () => {
  test('Bordered Cell test', async ({ mount, page }) => {
    let children;
    const component = await mount(<BorderedCell>{children}</BorderedCell>);

    await expect(component).toBeEnabled();
    await expect(component).toHaveCSS('border', '1px solid rgb(221, 221, 221)');
  });
});
