import { test, expect } from '@playwright/experimental-ct-react';
import { Heading } from './Heading';

test.describe('Heading component tests', () => {
  const title = 'Heading Title';

  test('Heading test', async ({ mount }) => {
    const component = await mount(<Heading title={title} />);

    await expect(component).toContainText(title);
    // Next line will fail the test
    await expect(component).toHaveCSS('font-weight', '500');
  });
});
