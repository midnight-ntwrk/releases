import * as fc from 'fast-check';
import { describe, it, expect } from '@jest/globals';
import { percentage } from './percentage';

describe('Percentage', () => {
  const arbitraryValidRecord = fc
    .dictionary(fc.string(), fc.float({ min: 0, noNaN: true, noDefaultInfinity: true }), { minKeys: 1 })
    .filter((dict) => Object.values(dict).reduce((acc, value) => acc + value, 0) > 0);

  const arbitraryInvalidRecord = fc
    .dictionary(fc.string(), fc.float(), { minKeys: 1 })
    .filter((dict) =>
      Object.values(dict).some((value) => Number.isNaN(value) || value < 0 || value === Number.POSITIVE_INFINITY),
    );

  it('returns empty object for empty input', () => {
    expect(percentage({})).toEqual({ total: 0, shares: {} });
  });

  it('follows input type for result', () => {
    const input = {
      votesYes: 1,
      votesNo: 3,
    } as const;

    const result: { total: number; shares: { readonly votesYes: number; readonly votesNo: number } } =
      percentage(input);

    expect(result).toEqual({ total: 4, shares: { votesYes: 25, votesNo: 75 } });
  });

  it('follows input shape for result', () => {
    fc.assert(
      fc.property(arbitraryValidRecord, (dict) => {
        const dictEntries = Object.entries(dict);
        const { total, shares } = percentage(dict);

        return (
          dictEntries.reduce((acc, [, value]) => acc + value, 0) === total &&
          dictEntries.every(([key]) => typeof shares[key] === 'number')
        );
      }),
    );
  });

  it('defaults to NaN if there is at least single Infinity or NaN or a negative value', () => {
    fc.assert(
      fc.property(arbitraryInvalidRecord, (dict) => {
        const result = percentage(dict);

        return Number.isNaN(result.total) && Object.values(result.shares).every((value) => Number.isNaN(value));
      }),
    );
  });

  it('defaults to NaN for all zeros', () => {
    fc.assert(
      fc.property(fc.dictionary(fc.string(), fc.constant(0)), (dict) => {
        const result = percentage(dict);

        return result.total === 0 && Object.values(result.shares).every((value) => Number.isNaN(value));
      }),
    );
  });

  it('sums to 100', () => {
    fc.assert(
      fc.property(arbitraryValidRecord, (dict) => {
        const result = percentage(dict);
        const sum = Object.values(result.shares).reduce((acc, value) => acc + value, 0);

        expect(sum).toBeCloseTo(100, 5);
      }),
    );
  });

  it('is zero for zeros', () => {
    fc.assert(
      fc.property(arbitraryValidRecord, (dict) => {
        const zeroEntries = Object.entries(dict).filter(([key, value]) => value === 0);
        const result = percentage(dict);
        const values = zeroEntries.map(([key]) => [key, result.shares[key]]);

        return values.every(([, value]) => value === 0);
      }),
    );
  });

  it('is bigger than zero for non-zero values', () => {
    fc.assert(
      fc.property(arbitraryValidRecord, (dict) => {
        const nonZeroEntries = Object.entries(dict).filter(([key, value]) => value > 0);
        const result = percentage(dict);
        const values = nonZeroEntries.map(([key]) => [key, result.shares[key]] as const);

        return values.every(([key, value]) => value > 0);
      }),
    );
  });

  it('is proportional to share of a value', () => {
    fc.assert(
      fc.property(arbitraryValidRecord, (dict) => {
        const entries = Object.entries(dict);
        const result = percentage(dict);
        const sum = Object.values(dict).reduce((acc, value) => acc + value, 0);

        entries.forEach(([key, value]) => {
          const expected = (100 * value) / sum;
          expect(result.shares[key]).toBeCloseTo(expected, 5);
        });
      }),
    );
  });
});
