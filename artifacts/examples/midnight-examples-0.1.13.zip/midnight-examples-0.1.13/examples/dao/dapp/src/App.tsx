import { type ReactElement } from 'react';
import { BrowserRouter as Router, Navigate, Route, Routes } from 'react-router-dom';
import { Box, useTheme } from '@mui/material';
import * as pino from 'pino';

import { MainLayout } from './components';
import { AppProvider, ErrorProvider, AlertProvider } from './contexts';
import { useAppContext } from './hooks';
import { Proposal } from './pages';
import { CreateProposal } from './pages/createProposal/CreateProposal';
import { Initialize } from './pages/initialize/Initialize';

const logger = pino.pino({
  level: 'trace',
});

const RootRedirect = (): ReactElement => {
  const { state } = useAppContext();
  return state !== undefined ? <Navigate to="/proposal" replace /> : <Navigate to="/initialize" replace />;
};

const App = (): ReactElement => {
  const theme = useTheme();

  // The App provider is the one that provides access to DAO API and makes usage of DApp connector to connect to user's wallet
  return (
    <Box sx={{ background: theme.palette.secondary.main, minHeight: '100vh' }}>
      <Router>
        <ErrorProvider>
          <AlertProvider>
            <AppProvider logger={logger}>
              <Routes>
                <Route path="/" element={<MainLayout />}>
                  <Route path="/proposal" element={<Proposal />} />
                  <Route path="/proposal/create" element={<CreateProposal />} />
                  <Route path="/initialize" element={<Initialize />} />
                  <Route path="/" element={<RootRedirect />} />
                </Route>
              </Routes>
            </AppProvider>
          </AlertProvider>
        </ErrorProvider>
      </Router>
    </Box>
  );
};

export default App;
