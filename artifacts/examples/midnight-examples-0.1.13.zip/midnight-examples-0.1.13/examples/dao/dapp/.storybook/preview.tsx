import '../src/globals';
import type { Preview, ReactRenderer } from "@storybook/react";
import { DecoratorFunction } from "@storybook/types";
import { AlertProvider, ErrorProvider } from "../src/contexts";

const preview: Preview = {
  parameters: {
    actions: { argTypesRegex: '^on[A-Z].*' },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i,
      },
    }
  },
};

export default preview;

export const decorators: DecoratorFunction<ReactRenderer>[] = [(Story) => (<ErrorProvider><AlertProvider><Story /></AlertProvider></ErrorProvider>)];
