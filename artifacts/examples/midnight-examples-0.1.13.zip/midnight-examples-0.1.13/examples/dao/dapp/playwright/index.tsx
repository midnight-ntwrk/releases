// Import styles, initialize component theme here.
import { theme } from '../src/config/theme';
