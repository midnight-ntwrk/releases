import { Contract, type ContractPrivateState } from '@midnight-ntwrk/dao-contract';
import { FinalizedDeployTxData } from '@midnight-ntwrk/midnight-js-contracts';

export const toHex = (bytes: Uint8Array): string => Buffer.from(bytes).toString('hex');

export const fromHex = (hex: string): Uint8Array => Buffer.from(hex, 'hex');

const prettifyLedgerState = (state: Contract.LedgerState) => {
  switch (state) {
    case Contract.LedgerState.setup:
      return 'setup';
    case Contract.LedgerState.commit:
      return 'commit';
    case Contract.LedgerState.reveal:
      return 'reveal';
    case Contract.LedgerState.final:
      return 'final';
  }
};

export const prettifyLedger = ({
  state,
  topic,
  beneficiary,
  yes,
  no,
  round,
  organizer,
  committedParticipants,
  revealedParticipants,
  pot,
  potHasCoin,
}: Contract.Ledger) => ({
  state: prettifyLedgerState(state),
  topic: topic.is_some ? topic.value : null,
  yes,
  no,
  round,
  beneficiary: beneficiary.is_some ? toHex(beneficiary.value.bytes) : null,
  organizer: toHex(organizer),
  committed: [...committedParticipants].map(toHex),
  revealed: [...revealedParticipants].map(toHex),
  pot: pot.value,
  potHasCoin,
});

const prettifyLocalState = (state: Contract.LocalState) => {
  switch (state) {
    case Contract.LocalState.initial:
      return 'initial';
    case Contract.LocalState.committed:
      return 'committed';
    case Contract.LocalState.revealed:
      return 'revealed';
  }
};

export const prettifyPrivateState = (contractPrivateState: ContractPrivateState | null) =>
  contractPrivateState === null
    ? null
    : {
        dappSecretKey: toHex(contractPrivateState.dappSecretKey),
        statesPerRound: Object.fromEntries(
          Object.entries(contractPrivateState.statesPerRound).map(([round, { state, ballot }]) => [
            round,
            { ballot, state: prettifyLocalState(state) },
          ]),
        ),
      };

export const prettifyFinalizedDeployTxData = ({
  initialContractState,
  initialPrivateState,
  ...rest
}: FinalizedDeployTxData<Record<string, ContractPrivateState>, string>) => ({
  ...rest,
  initialLedgerState: prettifyLedger(Contract.ledger(initialContractState.data)),
  initialPrivateState: prettifyPrivateState(initialPrivateState),
});
