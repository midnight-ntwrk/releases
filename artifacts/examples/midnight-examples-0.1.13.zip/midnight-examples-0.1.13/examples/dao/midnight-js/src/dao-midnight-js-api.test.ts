import { expect, it, jest } from '@jest/globals';
import { sampleContractAddress } from '@midnight-ntwrk/compact-runtime';
import { runDaoAPITest } from '@midnight-ntwrk/dao-api-testing';
import { defaultConfig } from '@midnight-ntwrk/dao-contract';
import { pipe, Resource } from '@midnight-ntwrk/dao-helpers';
import { networkId, setNetworkId } from '@midnight-ntwrk/midnight-js-network-id';
import { webcrypto } from 'crypto';
import * as fc from 'fast-check';
import { VerbosityLevel } from 'fast-check';
import { createWriteStream } from 'node:fs';
import * as fs from 'node:fs/promises';
import * as path from 'path';
import pino from 'pino';
import pinoPretty from 'pino-pretty';
import { WebSocket } from 'ws';
import { ContractDeploymentFailed, ContractNotFoundError, DaoMidnightJSAPI } from './dao-midnight-js-api';
import { Infrastructure, MidnightJSDAOAPIInstance } from './dao-midnight-js-instance.js';

// @ts-ignore: It's needed to make Scala.js and WASM code able to use cryptography
globalThis.crypto = webcrypto;

// @ts-ignore: It's needed to enable WebSocket usage through apollo
globalThis.WebSocket = WebSocket;

setNetworkId(networkId.undeployed);

//Yes, with proving, consensus, etc. longer scenarios take a lot of time
jest.setTimeout(1_800_000);

fc.configureGlobal({
  numRuns: 2,
  endOnFailure: true,
  errorWithCause: true,
  verbose: VerbosityLevel.Verbose,
});

const logPath = path.resolve(new URL(import.meta.url).pathname, '../../log/test.log');
await fs.mkdir(path.dirname(logPath), { recursive: true });

const pretty: pinoPretty.PrettyStream = pinoPretty({
  colorize: true,
  sync: true,
});
const level = 'trace' as const;
const logger = pino(
  {
    level,
    depthLimit: 20,
  },
  pino.multistream([
    { stream: pretty, level: 'fatal' },
    { stream: createWriteStream(logPath), level },
  ]),
);

const TRANSACTION_TIMEOUT = 90_000; // 90 seconds

runDaoAPITest<Infrastructure>({
  implementationName: 'Midnight.JS',
  suite: 'smoke',
  logger,
  instance: (config, infrastructure) =>
    MidnightJSDAOAPIInstance.setup({ dao: config, transactionTimeout: TRANSACTION_TIMEOUT }, infrastructure),
  infrastructure: () => MidnightJSDAOAPIInstance.infrastructure(logger),
  implementationSpecificSuite:
    ({ getInfrastructure }) =>
    () => {
      const getImplConfig = () => {
        return {
          dao: defaultConfig,
          transactionTimeout: TRANSACTION_TIMEOUT,
        };
      };

      it('checks contract state availability after deployment', async () => {
        const config = getImplConfig();
        const infrastructure = getInfrastructure();

        const { result, queryDeployContractStateSpy } = await pipe(
          MidnightJSDAOAPIInstance.prepareProviders(
            crypto.randomUUID(),
            'organizer',
            infrastructure.wallets.organizer,
            infrastructure.containerPorts,
            logger,
          ),
          Resource.map((providers) => {
            const publicDataProvider = providers.publicDataProvider;
            const queryDeployContractStateSpy = jest.spyOn(publicDataProvider, 'queryDeployContractState');
            return {
              providers,
              queryDeployContractStateSpy,
            };
          }),
          Resource.use(async ({ providers, queryDeployContractStateSpy }) => {
            const result = await DaoMidnightJSAPI.deploy(
              'organizer',
              providers,
              config,
              Buffer.from(providers.walletProvider.coinPublicKey, 'hex'),
            );
            return { result, queryDeployContractStateSpy };
          }),
        );

        expect(queryDeployContractStateSpy).toBeCalledWith(result.contract.finalizedDeployTxData.contractAddress);
      });

      it('raises error if contract state cannot be found after observing deployment transaction', async () => {
        const config = getImplConfig();
        const infrastructure = getInfrastructure();

        await pipe(
          MidnightJSDAOAPIInstance.prepareProviders(
            crypto.randomUUID(),
            'organizer',
            infrastructure.wallets.organizer,
            infrastructure.containerPorts,
            logger,
          ),
          Resource.map((providers) => {
            const publicDataProvider = providers.publicDataProvider;
            jest.spyOn(publicDataProvider, 'queryDeployContractState').mockImplementation(() => Promise.resolve(null));
            return providers;
          }),
          Resource.use(async (providers) => {
            expect.assertions(1);
            try {
              await DaoMidnightJSAPI.deploy(
                'organizer',
                providers,
                config,
                Buffer.from(providers.walletProvider.coinPublicKey, 'hex'),
              );
            } catch (e) {
              expect(e).toBeInstanceOf(ContractDeploymentFailed);
            }
          }),
        );
      });

      it('raises error if contract state query fails after observing deployment transaction', async () => {
        const config = getImplConfig();
        const infrastructure = getInfrastructure();

        await pipe(
          MidnightJSDAOAPIInstance.prepareProviders(
            crypto.randomUUID(),
            'organizer',
            infrastructure.wallets.organizer,
            infrastructure.containerPorts,
            logger,
          ),
          Resource.map((providers) => {
            const publicDataProvider = providers.publicDataProvider;
            jest
              .spyOn(publicDataProvider, 'queryDeployContractState')
              .mockImplementation(() => Promise.reject(new Error('voo!')));
            return providers;
          }),
          Resource.use(async (providers) => {
            expect.assertions(1);
            try {
              await DaoMidnightJSAPI.deploy(
                'organizer',
                providers,
                config,
                Buffer.from(providers.walletProvider.coinPublicKey, 'hex'),
              );
            } catch (e) {
              expect(e).toBeInstanceOf(ContractDeploymentFailed);
            }
          }),
        );
      });

      it('raises error if contract state cannot be found on join', async () => {
        const config = getImplConfig();
        const infrastructure = getInfrastructure();
        const sampledAddress = sampleContractAddress();

        await pipe(
          MidnightJSDAOAPIInstance.prepareProviders(
            crypto.randomUUID(),
            'organizer',
            infrastructure.wallets.organizer,
            infrastructure.containerPorts,
            logger,
          ),
          Resource.use(async (providers) => {
            expect.assertions(2);
            try {
              await DaoMidnightJSAPI.join(
                'organizer',
                providers,
                config,
                Buffer.from(providers.walletProvider.coinPublicKey, 'hex'),
                sampledAddress,
              );
            } catch (e) {
              expect(e).toBeInstanceOf(ContractNotFoundError);
              expect((e as ContractNotFoundError).address).toEqual(sampledAddress);
            }
          }),
        );
      });
    },
});
