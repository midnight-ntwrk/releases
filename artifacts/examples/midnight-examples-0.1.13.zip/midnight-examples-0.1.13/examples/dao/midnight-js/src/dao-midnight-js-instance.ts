import { DaoAPI, DaoConfig } from '@midnight-ntwrk/dao-api';
import { DAOInstance, GetAPIOptions } from '@midnight-ntwrk/dao-api-testing';
import { EphemeralStateBloc } from '@midnight-ntwrk/dao-contract';
import { pipe, Resource } from '@midnight-ntwrk/dao-helpers';
import { nativeToken } from '@midnight-ntwrk/ledger';
import { httpClientProofProvider } from '@midnight-ntwrk/midnight-js-http-client-proof-provider';
import { indexerPublicDataProvider } from '@midnight-ntwrk/midnight-js-indexer-public-data-provider';
import { NodeZkConfigProvider } from '@midnight-ntwrk/midnight-js-node-zk-config-provider';
import { WalletBuilder, Resource as WalletResource } from '@midnight-ntwrk/wallet';
import { Wallet } from '@midnight-ntwrk/wallet-api';
import { webcrypto } from 'crypto';
import * as crypto from 'node:crypto';
import * as path from 'path';
import pino from 'pino';
import { filter, firstValueFrom, map } from 'rxjs';
import { webCryptoCryptography } from './cryptography.js';
import { Config, DaoMidnightJSAPI, MidnightJSDaoProviders } from './dao-midnight-js-api.js';
import { headlessWalletAndMidnightProvider } from './headless-wallet-provider.js';
import { inMemoryPrivateStateProvider } from './in-memory-private-state-provider.js';
import { SubscribablePrivateStateProviderDecorator } from './private-state-decorator.js';
import { DockerComposeEnvironment, StartedDockerComposeEnvironment, Wait } from 'testcontainers';

export type DockerContainerPorts = {
  readonly indexer: number;
  readonly node: number;
  readonly proofServer: number;
};

export type TestParticipantsWallets = {
  organizer: Wallet;
  [index: number]: Wallet | undefined;
};

export type Infrastructure = {
  environment: StartedDockerComposeEnvironment;
  containerPorts: DockerContainerPorts;
  wallets: TestParticipantsWallets;
  logger: pino.Logger;
};

/**
 * This seed gives access to tokens minted in the genesis block of a local development node
 */
const GENESIS_MINT_WALLET_SEED = '0000000000000000000000000000000000000000000000000000000000000042';

export class MidnightJSDAOAPIInstance implements DAOInstance {
  /**
   * Prepares Midnight.js providers for testing.
   */
  static prepareProviders(
    instanceId: string,
    forWho: string,
    wallet: Wallet,
    containerPorts: DockerContainerPorts,
    logger: pino.Logger,
  ): Resource<MidnightJSDaoProviders> {
    return pipe(
      EphemeralStateBloc.init(logger.child({ what: 'Ephemeral state', forWho })),
      Resource.zip(
        Resource.fromPromise(() => headlessWalletAndMidnightProvider(wallet, logger.child({ what: 'Wallet provider' }))),
      ),
      Resource.map(([ephemeralStateBloc, { walletProvider, midnightProvider }]): MidnightJSDaoProviders => {
        const instanceLogger = logger.child({ forWho, instanceId });
        return {
          logging: instanceLogger,
          crypto: webCryptoCryptography(webcrypto),
          privateStateProvider: new SubscribablePrivateStateProviderDecorator(
            instanceLogger.child({
              what: 'Subscribable Private State Decorator',
            }),
            inMemoryPrivateStateProvider(),
          ),
          zkConfigProvider: new NodeZkConfigProvider(
            path.resolve(new URL(import.meta.url).pathname, '..', '..', '..', 'contract', 'dist', 'managed', 'micro-dao'),
          ),
          ephemeralState: ephemeralStateBloc,
          proofProvider: httpClientProofProvider(`http://localhost:${containerPorts.proofServer}`),
          publicDataProvider: indexerPublicDataProvider(
            `http://localhost:${containerPorts.indexer}/api/v1/graphql`,
            `ws://localhost:${containerPorts.indexer}/api/v1/graphql/ws`,
          ),
          walletProvider,
          midnightProvider,
        };
      }),
    );
  }

  static DEFAULT_STARTUP_TIMEOUT = 30_000;
  static DEFAULT_SHUTDOWN_TIMEOUT = 10_000;

  /**
   * Shared infrastructure between test runs. It comprises:
   *   - proving server, node and indexer run through testcontainers
   *   - wallets
   */
  static infrastructure(logger: pino.Logger): Resource<Infrastructure> {
    return pipe(
      Resource.make<[StartedDockerComposeEnvironment, DockerContainerPorts]>(
        async () => {
          const currentPath = path.dirname(new URL(import.meta.url).pathname);
          const composeFileDir = path.resolve(currentPath, '..');
          const env = new DockerComposeEnvironment(composeFileDir, 'test-compose.yml')
            .withWaitStrategy('dao-proof-server', Wait.forListeningPorts())
            .withWaitStrategy('dao-graphql-api', Wait.forListeningPorts())
            .withStartupTimeout(MidnightJSDAOAPIInstance.DEFAULT_STARTUP_TIMEOUT);
          logger.debug('Setting up tests infrastructure');
          const startedEnv = await env.up();
          // Per the test compose file, host ports are chosen at random and mapped to the container ports specified in the compose file.
          // This avoids port clashes when DAO and Coracle/Welcome tests are run concurrently.
          // The object below retrieves the randomly chosen host ports and passes them to the other providers.
          const containerPorts = {
            proofServer: startedEnv.getContainer('dao-proof-server').getMappedPort(6300),
            indexer: startedEnv.getContainer('dao-graphql-api').getMappedPort(8088),
            node: startedEnv.getContainer('dao-node').getMappedPort(9944),
          };
          return [startedEnv, containerPorts];
        },
        async ([environment]) => {
          logger.debug('Tearing down tests infrastructure');
          await environment.down({ timeout: MidnightJSDAOAPIInstance.DEFAULT_SHUTDOWN_TIMEOUT, removeVolumes: true });
        },
      ),
      Resource.mproduct(([, containerPorts]) => MidnightJSDAOAPIInstance.wallets(logger, containerPorts)),
      Resource.map(([[environment, containerPorts], wallets]) => ({ environment, containerPorts, wallets, logger })),
    );
  }

  /**
   * Prepares wallets for testing:
   *   - initializes one with seed funds
   *   - sends some tokens to all participants
   *   - waits till all wallets have some balance
   *   - returns them in a way allowing for easy access later, when handling calls to `getAPI`
   */
  static wallets(logger: pino.Logger, containerPorts: DockerContainerPorts): Resource<TestParticipantsWallets> {
    const makeWallet = (seed: Buffer, wait: boolean) =>
      Resource.make<Wallet & WalletResource>(
        () =>
          WalletBuilder.buildFromSeed(
            `http://localhost:${containerPorts.indexer}/api/v1/graphql`,
            `ws://localhost:${containerPorts.indexer}/api/v1/graphql/ws`,
            `http://localhost:${containerPorts.proofServer}`,
            `http://localhost:${containerPorts.node}`,
            seed.toString('hex'),
          ).then((wallet) => {
            wallet.start();
            if (wait) {
              return waitForFunds(wallet).then(() => wallet);
            }
            return wallet;
          }),
        (wallet) => wallet.close(),
      );

    const waitForFunds = (wallet: Wallet) =>
      firstValueFrom(
        wallet.state().pipe(
          map((s) => s.balances[nativeToken()] ?? 0n),
          filter((balance) => balance > 0n),
        ),
      );

    const initFunds = async (from: Wallet, to: Wallet[]) =>
      Promise.all(
        to.map((receiver) =>
          firstValueFrom(receiver.state())
            .then((state) => state.address)
            .then((receiverAddress) => from.transferTransaction([{ type: nativeToken(), amount: 20_000_000n, receiverAddress }]))
            .then((txToProve) => from.proveTransaction(txToProve))
            .then((txToSubmit) => from.submitTransaction(txToSubmit))
            .then(() => waitForFunds(receiver)),
        ),
      );

    const organizerSeed = Buffer.from(GENESIS_MINT_WALLET_SEED, 'hex');
    return pipe(
      makeWallet(organizerSeed, true),
      Resource.zip(makeWallet(crypto.randomBytes(32), false)),
      Resource.zip(makeWallet(crypto.randomBytes(32), false)),
      Resource.mapAsync(async ([[organizerWallet, joiner1Wallet], joiner2Wallet]) => {
        logger.trace('Wallets created');
        logger.debug("Organizer's wallet ready to send coins");
        await initFunds(organizerWallet, [joiner1Wallet, joiner2Wallet]);
        logger.debug('Other parties received coins');
        return {
          organizer: organizerWallet,
          [1]: organizerWallet,
          [2]: joiner1Wallet,
          [3]: joiner2Wallet,
        };
      }),
    );
  }

  /**
   * Given the infrastructure, prepare a DAO instance for testing. That is:
   *   - prepare organizer data
   *   - deploy contract
   */
  static setup(config: Config & Readonly<{ dao: DaoConfig }>, infrastructure: Infrastructure): Resource<DAOInstance> {
    const instanceId = crypto.randomUUID();
    return pipe(
      MidnightJSDAOAPIInstance.prepareProviders(
        instanceId,
        'organizer',
        infrastructure.wallets.organizer,
        infrastructure.containerPorts,
        infrastructure.logger,
      ),
      Resource.mapAsync(async (providers) => {
        const coinPublicKey = Buffer.from(providers.walletProvider.coinPublicKey, 'hex');
        const deployed = await DaoMidnightJSAPI.deploy('organizer', providers, config, coinPublicKey);
        return new MidnightJSDAOAPIInstance(
          config,
          instanceId,
          deployed.contract.finalizedDeployTxData.contractAddress,
          {
            api: deployed,
            providers: providers,
          },
          infrastructure.wallets,
          infrastructure.containerPorts,
          infrastructure.logger,
        );
      }),
    );
  }

  constructor(
    private readonly config: Config,
    private readonly instanceId: string,
    private readonly contractAddress: string,
    private readonly organizerState: { providers: MidnightJSDaoProviders; api: DaoAPI },
    private readonly wallets: TestParticipantsWallets,
    private readonly containerPorts: DockerContainerPorts,
    private readonly logger: pino.Logger,
  ) {}

  /**
   * Join the instance. Either as organizer or one of the other participants
   */
  getAPI(options: GetAPIOptions): Resource<{ api: DaoAPI; address: string }> {
    if (options.organizer) {
      return Resource.from(() => ({
        api: this.organizerState.api,
        address: this.organizerState.providers.walletProvider.coinPublicKey,
      }));
    } else {
      const wallet = this.wallets[options.number];
      if (wallet == undefined) {
        throw new Error(
          `Could not find wallet with number ${options.number} in prepared wallets: ${Object.keys(this.wallets).join(', ')}`,
        );
      }
      return pipe(
        MidnightJSDAOAPIInstance.prepareProviders(
          this.instanceId,
          `voter_${options.number}`,
          wallet,
          this.containerPorts,
          this.logger,
        ),
        Resource.mapAsync(async (providers) => {
          const api = await DaoMidnightJSAPI.join(
            `voter_${options.number}`,
            providers,
            this.config,
            Buffer.from(providers.walletProvider.coinPublicKey, 'hex'),
            this.contractAddress,
          );

          return {
            api,
            address: providers.walletProvider.coinPublicKey,
          };
        }),
      );
    }
  }
}
