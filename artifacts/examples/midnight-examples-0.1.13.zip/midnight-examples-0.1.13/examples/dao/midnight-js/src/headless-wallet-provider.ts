import { CoinInfo, Offer, Transaction, TransactionId } from '@midnight-ntwrk/ledger';
import {
  BalancedTransaction,
  createBalancedTx,
  MidnightProvider,
  UnbalancedTransaction,
  WalletProvider,
} from '@midnight-ntwrk/midnight-js-types';
import { Wallet } from '@midnight-ntwrk/wallet-api';
import { Transaction as ZswapTransaction } from '@midnight-ntwrk/zswap';
import pino from 'pino';
import { firstValueFrom } from 'rxjs';

/**
 * Creates Wallet Provider and Midnight Provider based on wallet instance
 *
 * It is mostly just exposing bits of wallet state or calling its methods. The only places that might be confusing
 * are the one related to `Transaction.deserialize(tx.serialize)` - they are needed because there exist 3 WASM libraries
 * that implement some parts of Midnight API, there is some overlap between them but the wrapping code performs
 * `instanceof` checks, which would require either using a single library everywhere (with its own challenges) or the conversions.
 */
export const headlessWalletAndMidnightProvider = async (
  wallet: Wallet,
  logger: pino.Logger,
): Promise<{ walletProvider: WalletProvider; midnightProvider: MidnightProvider }> => {
  const state = await firstValueFrom(wallet.state());

  const walletProvider: WalletProvider = {
    coinPublicKey: state.coinPublicKey,
    balanceTx(tx: UnbalancedTransaction, newCoins: CoinInfo[]): Promise<BalancedTransaction> {
      const logOffer = (offer: Offer) => ({
        deltas: Object.fromEntries(offer.deltas.entries()),
        inputs: offer.inputs,
        outputs: offer.outputs,
      });
      logger.trace({
        ids: tx.tx.identifiers(),
        guaranteed: logOffer(tx.tx.guaranteedCoins),
        fallible: tx.tx.fallibleCoins ? logOffer(tx.tx.fallibleCoins) : undefined,
        calls: tx.tx.contractCalls,
      });
      return wallet
        .balanceTransaction(ZswapTransaction.deserialize(tx.tx.serialize()), newCoins)
        .then((tx) => wallet.proveTransaction(tx))
        .then((zswapTx) => Transaction.deserialize(zswapTx.serialize()))
        .then(createBalancedTx);
    },
  };

  const midnightProvider: MidnightProvider = {
    submitTx(tx: BalancedTransaction): Promise<TransactionId> {
      return wallet.submitTransaction(tx.tx);
    },
  };

  return {
    walletProvider,
    midnightProvider,
  };
};
