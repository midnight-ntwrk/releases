export type Cryptography = {
  randomUUID: () => string;
};

/**
 * A simple wrapper around crypto module / webcrypto to perform common cryptographic operations;
 * Now it's just UUID generation
 */
export const webCryptoCryptography = (crypto: { randomUUID(): string }): Cryptography => {
  return {
    randomUUID: (): string => crypto.randomUUID(),
  };
};
