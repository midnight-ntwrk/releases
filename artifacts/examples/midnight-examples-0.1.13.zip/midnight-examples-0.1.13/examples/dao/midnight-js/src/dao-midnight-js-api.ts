import { ContractState, encodeCoinInfo, tokenType } from '@midnight-ntwrk/compact-runtime';
import { createCoinInfo, nativeToken } from '@midnight-ntwrk/ledger';
import { Action, ActionId, AsyncAction, DaoAPI, DaoConfig, DaoState, Proposal } from '@midnight-ntwrk/dao-api';
import {
  configToCosts,
  Contract,
  ContractPrivateState,
  costsToConfig,
  deriveDAOState,
  EphemeralStateBloc,
  Witnesses,
} from '@midnight-ntwrk/dao-contract';
import {
  ContractCircuitsInterface,
  deployContract,
  DeployedContract,
  findDeployedContract,
  StateWithZswap,
  SubmittedCallTx,
  withZSwapState,
  withZswapWitnesses,
} from '@midnight-ntwrk/midnight-js-contracts';
import { MidnightProviders } from '@midnight-ntwrk/midnight-js-types';
import { pipe } from 'fp-ts/function';
import pino from 'pino';
import * as rx from 'rxjs';
import {
  catchError,
  combineLatest,
  concatMap,
  debounceTime,
  EMPTY,
  filter,
  firstValueFrom,
  map,
  Observable,
  of,
  shareReplay,
  tap,
  throwError,
  timeout,
} from 'rxjs';
import { Cryptography } from './cryptography.js';
import { inMemoryPrivateStateProvider } from './in-memory-private-state-provider.js';
import { SubscribablePrivateStateProvider } from './private-state-decorator.js';
import { prettifyFinalizedDeployTxData, prettifyLedger, prettifyPrivateState } from './prettify-utils';

type ContractAddress = string;

type PrivateStateSchema = Record<string, ContractPrivateState>;
type CircuitNames = Exclude<keyof Contract.Contract<unknown>['impureCircuits'], number | symbol>;
type CallCircuitContext = {
  contract: ContractCircuitsInterface<
    PrivateStateSchema,
    string,
    Contract.Contract<PrivateState, Contract.Witnesses<PrivateState>>
  >;
};
type CallTx<K extends keyof Contract.Contract<unknown>['impureCircuits']> = SubmittedCallTx<
  PrivateStateSchema,
  string,
  Contract.Contract<PrivateState, Contract.Witnesses<PrivateState>>,
  K
>;

export type MidnightJSDaoProviders = MidnightProviders<CircuitNames, PrivateStateSchema> & {
  crypto: Cryptography;
  logging: pino.Logger;
  ephemeralState: EphemeralStateBloc;
  privateStateProvider: SubscribablePrivateStateProvider<PrivateStateSchema>;
};

export class ContractNotFoundError extends Error {
  constructor(public readonly address: string) {
    super(`Contract at address ${address} was not found`);
  }
}

export class ContractDeploymentFailed extends Error {
  constructor() {
    super(`Contract deployment failed`);
  }
}

export type PrivateState = StateWithZswap<ContractPrivateState>;

export type Config = Readonly<{
  transactionTimeout: number;
}>;

/**
 * A Midnight.JS-based implementation of DAO
 * It does use Midnight.JS and real contract implementation, as well as requires access to node, wallet, pub-sub and proof server
 * in order to fully work.
 *
 * This class is also the primary implementation final DApp uses to make calls and get state.
 *
 * In its structure it has many similarities with the `DirectAPI` implementation from contract package. But the implementations
 * used make this class connect to a network and create transactions instead of performing everything in memory. So there are 3 main parts:
 * - state management
 * - orchestrating contract calls
 * - exposing calls to specific contract circuits
 *
 * Most of the state management code is held in the constructor. It boils down to getting stream of state changes of each
 * state piece (contract, private, ephemeral) and combining them into single DAO state (using exactly the same code, as
 * in-memory implementation does)
 *
 * Calls are orchestrated in the `callCircuit` method.
 *
 * The majority of other methods are ones to call specific circuits through a `callCircuit` one.
 */
export class DaoMidnightJSAPI implements DaoAPI {
  static TRANSACTION_TIMEOUT = 5 * 60 * 1_000; // 5 minutes
  /**
   * Deploys contract to the network. Exact behavior will depend on passed providers, and this is place where one can
   * differentiate between e.g. browser environment and a headless local testing one.
   *
   * What happens is that:
   * 1. a brand new private state is being generated
   * 2. a private state provider is overridden to use in-memory implementation, this will be useful in step #4
   * 3. within `deployContractCall` Midnight.js prepares initial contract state, prepares deploy transaction and submits it
   * 4. After successful deploy, the resulting private state is rewritten to persistent storage, this time under contract address - this allows to:
   *    - unify slightly deploy and join story
   *    - make a single DApp/UI deployment support multiple contract instances easily
   * 5. Once the private state is rewritten - function returns with join.
   *
   * @param who - originally a role of participant for logging purposes; it's almost unused in actual DApp, but very useful in testing
   * @param providers - Midnight.js providers extended with DAO-specific ones (like logger)
   * @param config - DAO configuration
   * @param coinPublicKey - Coin public key obtained from wallet, this one probably could be removed to use wallet provider instead
   */
  static async deploy(
    who: string,
    providers: MidnightJSDaoProviders,
    config: Config & Readonly<{ dao: DaoConfig }>,
    coinPublicKey: Uint8Array,
  ): Promise<DaoMidnightJSAPI> {
    providers.logging.trace('Preparing for contract deployment');
    const contract: Contract.Contract<PrivateState, Contract.Witnesses<PrivateState>> = new Contract.Contract<
      PrivateState,
      Contract.Witnesses<PrivateState>
    >(withZswapWitnesses(Witnesses())(coinPublicKey));
    const privateState: PrivateState = withZSwapState(ContractPrivateState.generate());

    const overriddenProviders = {
      ...providers,
      privateStateProvider: inMemoryPrivateStateProvider<PrivateStateSchema>(),
    };
    const deployed = await pipe(
      rx.defer(() =>
        deployContract<
          PrivateStateSchema,
          string,
          Contract.Witnesses<PrivateState>,
          Contract.Contract<PrivateState, Contract.Witnesses<PrivateState>>,
          CircuitNames
        >(
          overriddenProviders,
          who,
          privateState.contract,
          contract,
          privateState.contract.dappSecretKey,
          configToCosts(config.dao),
        ),
      ),
      rx.concatMap((deployed) => {
        const address = deployed.finalizedDeployTxData.contractAddress;

        return rx.interval(1000).pipe(
          rx.concatMap(() => DaoMidnightJSAPI.getInitialContractState(providers, address)),
          rx.map(() => deployed),
        );
      }),
      rx.timeout({
        first: config.transactionTimeout,
      }),
      rx.catchError((err) => {
        providers.logging.error({ err }, 'Contract deployment failed');
        return throwError(() => new ContractDeploymentFailed());
      }),
      (x) => rx.firstValueFrom(x),
    );
    providers.logging.debug(prettifyFinalizedDeployTxData(deployed.finalizedDeployTxData), 'Contract deployed');
    const contractAddress = deployed.finalizedDeployTxData.contractAddress;
    const currentPrivateState = await overriddenProviders.privateStateProvider.get(who);
    if (currentPrivateState == null) {
      throw new Error('Could not read private state after deployment');
    }
    await providers.privateStateProvider.set(contractAddress, currentPrivateState);
    return DaoMidnightJSAPI.join(who, providers, config, coinPublicKey, contractAddress);
  }

  /**
   * Joins an already existing contract deployment. It does:
   * 1. Ensure there is private state available in the provider, generating a brand new one if there is no
   *    existing one for given contract address
   * 2. Look for contract data under provided address
   * 3. Return instance ready to interact with the contract
   *
   * @param who - originally a role of participant for logging purposes; it's almost unused in actual DApp, but very useful in testing
   * @param providers - Midnight.js providers extended with DAO-specific ones (like logger)
   * @param config - DAO configuration
   * @param coinPublicKey - Coin public key obtained from wallet, this one probably could be removed to use wallet provider instead
   * @param address - Contract address
   */
  static async join(
    who: string,
    providers: MidnightJSDaoProviders,
    config: Config,
    coinPublicKey: Uint8Array,
    address: ContractAddress,
  ): Promise<DaoMidnightJSAPI> {
    providers.logging.debug({ address }, 'Joining contract');
    if ((await providers.privateStateProvider.get(address)) == null) {
      providers.logging.trace({ address }, 'No private state found, initializing a new, random one');
      const newPrivateState = ContractPrivateState.generate();
      await providers.privateStateProvider.set(address, newPrivateState);
    }
    const contract: Contract.Contract<PrivateState> = new Contract.Contract<PrivateState>(
      withZswapWitnesses(Witnesses())(coinPublicKey),
    );
    providers.logging.trace({ address }, 'Looking for deployed contract');
    await pipe(
      rx.interval(1000),
      rx.concatMap(() => this.getInitialContractState(providers, address)),
      rx.timeout({
        first: config.transactionTimeout,
      }),
      rx.catchError((err) => {
        providers.logging.error({ err }, 'Contract state not found');
        return throwError(() => new ContractNotFoundError(address));
      }),
      rx.firstValueFrom,
    );
    const foundContract = await findDeployedContract<
      PrivateStateSchema,
      string,
      Contract.Witnesses<PrivateState>,
      Contract.Contract<PrivateState, Contract.Witnesses<PrivateState>>,
      CircuitNames
    >(providers, address, contract, { privateStateKey: address });
    providers.logging.trace(prettifyFinalizedDeployTxData(foundContract.finalizedDeployTxData), 'Contract found');
    return new DaoMidnightJSAPI(who, providers, config, coinPublicKey, foundContract);
  }

  private static getInitialContractState(providers: MidnightJSDaoProviders, address: ContractAddress) {
    return rx
      .defer(() => providers.publicDataProvider.queryDeployContractState(address))
      .pipe(rx.filter((state: ContractState | null): state is ContractState => state != null));
  }

  config$: Observable<DaoConfig>;
  state$: Observable<DaoState>;
  #logger: pino.Logger;

  private constructor(
    who: string,
    private readonly providers: MidnightJSDaoProviders,
    private readonly config: Config,
    private readonly coinPublicKey: Uint8Array,
    public readonly contract: DeployedContract<PrivateStateSchema, string, Contract.Contract<PrivateState>>,
  ) {
    this.#logger = providers.logging.child({
      who,
      address: contract.finalizedDeployTxData.contractAddress,
    });

    // Under the hood this is expected to start a GraphQL subscription for contract data.
    // So that whenever contract state changes on-chain - Indexer pushes an update to the DApp
    const contractState$: Observable<Contract.Ledger> = providers.publicDataProvider
      .contractStateObservable(contract.finalizedDeployTxData.contractAddress, {
        type: 'latest',
      })
      .pipe(
        concatMap((contractState): Observable<Contract.Ledger> => {
          if (contractState == undefined) {
            return EMPTY;
          }
          return of(Contract.ledger(contractState.data));
        }),
        tap((state) => this.#logger.trace(prettifyLedger(state), 'New ledger state')),
      );

    this.config$ = contractState$.pipe(map((ledgerState) => costsToConfig(ledgerState.costs)));

    // This works thanks to wrapping private state provider with the subscription decorator
    const privateState$: Observable<ContractPrivateState> = providers.privateStateProvider
      .state$(contract.finalizedDeployTxData.contractAddress)
      .pipe(
        tap((state) => this.#logger.trace(prettifyPrivateState(state), 'New private state')),
        filter((maybeState): maybeState is ContractPrivateState => maybeState != undefined),
      );

    // Final state is "just" result of calling `deriveDAOState` whenever one of the other pieces changes
    this.state$ = combineLatest([contractState$, privateState$, providers.ephemeralState.state$]).pipe(
      map(([contract, priv, ephemeral]) =>
        deriveDAOState(contract, priv, ephemeral, this.coinPublicKey, this.contract.finalizedDeployTxData.contractAddress),
      ),
      tap((state) => this.#logger.trace(state, 'New DAO state')),
      shareReplay({
        bufferSize: 1,
        refCount: true,
      }),
    );
  }

  advance(): Promise<ActionId> {
    return this.callCircuit('advance', (ctx) => ctx.contract.advance());
  }

  buyIn(amount: bigint): Promise<ActionId> {
    const call: Observable<ActionId> = pipe(
      this.config$,
      map((config: DaoConfig): Contract.CoinInfo => this.newCoin(BigInt(config.buyInCoins) * amount)),
      concatMap((coin: Contract.CoinInfo) => this.callCircuit('buy_in', (ctx) => ctx.contract.buy_in(coin, amount))),
    );

    return firstValueFrom(call);
  }

  cashOut(): Promise<ActionId> {
    return this.callCircuit('cash_out', (ctx) => ctx.contract.cash_out());
  }

  initProposal(proposal: Proposal): Promise<ActionId> {
    const call: Observable<ActionId> = pipe(
      this.config$,
      map((config: DaoConfig): Contract.CoinInfo => this.newCoin(BigInt(config.seedCoins))),
      concatMap((coin: Contract.CoinInfo) => {
        // Let's extract coin public key from the string; It will work for the case when the coin key is passed alone as well as in case of full wallet address
        const beneficiary = Buffer.from(proposal.beneficiary.split('|')[0], 'hex');
        return this.callCircuit('init_proposal', (ctx) => ctx.contract.set_topic(proposal.topic, { bytes: beneficiary }, coin));
      }),
    );

    return firstValueFrom(call);
  }

  voteCommit(ballot: boolean): Promise<ActionId> {
    return this.callCircuit('commit', (ctx) => {
      const votingTokenType = tokenType(
        Contract.pureCircuits.dao_token_domain_separator(),
        this.contract.finalizedDeployTxData.contractAddress,
      );
      const votingCoin = encodeCoinInfo(createCoinInfo(votingTokenType, 1n));
      return ctx.contract.vote_commit(ballot, votingCoin);
    });
  }

  voteReveal(): Promise<ActionId> {
    return this.callCircuit('reveal', (ctx) => ctx.contract.vote_reveal());
  }

  /**
   * The structure of each circuit call is the same and abstracts nicely:
   * 1. prepare action id to return
   * 2. In background:
   *    a. Save in-progress action in ephemeral state
   *    b. Make actual call with Midnight.js, which is going to run the circuit and collect data necessary to prepare a transaction
   *    c. Prepare, prove and submit transaction through wallet provider
   *    d. Wait for state update
   *    e. Register action success
   * 3. return action id immediately to let higher layers check the status
   *
   * @param action - action name
   * @param makeCall - function that actually calls the circuit
   * @private
   */
  private callCircuit<K extends keyof Contract.Contract<unknown>['impureCircuits']>(
    action: Action,
    makeCall: (context: CallCircuitContext) => Promise<CallTx<K>>,
  ): Promise<ActionId> {
    const actionId = this.providers.crypto.randomUUID();
    const newAction: AsyncAction = {
      action,
      status: 'in_progress',
      startedAt: new Date(),
      id: actionId,
    };

    const logActionStatus = (status: string) => this.#logger.trace({ action, actionId }, status);

    const runningCall = this.providers.ephemeralState.addAction(newAction).pipe(
      tap(() => logActionStatus('Started')),
      concatMap(() => makeCall({ contract: this.contract.contractCircuitsInterface })),
      tap(() => logActionStatus('Call transaction submitted')),
      concatMap(() => firstValueFrom(this.state$.pipe(debounceTime(100)))),
      tap(() => logActionStatus('Received state after')),
      concatMap(() => this.providers.ephemeralState.succeedAction(actionId)),
      tap(() => logActionStatus('Succeeded')),
      timeout({
        first: this.config.transactionTimeout,
        with: () => throwError(() => new Error(`Action did not finish within ${this.config.transactionTimeout / 1000} seconds`)),
      }),
      catchError((err: Error) => {
        this.#logger.error({ err }, 'Contract call error');
        return this.providers.ephemeralState.failAction(actionId, err.message);
      }),
    );
    void firstValueFrom(runningCall);

    return Promise.resolve(actionId);
  }

  private newCoin(value: bigint): Contract.CoinInfo {
    return encodeCoinInfo(createCoinInfo(nativeToken(), value));
  }
}
