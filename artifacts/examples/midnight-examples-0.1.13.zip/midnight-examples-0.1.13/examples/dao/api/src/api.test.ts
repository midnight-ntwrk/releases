import fc from 'fast-check';
import { either } from 'fp-ts';
import { pipe } from 'fp-ts/function';
import { BigintStringCodec, DateCodec } from './api.js';

describe('Custom codecs', () => {
  describe('Date', () => {
    it('maintains decode(encode(x)) = x property', () => {
      fc.assert(
        fc.property(fc.date(), (date: Date) =>
          pipe(
            date,
            (date: Date) => DateCodec.decode(DateCodec.encode(date)),
            either.map((date) => date.valueOf()),
            either.map((actual) => actual === date.valueOf()),
            either.getOrElse(() => false),
          ),
        ),
      );
    });

    it('encodes to ISO string', () => {
      fc.assert(fc.property(fc.date(), (date: Date) => DateCodec.encode(date) === date.toISOString()));
    });

    it('reports an error if not an iso string provided', () => {
      fc.assert(fc.property(fc.date(), (date: Date) => either.isLeft(DateCodec.decode(date.valueOf()))));
      expect(either.isLeft(DateCodec.decode('foo'))).toBe(true);
    });

    it('is able to assert date was passed properly', () => {
      expect(DateCodec.is(new Date())).toBe(true);
    });
  });

  describe('BigInt', () => {
    it('maintains decode(encode(x)) = x property', () => {
      fc.assert(
        fc.property(fc.bigInt(), (value: bigint) =>
          pipe(
            value,
            (value: bigint) => BigintStringCodec.decode(BigintStringCodec.encode(value)),
            either.map((actual) => actual === value),
            either.getOrElse(() => false),
          ),
        ),
      );
    });

    it('encodes to decimal string', () => {
      fc.assert(fc.property(fc.bigInt(), (value: bigint) => BigintStringCodec.encode(value) === value.toString(10)));
    });

    it('reports an error if not a numeric string provided', () => {
      fc.assert(
        fc.property(
          fc.stringOf(fc.char().filter((char) => Number.isNaN(Number.parseInt(char, 10)))), //Let's build a string of characters that are not numbers
          (string: string) => either.isLeft(BigintStringCodec.decode(string)),
        ),
      );
      expect(either.isLeft(BigintStringCodec.decode('foo'))).toBe(true);
    });

    it('is able to assert bigint was passed properly', () => {
      expect(BigintStringCodec.is(BigInt(10))).toBe(true);
      expect(BigintStringCodec.is(10n)).toBe(true);
    });
  });
});
