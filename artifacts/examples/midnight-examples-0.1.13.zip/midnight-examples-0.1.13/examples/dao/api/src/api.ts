import { block, pipe, ValuesOf } from '@midnight-ntwrk/dao-helpers';
import { either } from 'fp-ts';
import * as t from 'io-ts';
import type { Observable } from 'rxjs';

/**
 * Below are definitions for 2 most important pieces of the DAO API:
 *   - the interface UI expects `DaoAPI`
 *   - state definition: `DaoState`
 */

// an enum helper needed?
export const Actions = {
  advance: 'advance',
  buyIn: 'buy_in',
  commit: 'commit',
  reveal: 'reveal',
  cashOut: 'cash_out',
  initProposal: 'init_proposal',
} as const;
export const ActionCodec = t.union([
  t.literal(Actions.advance),
  t.literal(Actions.buyIn),
  t.literal(Actions.commit),
  t.literal(Actions.reveal),
  t.literal(Actions.cashOut),
  t.literal(Actions.initProposal),
]);
export type Action = t.TypeOf<typeof ActionCodec>;

export const AsyncActionStates = {
  inProgress: 'in_progress',
  error: 'error',
  success: 'success',
} as const;
export type AsyncActionState = ValuesOf<typeof AsyncActionStates>;

export const ActionIdCodec = t.string;
export type ActionId = t.TypeOf<typeof ActionIdCodec>;

export const DateCodec = t.string.pipe(
  block(() => {
    const validate: t.Validate<string, Date> = (str, context) => {
      const candidate = new Date(str);
      if (candidate.toString() === 'Invalid Date') {
        return either.left([
          {
            value: str,
            context,
            message: `Could not parse ${str} to a Date object`,
          },
        ]);
      } else {
        return either.right(candidate);
      }
    };

    return new t.Type<Date, string, string>(
      'date',
      (value): value is Date => value instanceof Date,
      validate,
      (date) => date.toISOString(),
    );
  }),
);

export const BigintStringCodec = t.string.pipe(
  new t.Type<bigint, string, string>(
    'bigint',
    (value): value is bigint => typeof value === 'bigint' || value instanceof BigInt,
    (str, context) =>
      pipe(
        str,
        either.fromPredicate(
          (str) => str.trim() !== '',
          () => [
            {
              value: str,
              context,
              message: `Could not parse an empty string into a BigInt`,
            },
          ],
        ),
        either.chain((str) =>
          either.tryCatch(
            () => BigInt(str),
            (): t.Errors => [
              {
                value: str,
                context,
                message: `Could not parse ${str} into a BigInt`,
              },
            ],
          ),
        ),
      ),
    (bigint) => bigint.toString(10),
  ),
);

const AsyncActionCommons = t.type({
  id: ActionIdCodec,
  action: ActionCodec,
  startedAt: DateCodec,
});

export const AsyncActionCodec = t.intersection([
  AsyncActionCommons,
  t.union([
    t.type({
      status: t.literal(AsyncActionStates.inProgress),
    }),
    t.type({
      status: t.literal(AsyncActionStates.error),
      error: t.string,
    }),
    t.type({
      status: t.literal(AsyncActionStates.success),
    }),
  ]),
]);
export type AsyncAction = t.TypeOf<typeof AsyncActionCodec>;
export const AsyncAction = block(() => {
  const succeeded = (action: AsyncAction): AsyncAction => ({
    ...action,
    status: 'success',
  });

  const failed =
    (error: string) =>
    (action: AsyncAction): AsyncAction => ({
      ...action,
      status: 'error',
      error,
    });

  return { succeeded, failed };
});

export const OrganizerStates = {
  notAnOrganizer: 'not_an_organizer',
  canAdvance: 'can_advance',
  canInitProposal: 'can_init_proposal',
  initInProgress: 'init_in_progress',
  cannotAdvance: 'cant_advance',
  advanceInProgress: 'advance_in_progress',
} as const;
export type OrganizerState = ValuesOf<typeof OrganizerStates>;

export const OrganizerCodec = t.union([
  t.type({
    state: t.literal(OrganizerStates.notAnOrganizer),
  }),
  t.type({
    state: t.literal(OrganizerStates.canInitProposal),
  }),
  t.type({
    state: t.literal(OrganizerStates.initInProgress),
    actionId: ActionIdCodec,
  }),
  t.type({
    state: t.literal(OrganizerStates.canAdvance),
  }),
  t.type({
    state: t.literal(OrganizerStates.cannotAdvance),
  }),
  t.type({
    state: t.literal(OrganizerStates.advanceInProgress),
    actionId: ActionIdCodec,
  }),
]);
export type Organizer = t.TypeOf<typeof OrganizerCodec>;

export const BeneficiaryStates = {
  notBeneficiary: 'not_beneficiary',
  waitingForFinal: 'waiting_for_final',
  finalCanCashOut: 'final_can_cash_out',
  finalCantCashOut: 'final_cant_cash_out',
  cashingOut: 'cashing_out',
} as const;
export type BeneficiaryState = ValuesOf<typeof BeneficiaryStates>;

export const BeneficiaryCodec = t.union([
  t.type({
    state: t.literal(BeneficiaryStates.notBeneficiary),
  }),
  t.type({
    state: t.literal(BeneficiaryStates.waitingForFinal),
  }),
  t.type({
    state: t.literal(BeneficiaryStates.finalCanCashOut),
  }),
  t.type({
    state: t.literal(BeneficiaryStates.cashingOut),
    actionId: ActionIdCodec,
  }),
  t.type({
    state: t.literal(BeneficiaryStates.finalCantCashOut),
  }),
]);
export type Beneficiary = t.TypeOf<typeof BeneficiaryCodec>;

export const VoterStates = {
  initial: 'initial',
  buyingIn: 'buying_in',
  canCommit: 'can_commit',
  committing: 'committing',
  committed: 'committed',
  canReveal: 'can_reveal',
  revealing: 'revealing',
  revealed: 'revealed',
  final: 'final',
  disenfranchised: 'disenfranchised',
} as const;
export type VoterState = ValuesOf<typeof VoterStates>;

export const VoterCodec = t.union([
  t.type({
    state: t.literal(VoterStates.initial),
    canBuyIn: t.boolean,
  }),
  t.type({
    state: t.literal(VoterStates.buyingIn),
    actionId: ActionIdCodec,
  }),
  t.type({
    state: t.literal(VoterStates.canCommit),
  }),
  t.type({
    state: t.literal(VoterStates.committing),
    actionId: ActionIdCodec,
  }),
  t.type({
    state: t.literal(VoterStates.committed),
    ballot: t.boolean,
  }),
  t.type({
    state: t.literal(VoterStates.canReveal),
    ballot: t.boolean,
  }),
  t.type({
    state: t.literal(VoterStates.revealing),
    actionId: ActionIdCodec,
  }),
  t.type({
    state: t.literal(VoterStates.revealed),
  }),
  t.type({
    state: t.literal(VoterStates.final),
  }),
  t.type({
    state: t.literal(VoterStates.disenfranchised),
  }),
]);
export type Voter = t.TypeOf<typeof VoterCodec>;

export const UserAddressCodec = t.string;

export const ProposalCodec = t.type({ topic: t.string, beneficiary: UserAddressCodec });
export type Proposal = t.TypeOf<typeof ProposalCodec>;

export const BallotCodec = t.boolean;
export type Ballot = t.TypeOf<typeof BallotCodec>;

export const VotingStates = {
  commit: 'commit',
  reveal: 'reveal',
  finalCashOut: 'final_cash_out',
  finalNegative: 'final_negative',
} as const;
export type VotingState = ValuesOf<typeof VotingStates>;

const VotingResult = t.type({
  votesYes: t.number,
  votesNo: t.number,
});
const VotingCommon = t.type({
  proposal: ProposalCodec,
  committed: t.number, // should be uint or sth similar
  revealed: t.number,
});

export const VotingCodec = t.intersection([
  t.type({
    state: t.union([
      t.literal(VotingStates.commit),
      t.literal(VotingStates.reveal),
      t.literal(VotingStates.finalCashOut),
      t.literal(VotingStates.finalNegative),
    ]),
  }),
  VotingResult,
  VotingCommon,
]);
export type Voting = t.TypeOf<typeof VotingCodec>;

export const States = {
  setup: 'setup',
  initialized: 'initialized',
} as const;
export type State = ValuesOf<typeof States>;

export const CommonStateCodec = t.type({
  organizer: OrganizerCodec,
  voter: VoterCodec,
  actions: t.type({
    latest: t.union([ActionIdCodec, t.null]),
    all: t.record(ActionIdCodec, AsyncActionCodec),
  }),
  tokenType: t.string,
});

export const DaoStateCodec = t.union([
  t.intersection([
    t.type({
      state: t.literal(States.setup),
      pot: t.union([t.null, t.number]), // Pot should rather be a bigint encoded to string, we'll do it later
    }),
    CommonStateCodec,
  ]),
  t.intersection([
    t.type({
      state: t.literal(States.initialized),
      voting: VotingCodec,
      pot: t.number, // Pot should rather be a bigint encoded to string, we'll do it later
      beneficiary: BeneficiaryCodec,
    }),
    CommonStateCodec,
  ]),
]);
export type DaoState = t.TypeOf<typeof DaoStateCodec>;

export const DaoConfigCodec = t.type({
  seedCoins: t.number,
  buyInCoins: t.number,
});
export type DaoConfig = t.TypeOf<typeof DaoConfigCodec>;

/**
 * Definition of common, implementation- and technology-agnostic, DAO API. Its existence and shape may be disputable
 * depending on a case, but overall the pros and cons are of similar kinds as when working with e.g. HTTP-based APIs:
 *   - it allows to drive the API by the consumer code, which should lead to a fairly minimal, yet complete API
 *     surface, which (preferably) does not leak implementation details
 *   - it allows implementation and integration of the frontend in parallel with actual contract and Midnight.js-based
 *     implementation by providing a fake implementation in JS
 *   - it allows to write shared set of test cases, which can be used to drive all the implementations needed:
 *     - fake
 *     - contract code
 *     - Midnight.js integration
 *     - future contract rewrites
 *
 * There are a couple of important points about this API in particular:
 *   - state being an observable and operations returning immediately force to implement the state
 *     management in a way friendly to the UI code (and is similar to e.g. MobX, Redux, Elm architecture or Bloc
 *     pattern in many ways)
 *   - usage of io-ts imposes some overhead, but provides possibility to reliably using the API in scenarios, where
 *     type information is being lost, like: web sockets, web workers, or other forms of messaging
 *   - using the observables for state allows to hide the exact model being used - it might be polling, it might
 *     be push-based notification, it might be mixture of both
 */
export interface DaoAPI {
  state$: Observable<DaoState>;
  config$: Observable<DaoConfig>;
  advance: () => Promise<ActionId>;
  initProposal: (proposal: Proposal) => Promise<ActionId>;
  buyIn: (amount: bigint) => Promise<ActionId>;
  voteCommit: (ballot: boolean) => Promise<ActionId>;
  voteReveal: () => Promise<ActionId>;
  cashOut: () => Promise<ActionId>;
}
