import { expect } from '@jest/globals';
import {
  ActionId,
  AsyncAction,
  AsyncActionStates,
  DaoAPI,
  DaoState,
  OrganizerState,
  OrganizerStates,
  States,
  VoterState,
  VotingState,
  VotingStates,
} from '@midnight-ntwrk/dao-api';
import { RecursivePartial } from '@midnight-ntwrk/dao-helpers';
import { pipe } from 'fp-ts/function';
import { filter, firstValueFrom, map, Observable, take } from 'rxjs';
import { DaoAPITestContext } from './api-test.js';

export interface Assertions<T> {
  equal: (expected: T) => void;
  // eslint-disable-next-line @typescript-eslint/ban-types
  matchObject: <E extends T & {}>(expected: RecursivePartial<E>) => void;
}
export const assert = <T>(actual: T): Assertions<T> => {
  const equal = (expected: T): void => expect(actual).toEqual(expected);

  // eslint-disable-next-line @typescript-eslint/ban-types
  const matchObject = (expected: RecursivePartial<T> & {}): void => expect(actual).toMatchObject(expected);

  return { equal, matchObject };
};

export interface Person {
  readonly api: DaoAPI;
  readonly address: string;
}

export const waitFor = <T>(input$: Observable<T>, predicate: (t: T) => boolean): Promise<T> =>
  pipe(input$, filter(predicate), take(1), (r) => firstValueFrom(r));

export const waitForError = (input$: Observable<DaoState>, actionId: ActionId): Promise<DaoState> => {
  return waitFor(input$, (state) => state.actions.all[actionId].status === AsyncActionStates.error);
};

export const waitForSuccess = (input$: Observable<DaoState>, actionId: ActionId): Promise<DaoState> => {
  return waitForState(input$, (state) => state.actions.all[actionId].status === AsyncActionStates.success);
};

export const waitForCompletion = (input$: Observable<DaoState>, actionId: ActionId): Promise<DaoState> => {
  return waitFor(input$, (state) => state.actions.all[actionId].status !== AsyncActionStates.inProgress);
};

export const waitForState = (input$: Observable<DaoState>, predicate: (state: DaoState) => boolean): Promise<DaoState> => {
  const source$ = input$.pipe(
    map((state) => {
      const actions = Object.values(state.actions.all);
      const foundError = actions.find(
        (action): action is AsyncAction & { status: 'error' } => action.status === AsyncActionStates.error,
      );

      if (foundError) {
        throw new Error(foundError.error);
      } else {
        return state;
      }
    }),
  );
  return waitFor(source$, predicate);
};

export async function waitForOrganizerState(
  organizer: Person,
  votingState: VotingState,
  organizerState: OrganizerState,
): Promise<DaoState> {
  return await waitForState(
    organizer.api.state$,
    (state) =>
      state.state === States.initialized && state.organizer.state === organizerState && state.voting.state === votingState,
  );
}

export async function waitForCommittedVote(organizer: Person): Promise<DaoState> {
  return await waitForState(
    organizer.api.state$,
    (state) =>
      state.organizer.state === OrganizerStates.canAdvance &&
      state.state === States.initialized &&
      state.voting.state === VotingStates.commit &&
      state.voting.committed === 1,
  );
}

export async function waitForRevealedVote(organizer: Person): Promise<DaoState> {
  return await waitForState(
    organizer.api.state$,
    (state) =>
      state.organizer.state === OrganizerStates.canAdvance &&
      state.state === States.initialized &&
      state.voting.state === VotingStates.reveal &&
      state.voting.revealed === 1,
  );
}

export async function waitForVoterState(voter: Person, expectedState: VoterState): Promise<DaoState> {
  return await waitForState(
    voter.api.state$,
    (state) => state.state === States.initialized && state.voter.state === expectedState,
  );
}

export async function waitForVotingState(voter: Person, expectedState: VotingState): Promise<DaoState> {
  return await waitForState(
    voter.api.state$,
    (state) => state.state === States.initialized && state.voting.state === expectedState,
  );
}

export async function waitForInitializedState(organizer: Person, voter: Person): Promise<void> {
  await waitForState(organizer.api.state$, (state) => state.state === States.initialized);
  await waitForState(voter.api.state$, (state) => state.state === States.initialized);
}

export async function organizerInitializesProposal<T = unknown>(
  context: DaoAPITestContext<T>,
  organizer: Person,
  beneficiary: Person,
  proposalTopic: string,
): Promise<string> {
  context.logger.debug('Organizer initializes proposal');
  return await organizer.api.initProposal({
    topic: proposalTopic,
    beneficiary: beneficiary.address,
  });
}
