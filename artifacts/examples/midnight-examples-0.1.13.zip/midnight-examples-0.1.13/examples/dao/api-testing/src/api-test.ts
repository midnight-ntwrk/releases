import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it as jit } from '@jest/globals';
import {
  Actions,
  AsyncActionStates,
  BeneficiaryStates,
  DaoAPI,
  DaoConfig,
  DaoState,
  OrganizerStates,
  States,
  VoterStates,
  VotingStates,
} from '@midnight-ntwrk/dao-api';
import { Logger, Resource, block } from '@midnight-ntwrk/dao-helpers';
import * as fc from 'fast-check';
import { pipe } from 'fp-ts/function';
import { firstValueFrom } from 'rxjs';
import {
  assert,
  organizerInitializesProposal,
  Person,
  waitFor,
  waitForCommittedVote,
  waitForCompletion,
  waitForError,
  waitForInitializedState,
  waitForOrganizerState,
  waitForRevealedVote,
  waitForState,
  waitForSuccess,
  waitForVoterState,
  waitForVotingState,
} from './test-helpers.js';

const proposalTopic = 'Build a bridge to the sky?';

export interface GetAPIOptions {
  organizer: boolean;
  number: number;
}

export type DaoSuite = 'smoke' | 'full';
export interface DaoAPITestContext<T = unknown> {
  implementationName: string;
  suite: DaoSuite;
  infrastructure: () => Resource<T>;
  instance: (config: DaoConfig, infrastructure: T) => Resource<DAOInstance>; // such structure allows to run integration tests with real contract too
  logger: Logger;
  implementationSpecificSuite?: (environment: { getInfrastructure: () => T }) => () => void;
}

export interface DAOInstance {
  getAPI: (options: GetAPIOptions) => Resource<{ api: DaoAPI; address: string }>;
}

/**
 * Main function that wraps calls to `describe`, `it`, etc. as a means to define a single test suite being executed
 * against different implementations of the same interface
 * @param context - Provides all necessary structure to let the tests be defined
 */
export function runDaoAPITest<T = unknown>(context: DaoAPITestContext<T>): void {
  /**
   * A wrapper for jest functions, which allows to define which cases should be run in what scenario
   */
  const it = {
    skip: (): typeof jit.skip => jit.skip,
    full: (): typeof jit | typeof jit.skip => {
      if (context.suite === 'full') {
        return jit;
      } else {
        return jit.skip;
      }
    },
    smoke: (): typeof jit | typeof jit.skip => {
      if (context.suite === 'smoke' || context.suite === 'full') {
        return jit;
      } else {
        return jit.skip;
      }
    },
  };

  describe(`${context.implementationName} DAO API implementation`, () => {
    let infrastructure: T;
    let infrastructureTeardown: () => Promise<void>;

    beforeAll(async () => {
      const { value, teardown } = await context.infrastructure().allocate();
      infrastructure = value;
      infrastructureTeardown = teardown;
    });

    afterAll(async () => {
      await infrastructureTeardown();
    });

    describe('common cases', () => {
      beforeEach(() => {
        const currentTest = expect.getState();
        context.logger.debug(
          { test: currentTest.currentTestName, testPath: currentTest.testPath },
          `Starting ${currentTest.currentTestName ?? ''}`,
        );
      });

      afterEach(() => {
        const currentTest = expect.getState();
        context.logger.trace(
          { test: currentTest.currentTestName, testPath: currentTest.testPath },
          `Finished ${currentTest.currentTestName ?? ''}`,
        );
      });

      describe('initialized with standard prices', () => {
        let instance: DAOInstance;
        let instanceTeardown: () => Promise<void>;

        const config: DaoConfig = {
          seedCoins: 10_000_000,
          buyInCoins: 2_000_000,
        };

        beforeEach(async () => {
          const { value, teardown } = await context.instance(config, infrastructure).allocate();
          context.logger.debug('Initialized instance', { instance });
          instance = value;
          instanceTeardown = teardown;
        });

        afterEach(() => {
          context.logger.debug('Tearing instance down');
          return instanceTeardown();
        });

        describe('proposal initialization', () => {
          it.smoke()('succeeds for an organizer', () => {
            context.logger.debug('initialization succeeds for an organizer started');
            return pipe(
              instance.getAPI({ organizer: true, number: 1 }),
              Resource.zip(instance.getAPI({ organizer: false, number: 2 })),
              Resource.use(async ([organizer, beneficiary]: [Person, Person]) => {
                const stateBefore = await firstValueFrom(organizer.api.state$);
                context.logger.debug('Got initial state', stateBefore);
                await waitForState(organizer.api.state$, (s) => s.organizer.state === OrganizerStates.canInitProposal);
                context.logger.debug('Organizer can init proposal');
                // In this way we make sure that no matter how quickly it happens, we catch in-progress state
                const stateDuringP = waitForState(
                  organizer.api.state$,
                  (s) => s.organizer.state === OrganizerStates.initInProgress,
                );
                const initId = await organizerInitializesProposal(context, organizer, beneficiary, proposalTopic);

                const stateDuring = await stateDuringP;
                context.logger.debug('Got state during initialization', stateDuring);
                const stateAfter = await waitForState(organizer.api.state$, (s) => s.state === States.initialized);
                context.logger.debug('Got state after initialization', stateAfter);

                context.logger.debug('Proceeding to assertions');
                assert(stateBefore.state).equal(States.setup);
                assert(stateBefore.organizer).equal({
                  state: OrganizerStates.canInitProposal,
                });
                assert(stateDuring.state).equal(States.setup);
                assert(stateDuring.organizer).equal({
                  state: OrganizerStates.initInProgress,
                  actionId: initId,
                });
                assert(stateAfter).matchObject({
                  state: States.initialized,
                  organizer: {
                    state: OrganizerStates.canAdvance,
                  },
                  voting: {
                    state: VotingStates.commit,
                    proposal: {
                      topic: proposalTopic,
                      beneficiary: beneficiary.address,
                    },
                  },
                });
              }),
            );
          });

          it.full()('requires seed coins for pot', () => {
            return pipe(
              instance.getAPI({ organizer: true, number: 1 }),
              Resource.zip(instance.getAPI({ organizer: false, number: 2 })),
              Resource.use(async ([organizer, beneficiary]: [Person, Person]) => {
                await waitForState(organizer.api.state$, (state) => state.organizer.state === OrganizerStates.canInitProposal);
                await organizerInitializesProposal(context, organizer, beneficiary, proposalTopic);
                const initializedState = await waitForState(organizer.api.state$, (state) => state.state === States.initialized);
                context.logger.trace({ initializedState }, 'Initialized state');

                assert(initializedState).matchObject({
                  pot: Number(config.seedCoins),
                });
              }),
            );
          });
        });

        describe('finishing proposal', () => {
          it.full()('is allowed by advance in case of no voting', async () => {
            return await pipe(
              instance.getAPI({ organizer: true, number: 1 }),
              Resource.zip(instance.getAPI({ organizer: false, number: 2 })),
              Resource.use(async ([organizer, beneficiary]: [Person, Person]) => {
                const stateBefore = await firstValueFrom(organizer.api.state$);
                await organizerInitializesProposal(context, organizer, beneficiary, proposalTopic);

                await waitForOrganizerState(organizer, VotingStates.commit, OrganizerStates.canAdvance);
                await organizer.api.advance(); // to reveal
                await waitForOrganizerState(organizer, VotingStates.reveal, OrganizerStates.canAdvance);
                await organizer.api.advance(); // to final
                await waitForOrganizerState(organizer, VotingStates.finalNegative, OrganizerStates.canAdvance);

                const advanceId = await organizer.api.advance(); // back to setup
                const stateAfter = await waitForCompletion(organizer.api.state$, advanceId);

                assert(stateBefore).matchObject({
                  state: States.setup,
                  organizer: {
                    state: OrganizerStates.canInitProposal,
                  },
                });
                assert(stateAfter).matchObject({
                  state: States.setup,
                  organizer: {
                    state: OrganizerStates.canInitProposal,
                  },
                  actions: {
                    latest: advanceId,
                    all: {
                      [advanceId]: {
                        status: AsyncActionStates.success,
                      },
                    },
                  },
                });
              }),
            );
          });

          it.skip()('prevents new buyins', async () => {
            const organizer = (
              await instance
                .getAPI({
                  organizer: true,
                  number: 1,
                })
                .allocate()
            ).value;
            const voter = (await instance.getAPI({ organizer: false, number: 2 }).allocate()).value;
            const lateBuyinVoter = (
              await instance
                .getAPI({
                  organizer: false,
                  number: 3,
                })
                .allocate()
            ).value;
            await organizerInitializesProposal(context, organizer, voter, proposalTopic);
            await waitForVotingState(voter, VotingStates.commit);
            await voter.api.buyIn(1n);
            await waitForVoterState(voter, VoterStates.canCommit);
            await voter.api.voteCommit(true);
            await waitForCommittedVote(organizer);
            await organizer.api.advance(); // advance to reveal
            await waitForVoterState(voter, VoterStates.canReveal);
            await voter.api.voteReveal();
            await waitForRevealedVote(organizer);
            await organizer.api.advance(); // advance to final
            await waitForOrganizerState(organizer, VotingStates.finalCashOut, OrganizerStates.cannotAdvance);
            await lateBuyinVoter.api.buyIn(1n);
            const voterState = await waitForState(lateBuyinVoter.api.state$, () => true);
            expect(voterState.voter.state).toBe('initial');
            expect((voterState.voter as { canBuyIn: boolean }).canBuyIn).toBe(false);
          });

          it.full()('is not allowed by advance in case of positive voting', () => {
            return pipe(
              instance.getAPI({ organizer: true, number: 1 }),
              Resource.zip(instance.getAPI({ organizer: false, number: 2 })),
              Resource.use(async ([organizer, voter]: [Person, Person]) => {
                await organizerInitializesProposal(context, organizer, voter, proposalTopic);
                await waitForVotingState(voter, VotingStates.commit);
                await voter.api.buyIn(1n);
                await waitForVoterState(voter, VoterStates.canCommit);
                await voter.api.voteCommit(true);
                await waitForCommittedVote(organizer);
                await organizer.api.advance(); // advance to reveal
                await waitForVoterState(voter, VoterStates.canReveal);
                await voter.api.voteReveal();
                await waitForRevealedVote(organizer);
                await organizer.api.advance(); // advance to final
                await waitForOrganizerState(organizer, VotingStates.finalCashOut, OrganizerStates.cannotAdvance);
                const advanceId = await organizer.api.advance(); // advance back to setup
                const resultState = await waitForError(organizer.api.state$, advanceId);

                assert(resultState).matchObject({
                  state: States.initialized,
                  voting: {
                    state: VotingStates.finalCashOut,
                  },
                  organizer: {
                    state: OrganizerStates.cannotAdvance,
                  },
                  actions: {
                    latest: advanceId,
                    all: {
                      [advanceId]: {
                        status: AsyncActionStates.error,
                      },
                    },
                  },
                });
              }),
            );
          });

          it.full()('by advance resets local vote', () => {
            return pipe(
              instance.getAPI({ organizer: true, number: 1 }),
              Resource.zip(instance.getAPI({ organizer: false, number: 2 })),
              Resource.use(async ([organizer, voter]: [Person, Person]) => {
                await organizer.api.initProposal({
                  topic: 'Build a bridge to the sky?',
                  beneficiary: organizer.address,
                });

                await waitForState(voter.api.state$, (state) => state.state === States.initialized);
                await voter.api.buyIn(1n);
                await waitForState(voter.api.state$, (state) => state.voter.state === VoterStates.canCommit);
                await voter.api.voteCommit(false);

                await waitForState(
                  organizer.api.state$,
                  (state) =>
                    state.state === States.initialized &&
                    state.voting.committed === 1 &&
                    state.organizer.state === OrganizerStates.canAdvance,
                );
                await organizer.api.advance(); // to reveal

                await waitForState(voter.api.state$, (state) => state.voter.state === VoterStates.canReveal);
                await voter.api.voteReveal();

                await waitForState(
                  organizer.api.state$,
                  (state) =>
                    state.state === States.initialized &&
                    state.voting.revealed === 1 &&
                    state.organizer.state === OrganizerStates.canAdvance,
                );

                await organizer.api.advance(); // to final

                await waitForState(
                  organizer.api.state$,
                  (state) =>
                    state.state === States.initialized &&
                    state.voting.state === VotingStates.finalNegative &&
                    state.organizer.state === OrganizerStates.canAdvance,
                );
                await organizer.api.advance(); // back to setup
                await waitForState(organizer.api.state$, (state) => state.organizer.state === OrganizerStates.canInitProposal);

                await waitForState(organizer.api.state$, (state) => state.state === States.setup);
                const stateBeforeInit = await waitForState(voter.api.state$, (state) => state.state === States.setup);
                context.logger.debug({ stateBeforeInit }, 'Got state before init, initializing proposal');
                const initActionId = await organizer.api.initProposal({
                  topic: 'Build a bridge to the sky?',
                  beneficiary: organizer.address,
                });

                context.logger.debug({ initActionId }, 'Scheduled proposal init, waiting for voter state after initialization');
                const organizerStateAfterInit = await waitForState(organizer.api.state$, (state) => {
                  context.logger.trace({ initAction: state.actions.all[initActionId] }, 'Waiting for proposal init to finish');
                  return state.actions.all[initActionId].status != AsyncActionStates.inProgress;
                });
                context.logger.trace({ initAction: organizerStateAfterInit.actions.all[initActionId] }, 'Proposal init finished');
                // It would be nicer to wait for just setup, but this would require changes in state management, to allow for hooks without intermediate states
                const stateAfterInit = await waitForState(voter.api.state$, (state) => {
                  context.logger.trace(
                    { state, proposalState: state.state, voterState: state.voter.state },
                    'Waiting for state after initialization',
                  );
                  return state.state === States.initialized && state.voter.state === VoterStates.canCommit;
                });

                assert(stateBeforeInit).matchObject({
                  state: States.setup,
                  voter: {
                    state: VoterStates.initial,
                  },
                });

                assert(stateAfterInit).matchObject({
                  state: States.initialized,
                  voter: {
                    state: VoterStates.canCommit,
                  },
                });
              }),
            );
          });
        });

        describe('when a voter', () => {
          it.full()('does not allow to initialize the proposal', async () => {
            await instance.getAPI({ organizer: true, number: 1 }).allocate();
            const voter = (await instance.getAPI({ organizer: false, number: 2 }).allocate()).value;
            const initId = await voter.api.initProposal({
              topic: proposalTopic,
              beneficiary: voter.address,
            });

            const resultState = await waitForError(voter.api.state$, initId);

            assert(resultState).matchObject({
              state: States.setup,
              voter: {
                state: VoterStates.initial,
                canBuyIn: true,
              },
              organizer: {
                state: OrganizerStates.notAnOrganizer,
              },
              actions: {
                latest: initId,
                all: {
                  [initId]: {
                    status: AsyncActionStates.error,
                  },
                },
              },
            });
          });

          it.full()('does allow to buy in', () => {
            return pipe(
              instance.getAPI({ organizer: true, number: 1 }),
              Resource.zip(instance.getAPI({ organizer: false, number: 2 })),
              Resource.use(async ([organizer, voter]) => {
                await organizerInitializesProposal(context, organizer, voter, proposalTopic);
                await waitForInitializedState(organizer, voter);
                await voter.api.buyIn(1n);
                const boughtInState = await waitForVoterState(voter, VoterStates.canCommit);

                assert(boughtInState.voter.state).equal(VoterStates.canCommit);
              }),
            );
          });

          it.full()('requires at least one voting token to be bought, but not more then max Unsigned Integer[64]', () => {
            return pipe(
              instance.getAPI({ organizer: true, number: 1 }),
              Resource.zip(instance.getAPI({ organizer: false, number: 2 })),
              Resource.use(async ([organizer, voter]) => {
                await organizerInitializesProposal(context, organizer, voter, proposalTopic);
                await waitForInitializedState(organizer, voter);

                await fc.assert(
                  fc.asyncProperty(fc.oneof(fc.bigInt({ max: 0n }), fc.bigInt({ min: 2n ** 64n })), async (amount) => {
                    const actionId = await voter.api.buyIn(amount);
                    const result = await waitForCompletion(voter.api.state$, actionId);
                    return result.actions.all[actionId].status === AsyncActionStates.error;
                  }),
                );

                const [amount] = fc.sample(fc.bigInt({ min: 1n, max: 10_000n }), 1);
                const actionId = await voter.api.buyIn(amount);
                const boughtInState = await waitForCompletion(voter.api.state$, actionId);

                assert(boughtInState.voter.state).equal(VoterStates.canCommit);
              }),
            );
          });

          it.skip()('does not allow to advance', async () => {
            const organizer = (
              await instance
                .getAPI({
                  organizer: true,
                  number: 1,
                })
                .allocate()
            ).value;
            const voter = (await instance.getAPI({ organizer: false, number: 2 }).allocate()).value;
            await organizerInitializesProposal(context, organizer, voter, proposalTopic);
            await waitForInitializedState(organizer, voter);
            await voter.api.buyIn(1n);
            await waitForState(voter.api.state$, (state) => state.voter.state === VoterStates.canCommit);
            await voter.api.voteCommit(true);
            await waitForCommittedVote(organizer);
            await voter.api.advance();
            // await waitForOrganizerState(voter, VotingStates.reveal, OrganizerStates.canAdvance);
            const stateAfterAdvance = await waitForState(voter.api.state$, () => true);
            expect(stateAfterAdvance.voter.state).toBe(VoterStates.canCommit);
          });

          it.smoke()('should go all the way to the final stage with committing and revealing', () => {
            return pipe(
              instance.getAPI({ organizer: true, number: 1 }),
              Resource.zip(instance.getAPI({ organizer: false, number: 2 })),
              Resource.use(async ([organizer, voter]) => {
                await organizerInitializesProposal(context, organizer, voter, proposalTopic);
                await waitForInitializedState(organizer, voter);
                await voter.api.buyIn(1n);
                await waitForState(voter.api.state$, (state) => state.voter.state === VoterStates.canCommit);
                await voter.api.voteCommit(true);
                await waitForCommittedVote(organizer);
                await organizer.api.advance(); // advance to reveal
                await waitForState(voter.api.state$, (state) => state.voter.state === VoterStates.canReveal);
                await waitForCompletion(voter.api.state$, await voter.api.voteReveal());
                await waitForRevealedVote(organizer);
                const finalState = await waitForCompletion(organizer.api.state$, await organizer.api.advance()); // advance to final

                assert(finalState).matchObject({
                  state: States.initialized,
                  pot: Number(config.seedCoins + config.buyInCoins),
                  voting: {
                    state: VotingStates.finalCashOut,
                    votesYes: 1,
                  },
                  organizer: {
                    state: OrganizerStates.cannotAdvance,
                  },
                });
              }),
            );
          });

          it.full()('should go back to bought in stage when going from final stage through cash out', async () => {
            const organizer = (
              await instance
                .getAPI({
                  organizer: true,
                  number: 1,
                })
                .allocate()
            ).value;
            const voter = (await instance.getAPI({ organizer: false, number: 2 }).allocate()).value;
            const beneficiary = (
              await instance
                .getAPI({
                  organizer: false,
                  number: 3,
                })
                .allocate()
            ).value;
            await organizerInitializesProposal(context, organizer, beneficiary, proposalTopic);
            await waitForState(voter.api.state$, (state) => state.state === States.initialized);
            await voter.api.buyIn(1n);
            await waitForState(voter.api.state$, (state) => state.voter.state === VoterStates.canCommit);
            await voter.api.voteCommit(true);
            await waitForCommittedVote(organizer);
            await organizer.api.advance();
            await waitForState(voter.api.state$, (state) => state.voter.state === VoterStates.canReveal);
            await voter.api.voteReveal();
            await waitForRevealedVote(organizer);
            await organizer.api.advance();
            context.logger.debug('Beneficiary waiting for cash out stage');
            await waitForState(beneficiary.api.state$, (state) => {
              return state.state === States.initialized && state.beneficiary.state === BeneficiaryStates.finalCanCashOut;
            });
            context.logger.debug('Beneficiary ready to cash out');
            await beneficiary.api.cashOut();
            const finalVoterState = await waitForState(voter.api.state$, (state) => {
              return state.state === States.setup;
            });
            const finalOrganizerState = await waitForState(organizer.api.state$, (state) => {
              return state.state === States.setup;
            });
            assert(finalVoterState).matchObject({
              state: 'setup',
              pot: null,
              voter: {
                state: VoterStates.initial,
              },
            });
            assert(finalOrganizerState).matchObject({
              state: 'setup',
              pot: null,
              organizer: {
                state: OrganizerStates.canInitProposal,
              },
            });
          });

          it.full()('should go back to bought in stage when going from final stage through advance', async () => {
            const organizer = (
              await instance
                .getAPI({
                  organizer: true,
                  number: 1,
                })
                .allocate()
            ).value;
            const voter = (await instance.getAPI({ organizer: false, number: 2 }).allocate()).value;
            const config = await firstValueFrom(organizer.api.config$);
            await organizerInitializesProposal(context, organizer, voter, proposalTopic);
            await waitForState(voter.api.state$, (state) => state.state === States.initialized);
            await voter.api.buyIn(1n);
            await waitForVoterState(voter, VoterStates.canCommit);
            await voter.api.voteCommit(false);
            await waitForVoterState(voter, VoterStates.committed);
            await organizer.api.advance(); // advance to reveal
            await waitForVoterState(voter, VoterStates.canReveal);
            await voter.api.voteReveal();
            await waitForRevealedVote(organizer);
            await organizer.api.advance(); // advance to final
            await waitForOrganizerState(organizer, VotingStates.finalNegative, OrganizerStates.canAdvance);
            await organizer.api.advance(); // advance back to setup
            const finalVoterState = await waitForState(voter.api.state$, (state) => {
              return state.state === States.setup;
            });
            const finalOrganizerState = await waitForState(organizer.api.state$, (state) => {
              return state.state === States.setup;
            });

            assert(finalVoterState).matchObject({
              state: 'setup',
              pot: Number(config.seedCoins + config.buyInCoins),
              voter: {
                state: VoterStates.initial,
              },
            });
            assert(finalOrganizerState).matchObject({
              state: 'setup',
              pot: Number(config.seedCoins + config.buyInCoins),
              organizer: {
                state: OrganizerStates.canInitProposal,
              },
            });
          });
        });

        describe('as the organiser', () => {
          it.full()('it is possible to buy in', async () => {
            return pipe(
              instance.getAPI({ organizer: true, number: 1 }),
              Resource.zip(instance.getAPI({ organizer: false, number: 2 })),
              Resource.use(async ([organizer, voter]) => {
                const config = await firstValueFrom(organizer.api.config$);
                await organizerInitializesProposal(context, organizer, voter, proposalTopic);
                await waitForVotingState(organizer, VotingStates.commit);
                const buyInId = await organizer.api.buyIn(1n);
                const boughtInState = await waitForSuccess(organizer.api.state$, buyInId);
                expect(boughtInState.pot).toBe(config.seedCoins + config.buyInCoins);
              }),
            );
          });

          it.full()('it is not possible to cash out', () => {
            return pipe(
              instance.getAPI({ organizer: true, number: 1 }),
              Resource.zip(instance.getAPI({ organizer: false, number: 2 })),
              Resource.use(async ([organizer, voter]) => {
                await firstValueFrom(organizer.api.config$);
                await organizerInitializesProposal(context, organizer, voter, proposalTopic);
                await waitForInitializedState(organizer, voter);
                await voter.api.buyIn(1n);
                await waitForVoterState(voter, VoterStates.canCommit);
                await voter.api.voteCommit(true);
                await waitForCommittedVote(organizer);
                await organizer.api.advance(); // advance to reveal
                await waitForVoterState(voter, VoterStates.canReveal);
                await voter.api.voteReveal();
                await waitForRevealedVote(organizer);
                await organizer.api.advance(); // advance to final
                await waitForVotingState(organizer, VotingStates.finalCashOut);
                await waitForState(organizer.api.state$, () => true);
                await organizer.api.cashOut();
                const afterCashOut = await waitFor(organizer.api.state$, () => true);
                expect(afterCashOut.pot).toBeGreaterThan(0);
              }),
            );
          });
        });

        describe('ending up in disenfranchised state', () => {
          it.full()('should happen when buy in happens in reveal phase', () => {
            return pipe(
              instance.getAPI({ organizer: true, number: 1 }),
              Resource.zip(instance.getAPI({ organizer: false, number: 2 })),
              Resource.use(async ([organizer, voter]) => {
                await organizerInitializesProposal(context, organizer, voter, proposalTopic);
                await waitForOrganizerState(organizer, VotingStates.commit, OrganizerStates.canAdvance);
                await organizer.api.advance(); // advance to reveal
                await waitForVotingState(voter, VotingStates.reveal);
                const buyInId = await voter.api.buyIn(1n);
                const voterState = await waitForState(
                  voter.api.state$,
                  (state) =>
                    state.actions.all[buyInId].status === AsyncActionStates.success && state.state === States.initialized,
                );

                assert(voterState.voter.state).equal(VoterStates.disenfranchised);
              }),
            );
          });

          it.full()("should happen when advance happens while voter didn't commit", async () => {
            const organizer = (
              await instance
                .getAPI({
                  organizer: true,
                  number: 1,
                })
                .allocate()
            ).value;
            const voter = (await instance.getAPI({ organizer: false, number: 2 }).allocate()).value;
            await organizerInitializesProposal(context, organizer, voter, proposalTopic);
            await waitForVotingState(voter, VotingStates.commit);
            await voter.api.buyIn(1n);
            await waitForVoterState(voter, VoterStates.canCommit);
            await organizer.api.advance(); // advance to reveal
            const voterState = await waitForVotingState(voter, VotingStates.reveal);
            assert(voterState.voter.state).equal(VoterStates.disenfranchised);
          });
        });

        describe('as a beneficiary', () => {
          it.full()('allows to cash out at the final stage in case of positive voting', async () => {
            const organizer = (
              await instance
                .getAPI({
                  organizer: true,
                  number: 1,
                })
                .allocate()
            ).value;
            const voter = (await instance.getAPI({ organizer: false, number: 2 }).allocate()).value;
            const config = await firstValueFrom(organizer.api.config$);
            await organizerInitializesProposal(context, organizer, voter, proposalTopic);
            await waitForInitializedState(organizer, voter);
            await voter.api.buyIn(1n);
            await waitForVoterState(voter, VoterStates.canCommit);
            await voter.api.voteCommit(true);
            await waitForCommittedVote(organizer);
            await organizer.api.advance(); // advance to reveal
            await waitForVoterState(voter, VoterStates.canReveal);
            await voter.api.voteReveal();
            await waitForRevealedVote(organizer);
            await organizer.api.advance(); // advance to final
            await waitForVotingState(voter, VotingStates.finalCashOut);
            const cashOutInProgressP = waitForState(
              voter.api.state$,
              (state) => state.state === States.initialized && state.beneficiary.state === BeneficiaryStates.cashingOut,
            );
            const actionId = await voter.api.cashOut();
            const afterCashOut = await waitForState(
              voter.api.state$,
              (state) => state.actions.all[actionId].status === AsyncActionStates.success,
            );

            assert(await cashOutInProgressP).matchObject({
              state: States.initialized,
              pot: Number(config.seedCoins + config.buyInCoins),
              voting: {
                state: VotingStates.finalCashOut,
                votesYes: 1,
              },
              beneficiary: {
                state: BeneficiaryStates.cashingOut,
                actionId,
              },
            });
            assert(afterCashOut).matchObject({
              state: States.setup,
              pot: null,
            });
          });

          it.full()('does not allow to cash out at the final stage in case of negative voting', async () => {
            const organizer = (
              await instance
                .getAPI({
                  organizer: true,
                  number: 1,
                })
                .allocate()
            ).value;
            const voter = (await instance.getAPI({ organizer: false, number: 2 }).allocate()).value;
            const config = await firstValueFrom(organizer.api.config$);
            await organizerInitializesProposal(context, organizer, voter, proposalTopic);
            await waitForInitializedState(organizer, voter);
            const buyInId = await voter.api.buyIn(1n);
            await waitForSuccess(voter.api.state$, buyInId);
            await voter.api.voteCommit(false);
            await waitForCommittedVote(organizer);
            await organizer.api.advance(); // advance to reveal
            await waitForVoterState(voter, VoterStates.canReveal);
            await voter.api.voteReveal();
            await waitForRevealedVote(organizer);
            await organizer.api.advance(); // advance to final
            await waitForState(
              voter.api.state$,
              (state) => state.state === States.initialized && state.beneficiary.state === BeneficiaryStates.finalCantCashOut,
            );
            const actionId = await voter.api.cashOut();
            const voterState = await waitForCompletion(voter.api.state$, actionId);

            assert(voterState).matchObject({
              state: States.initialized,
              pot: Number(config.seedCoins + config.buyInCoins),
              voting: {
                state: VotingStates.finalNegative,
                votesNo: 1,
              },
              beneficiary: {
                state: BeneficiaryStates.finalCantCashOut,
              },
            });
          });

          it.full()("doesn't allow to cash out in case of a tie", () =>
            pipe(
              instance.getAPI({ organizer: true, number: 1 }),
              Resource.zip(instance.getAPI({ organizer: false, number: 2 })),
              Resource.zip(instance.getAPI({ organizer: false, number: 3 })),
              Resource.use(async ([[organizer, beneficiary], voter]) => {
                const config = await firstValueFrom(organizer.api.config$);
                await organizer.api.initProposal({
                  topic: 'Build a bridge to the sky?',
                  beneficiary: beneficiary.address,
                });

                await waitForState(beneficiary.api.state$, (state) => state.state === States.initialized);
                await beneficiary.api.buyIn(1n);
                await waitForState(beneficiary.api.state$, (state) => state.voter.state === VoterStates.canCommit);
                await beneficiary.api.voteCommit(true);

                await waitForState(voter.api.state$, (state) => state.state === States.initialized);
                await voter.api.buyIn(1n);
                await waitForState(voter.api.state$, (state) => state.voter.state === VoterStates.canCommit);
                await voter.api.voteCommit(false);

                await waitForState(
                  organizer.api.state$,
                  (state) =>
                    state.organizer.state === OrganizerStates.canAdvance &&
                    state.state === States.initialized &&
                    state.voting.state === VotingStates.commit &&
                    state.voting.committed === 2,
                );
                await organizer.api.advance(); // advance to reveal
                await waitForState(voter.api.state$, (state) => state.voter.state === VoterStates.canReveal);
                await voter.api.voteReveal();
                await waitForState(beneficiary.api.state$, (state) => state.voter.state === VoterStates.canReveal);
                await beneficiary.api.voteReveal();

                await waitForState(
                  organizer.api.state$,
                  (state) =>
                    state.organizer.state === OrganizerStates.canAdvance &&
                    state.state === States.initialized &&
                    state.voting.state === VotingStates.reveal &&
                    state.voting.revealed === 2,
                );
                await organizer.api.advance(); // advance to final

                await waitForState(
                  beneficiary.api.state$,
                  (state) =>
                    state.state === States.initialized &&
                    (state.voting.state === VotingStates.finalNegative || state.voting.state === VotingStates.finalCashOut),
                );
                const cashOutId = await beneficiary.api.cashOut();
                const finalState = await waitForCompletion(beneficiary.api.state$, cashOutId);

                assert(finalState).matchObject({
                  state: States.initialized,
                  voting: {
                    state: VotingStates.finalNegative,
                    votesYes: 1,
                    votesNo: 1,
                    revealed: 2,
                    committed: 2,
                  },
                  beneficiary: {
                    state: BeneficiaryStates.finalCantCashOut,
                  },
                  pot: Number(config.seedCoins + config.buyInCoins * 2),
                  actions: {
                    latest: cashOutId,
                    all: {
                      [cashOutId]: {
                        status: AsyncActionStates.error,
                        action: Actions.cashOut,
                      },
                    },
                  },
                });
              }),
            ),
          );

          it.full()('does not allow to cash out in commit or reveal phase', async () => {
            const organizer = (
              await instance
                .getAPI({
                  organizer: true,
                  number: 1,
                })
                .allocate()
            ).value;
            const voter = (await instance.getAPI({ organizer: false, number: 2 }).allocate()).value;
            const config = await firstValueFrom(organizer.api.config$);
            await organizerInitializesProposal(context, organizer, voter, proposalTopic);
            await waitForInitializedState(organizer, voter);
            const buyInId = await voter.api.buyIn(1n);
            await waitForSuccess(voter.api.state$, buyInId);
            await voter.api.voteCommit(true);
            await waitForCommittedVote(organizer);
            const commitCashoutId = await voter.api.cashOut();
            const commitCashoutState = await waitForCompletion(voter.api.state$, commitCashoutId);
            await organizer.api.advance(); // advance to reveal
            await waitForOrganizerState(organizer, VotingStates.reveal, OrganizerStates.canAdvance);
            const revealCashoutId = await voter.api.cashOut();
            const revealCashoutState = await waitForCompletion(voter.api.state$, revealCashoutId);

            assert(commitCashoutState).matchObject({
              state: States.initialized,
              pot: Number(config.seedCoins + config.buyInCoins),
              beneficiary: {
                state: BeneficiaryStates.waitingForFinal,
              },
              actions: {
                latest: commitCashoutId,
                all: {
                  [commitCashoutId]: {
                    status: AsyncActionStates.error,
                  },
                },
              },
            });
            assert(revealCashoutState).matchObject({
              state: States.initialized,
              pot: Number(config.seedCoins + config.buyInCoins),
              beneficiary: {
                state: BeneficiaryStates.waitingForFinal,
              },
              actions: {
                latest: revealCashoutId,
                all: {
                  [revealCashoutId]: {
                    status: AsyncActionStates.error,
                  },
                },
              },
            });
          });

          it.full()(
            'does allow to cash out in a second round after a tie, receiving sum of funds from the first and the second proposal',
            () =>
              pipe(
                instance.getAPI({ organizer: true, number: 1 }),
                Resource.zip(instance.getAPI({ organizer: false, number: 2 })),
                Resource.zip(instance.getAPI({ organizer: false, number: 3 })),
                Resource.use(async ([[organizer, beneficiary], voter]) => {
                  const config = await firstValueFrom(organizer.api.config$);
                  await organizer.api.initProposal({
                    topic: 'Build a bridge to the sky?',
                    beneficiary: beneficiary.address,
                  });

                  await waitForState(beneficiary.api.state$, (state) => state.state === States.initialized);
                  await beneficiary.api.buyIn(1n);
                  await waitForState(beneficiary.api.state$, (state) => state.voter.state === VoterStates.canCommit);
                  await beneficiary.api.voteCommit(true);

                  await waitForState(voter.api.state$, (state) => state.state === States.initialized);
                  await voter.api.buyIn(1n);
                  await waitForState(voter.api.state$, (state) => state.voter.state === VoterStates.canCommit);
                  await voter.api.voteCommit(false);

                  await waitForState(
                    organizer.api.state$,
                    (state) =>
                      state.organizer.state === OrganizerStates.canAdvance &&
                      state.state === States.initialized &&
                      state.voting.state === VotingStates.commit &&
                      state.voting.committed === 2,
                  );
                  await organizer.api.advance(); // advance to reveal
                  await waitForState(voter.api.state$, (state) => state.voter.state === VoterStates.canReveal);
                  await voter.api.voteReveal();
                  await waitForState(beneficiary.api.state$, (state) => state.voter.state === VoterStates.canReveal);
                  await beneficiary.api.voteReveal();

                  await waitForState(
                    organizer.api.state$,
                    (state) =>
                      state.organizer.state === OrganizerStates.canAdvance &&
                      state.state === States.initialized &&
                      state.voting.state === VotingStates.reveal &&
                      state.voting.revealed === 2,
                  );
                  await organizer.api.advance(); // advance to final

                  await waitForState(
                    organizer.api.state$,
                    (state) =>
                      state.state === States.initialized &&
                      state.voting.state === VotingStates.finalNegative &&
                      state.organizer.state === OrganizerStates.canAdvance,
                  );
                  await organizer.api.advance();
                  await waitForState(organizer.api.state$, (state) => state.organizer.state === OrganizerStates.canInitProposal);
                  await organizer.api.initProposal({
                    topic: 'Maybe over Atlantic Ocean?',
                    beneficiary: beneficiary.address,
                  });
                  await waitForState(beneficiary.api.state$, (state) => state.voter.state === VoterStates.canCommit);
                  await beneficiary.api.voteCommit(true);
                  await waitForState(voter.api.state$, (state) => state.voter.state === VoterStates.canCommit);
                  await voter.api.voteCommit(true);

                  await waitForState(
                    organizer.api.state$,
                    (state) => state.state === States.initialized && state.voting.committed === 2,
                  );
                  await organizer.api.advance();
                  await waitForState(beneficiary.api.state$, (state) => state.voter.state === VoterStates.canReveal);
                  await beneficiary.api.voteReveal();
                  await waitForState(voter.api.state$, (state) => state.voter.state === VoterStates.canReveal);
                  await voter.api.voteReveal();
                  await waitForState(
                    organizer.api.state$,
                    (state) => state.state === States.initialized && state.voting.revealed === 2,
                  );
                  await organizer.api.advance(); // to final

                  const beforeCashOut = await waitForState(
                    beneficiary.api.state$,
                    (state) =>
                      state.state === States.initialized && state.beneficiary.state === BeneficiaryStates.finalCanCashOut,
                  );
                  const cashOutId = await beneficiary.api.cashOut();
                  const finalState = await waitForState(
                    beneficiary.api.state$,
                    (state) =>
                      state.actions.all[cashOutId].status !== AsyncActionStates.inProgress && state.state === States.setup,
                  );

                  assert(beforeCashOut).matchObject({
                    state: States.initialized,
                    voting: {
                      state: VotingStates.finalCashOut,
                      votesYes: 2,
                      votesNo: 0,
                      revealed: 2,
                      committed: 2,
                    },
                    beneficiary: {
                      state: BeneficiaryStates.finalCanCashOut,
                    },
                    pot: Number(config.seedCoins * 2 + config.buyInCoins * 2),
                  });

                  assert(finalState).matchObject({
                    state: States.setup,
                    pot: null,
                    actions: {
                      latest: cashOutId,
                      all: {
                        [cashOutId]: {
                          status: AsyncActionStates.success,
                          action: Actions.cashOut,
                        },
                      },
                    },
                  });
                }),
              ),
          );
        });
      });

      describe('contract initialization', () => {
        it.skip()('allows to set a voting token price and amount of seed tDUST for a proposal', () => {
          return fc.assert(
            fc.asyncProperty(
              fc.record({
                buyInCoins: fc.integer({ min: 0, max: 100_000 }),
                seedCoins: fc.integer({ min: 0, max: 100_000 }),
              }),
              fc.integer({ min: 1, max: 10 }),
              (config: DaoConfig, amountToBuy) =>
                pipe(
                  context.instance(config, infrastructure),
                  Resource.mproduct((instance) => instance.getAPI({ organizer: true, number: 1 })),
                  Resource.mproduct(([instance]) =>
                    instance.getAPI({
                      organizer: false,
                      number: 2,
                    }),
                  ),
                  Resource.use(async ([[_instance, organizer], voter]) => {
                    const initializationId = await organizerInitializesProposal(context, organizer, voter, 'foo');
                    await waitForSuccess(organizer.api.state$, initializationId);
                    const buyInId = await voter.api.buyIn(BigInt(amountToBuy));
                    const afterBuyIn = await waitForSuccess(voter.api.state$, buyInId);

                    const organizerState = await waitForState(
                      organizer.api.state$,
                      (organizerState) => organizerState?.pot === afterBuyIn?.pot,
                    );

                    const expectedPot = config.buyInCoins * amountToBuy + config.seedCoins;
                    assert(organizerState?.pot).equal(expectedPot);
                    assert(afterBuyIn?.pot).equal(expectedPot);
                  }),
                ),
            ),
          );
        });

        it.smoke()('allows to set voting token price equal zero', () => {
          const config: DaoConfig = {
            buyInCoins: 0,
            seedCoins: 10_000_000,
          };
          return pipe(
            context.instance(config, infrastructure),
            Resource.mproduct((instance) => instance.getAPI({ organizer: true, number: 1 })),
            Resource.mproduct(([instance]) => instance.getAPI({ organizer: false, number: 2 })),
            Resource.use(async ([[_instance, organizer], voter]) => {
              const initializationId = await organizerInitializesProposal(context, organizer, voter, 'foo');
              await waitForSuccess(organizer.api.state$, initializationId);
              const buyInId = await voter.api.buyIn(1n);
              await waitForSuccess(voter.api.state$, buyInId);

              const commitId = await voter.api.voteCommit(true);
              const voterState: DaoState = await waitForSuccess(voter.api.state$, commitId);

              assert(voterState).matchObject({
                voting: {
                  committed: 1,
                },
                pot: config.seedCoins,
              });
            }),
          );
        });

        it.smoke()('allows to set amount of seed tDUST equal zero', () => {
          const config: DaoConfig = {
            buyInCoins: 2_000_000,
            seedCoins: 0,
          };
          return pipe(
            context.instance(config, infrastructure),
            Resource.mproduct((instance) => instance.getAPI({ organizer: true, number: 1 })),
            Resource.mproduct(([instance]) => instance.getAPI({ organizer: false, number: 2 })),
            Resource.use(async ([[_instance, organizer], voter]) => {
              const initalizationId = await organizerInitializesProposal(context, organizer, voter, 'foo');
              const state = await waitForSuccess(organizer.api.state$, initalizationId);

              assert(state).matchObject({
                state: States.initialized,
                pot: 0,
              });
            }),
          );
        });

        it.smoke()('rejects negative prices', () => {
          return fc.assert(
            fc.asyncProperty(
              fc.oneof(
                fc.record({
                  buyInCoins: fc.integer({ max: -1 }),
                  seedCoins: fc.integer({ max: -1 }),
                }),
                fc.record({
                  buyInCoins: fc.integer({ min: 0 }),
                  seedCoins: fc.integer({ max: -1 }),
                }),
                fc.record({
                  buyInCoins: fc.integer({ max: -1 }),
                  seedCoins: fc.integer({ min: 0 }),
                }),
              ),
              async (config: DaoConfig) => {
                const failingInit: Promise<void> = pipe(
                  context.instance(config, infrastructure),
                  Resource.use(() => Promise.resolve()),
                );

                await expect(failingInit).rejects.toBeInstanceOf(Error);
              },
            ),
          );
        });
      });
    });

    describe(
      'specific',
      block(() => {
        const noopSuite = () => () => {};
        const suite = context.implementationSpecificSuite ?? noopSuite;
        return suite({
          getInfrastructure() {
            return infrastructure;
          },
        });
      }),
    );
  });
}
