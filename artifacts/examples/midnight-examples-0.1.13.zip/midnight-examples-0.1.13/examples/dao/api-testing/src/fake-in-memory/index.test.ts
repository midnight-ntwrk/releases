import { pino } from 'pino';
import { runDaoAPITest } from '../api-test.js';
import { Clock, FailAction, FakeInMemoryDao } from './index.js';
import { Resource } from '@midnight-ntwrk/dao-helpers';

const randomDelay = (): Promise<void> => new Promise((resolve) => setTimeout(resolve, Math.random() * 10)); // For tests we really don't need big delays, but we need them at all and we need them unpredictable

runDaoAPITest({
  implementationName: 'in-memory',
  suite: 'full',
  logger: pino({
    level: 'error',
  }),
  infrastructure: () => Resource.from(() => undefined),
  instance: (config) =>
    Resource.fromPromise(() =>
      FakeInMemoryDao.prepare(randomDelay, Clock.real, config).then((dao: FakeInMemoryDao) => ({
        getAPI: (options) =>
          Resource.fromPromise(() => {
            const address = options.organizer ? 'organizer' : `voter${options.number}`;
            return dao
              .join({
                asOrganizer: options.organizer,
                address,
                failAction: FailAction.never,
              })
              .then((api) => ({ api, address }));
          }),
      })),
    ),
});
