import { Proposal } from '@midnight-ntwrk/dao-api';
import { block } from '@midnight-ntwrk/dao-helpers';

export type LedgerState =
  | {
      state: 'setup';
      eligibleVoters: number;
      pot: bigint | null;
    }
  | {
      state: 'commit' | 'reveal' | 'final';
      proposal: Proposal;
      committed: number;
      revealed: number;
      yes: number;
      no: number;
      eligibleVoters: number;
      pot: bigint;
    };
export const LedgerState = block(() => {
  const initial: LedgerState = {
    state: 'setup',
    eligibleVoters: 0,
    pot: 0n,
  };
  const initProposal =
    (proposal: Proposal, seedFunding: bigint) =>
    (state: LedgerState): LedgerState => {
      return {
        state: 'commit',
        proposal,
        committed: 0,
        revealed: 0,
        yes: 0,
        no: 0,
        pot: (state.pot ?? 0n) + seedFunding,
        eligibleVoters: state.eligibleVoters,
      };
    };

  const advance =
    () =>
    (state: LedgerState): LedgerState => {
      switch (state.state) {
        case 'setup':
          return state;
        case 'commit':
          return {
            ...state,
            state: 'reveal',
          };
        case 'reveal':
          return {
            ...state,
            state: 'final',
          };
        case 'final':
          if (state.no >= state.yes) {
            return {
              ...initial,
              eligibleVoters: state.eligibleVoters,
              pot: state.pot,
            };
          } else {
            return state;
          }
      }
    };

  const boughtIn =
    (value: bigint) =>
    (state: LedgerState): LedgerState => {
      return {
        ...state,
        eligibleVoters: state.eligibleVoters + 1,
        pot: (state.pot ?? 0n) + value,
      };
    };

  const voteCommited =
    () =>
    (state: LedgerState): LedgerState => {
      if (state.state === 'commit') {
        return {
          ...state,
          committed: state.committed + 1,
        };
      } else {
        return state;
      }
    };

  const voteRevealed =
    (ballot: boolean) =>
    (state: LedgerState): LedgerState => {
      if (state.state === 'reveal') {
        return {
          ...state,
          revealed: state.revealed + 1,
          yes: state.yes + (ballot ? 1 : 0),
          no: state.no + (ballot ? 0 : 1),
        };
      } else {
        return state;
      }
    };

  const cashedOut =
    () =>
    (state: LedgerState): LedgerState => {
      return {
        state: 'setup',
        eligibleVoters: state.eligibleVoters,
        pot: null,
      };
    };

  return { initial, initProposal, advance, boughtIn, voteCommited, voteRevealed, cashedOut };
});
