import { option } from 'fp-ts';
import { Lazy, pipe } from 'fp-ts/function';
import { Option } from 'fp-ts/Option';
import {
  ActionId,
  Actions,
  AsyncAction,
  AsyncActionStates,
  Beneficiary,
  BeneficiaryStates,
  DaoState,
  Organizer,
  OrganizerStates,
  States,
  Voter,
  VoterStates,
  Voting,
  VotingStates,
} from '@midnight-ntwrk/dao-api';
import { LedgerState } from './LedgerState.js';
import { LocalState } from './LocalState.js';

const deriveActions = (localState: LocalState): DaoState['actions'] => ({
  latest: option.getOrElseW(() => null)(localState.lastAction),
  all: localState.actions,
});

const deriveVoting = (ledgerState: LedgerState): Option<Voting> => {
  switch (ledgerState.state) {
    case 'setup':
      return option.none;
    case 'commit':
      return option.some({
        state: VotingStates.commit,
        eligibleVoters: ledgerState.eligibleVoters,
        committed: ledgerState.committed,
        revealed: ledgerState.revealed,
        proposal: ledgerState.proposal,
        votesNo: ledgerState.yes,
        votesYes: ledgerState.no,
      });
    case 'reveal':
      return option.some({
        state: VotingStates.reveal,
        eligibleVoters: ledgerState.eligibleVoters,
        committed: ledgerState.committed,
        revealed: ledgerState.revealed,
        proposal: ledgerState.proposal,
        votesNo: ledgerState.yes,
        votesYes: ledgerState.no,
      });
    case 'final': {
      const result = {
        votesYes: ledgerState.yes,
        votesNo: ledgerState.no,
      };
      if (result.votesYes > result.votesNo) {
        return option.some({
          state: VotingStates.finalCashOut,
          eligibleVoters: ledgerState.eligibleVoters,
          committed: ledgerState.committed,
          revealed: ledgerState.revealed,
          proposal: ledgerState.proposal,
          ...result,
        });
      } else {
        return option.some({
          state: VotingStates.finalNegative,
          eligibleVoters: ledgerState.eligibleVoters,
          committed: ledgerState.committed,
          revealed: ledgerState.revealed,
          proposal: ledgerState.proposal,
          ...result,
        });
      }
    }
  }
};

const deriveOrganizer = (localState: LocalState, voting: Option<Voting>): Organizer => {
  if (!localState.organizer) {
    return {
      state: OrganizerStates.notAnOrganizer,
    };
  }

  return pipe(
    voting,
    option.fold(
      (): Organizer => {
        return pipe(
          localState.lastAction,
          option.map((action: ActionId): AsyncAction => localState.actions[action]),
          option.filter(
            (action: AsyncAction) => action.action === Actions.initProposal && action.status === AsyncActionStates.inProgress,
          ),
          option.fold(
            (): Organizer => {
              return {
                state: OrganizerStates.canInitProposal,
              };
            },
            (action: AsyncAction): Organizer => {
              return {
                state: OrganizerStates.initInProgress,
                actionId: action.id,
              };
            },
          ),
        );
      },
      (votingState): Organizer => {
        if (votingState.state === VotingStates.finalCashOut) {
          return {
            state: OrganizerStates.cannotAdvance,
          };
        } else {
          return pipe(
            localState.lastAction,
            option.map((id) => localState.actions[id]),
            option.filter((action) => action.action === Actions.advance && action.status === AsyncActionStates.inProgress),
            option.fold(
              () => {
                return {
                  state: OrganizerStates.canAdvance,
                };
              },
              (action): Organizer => {
                return {
                  state: OrganizerStates.advanceInProgress,
                  actionId: action.id,
                };
              },
            ),
          );
        }
      },
    ),
  );
};

const deriveVoter = (localState: LocalState, voting: Option<Voting>): Voter => {
  return pipe(
    voting,
    option.fold(
      () => {
        return {
          state: VoterStates.initial,
          canBuyIn: true,
        };
      },
      (votingState) => {
        switch (localState.stage) {
          case 'initial':
            if (votingState.state !== VotingStates.commit) {
              return {
                state: VoterStates.disenfranchised,
              };
            } else {
              return pipe(
                localState.lastAction,
                option.map((id) => localState.actions[id]),
                option.filter((action) => action.action === Actions.commit),
                option.fold(
                  () => {
                    return {
                      state: VoterStates.canCommit,
                    };
                  },
                  (action): Voter => {
                    switch (action.status) {
                      case 'error':
                        return {
                          state: VoterStates.canCommit,
                        };
                      case 'in_progress':
                        return {
                          state: VoterStates.committing,
                          actionId: action.id,
                        };
                      case 'success':
                        return pipe(
                          localState.ballot,
                          option.foldW(
                            () => ({
                              state: VoterStates.disenfranchised,
                            }),
                            (ballot) => ({
                              state: VoterStates.committed,
                              ballot,
                            }),
                          ),
                        );
                    }
                  },
                ),
              );
            }
          case 'committed':
            if (votingState.state === VotingStates.commit) {
              return pipe(
                localState.ballot,
                option.foldW(
                  () => ({
                    state: VoterStates.disenfranchised, // we don't have ballot for some reason (e.g. delay between reset of ledger and local state) so defaulting to state, where voter should not perform any action
                  }),
                  (ballot) => ({
                    state: VoterStates.committed,
                    ballot,
                  }),
                ),
              );
            } else if (votingState.state === VotingStates.reveal) {
              const canRevealOrDisenfranchised: Lazy<Voter> = () =>
                pipe(
                  localState.ballot,
                  option.foldW(
                    () => ({
                      state: VoterStates.disenfranchised,
                    }),
                    (ballot) => ({
                      state: VoterStates.canReveal,
                      ballot,
                    }),
                  ),
                );
              return pipe(
                localState.lastAction,
                option.map((id) => localState.actions[id]),
                option.filter((action) => action.action === Actions.reveal),
                option.fold(canRevealOrDisenfranchised, (action): Voter => {
                  switch (action.status) {
                    case 'error':
                      return canRevealOrDisenfranchised();
                    case 'in_progress':
                      return { state: VoterStates.revealing, actionId: action.id };
                    case 'success':
                      return { state: VoterStates.revealed };
                  }
                }),
              );
            } else {
              return {
                state: VoterStates.final,
              };
            }
          case 'revealed':
            if (votingState.state === VotingStates.commit) {
              // technically speaking this is a completely invalid state
              // but without proper reset can happen in next round
              // going with safe disenfranchised option
              return { state: VoterStates.disenfranchised };
            } else if (votingState.state === VotingStates.reveal) {
              return {
                state: VoterStates.revealed,
              };
            } else {
              return {
                state: VoterStates.final,
              };
            }
        }
      },
    ),
  );
};

const deriveBeneficiary = (localState: LocalState, voting: Voting): Beneficiary => {
  if (voting.proposal.beneficiary !== localState.address) {
    return {
      state: BeneficiaryStates.notBeneficiary,
    };
  } else {
    switch (voting.state) {
      case VotingStates.finalNegative:
        return {
          state: BeneficiaryStates.finalCantCashOut,
        };
      case VotingStates.commit:
      case VotingStates.reveal:
        return {
          state: BeneficiaryStates.waitingForFinal,
        };
      case VotingStates.finalCashOut:
        return pipe(
          localState.lastAction,
          option.map((id) => localState.actions[id]),
          option.filter((action) => action.action === Actions.cashOut && action.status === AsyncActionStates.inProgress),
          option.foldW(
            () => {
              return {
                state: BeneficiaryStates.finalCanCashOut,
              };
            },
            (action) => {
              return {
                state: BeneficiaryStates.cashingOut,
                actionId: action.id,
              };
            },
          ),
        );
    }
  }
};

export const deriveDaoState = (ledgerState: LedgerState, localState: LocalState): DaoState => {
  const tokenType = 'fake_token_type';
  const actions: DaoState['actions'] = deriveActions(localState);
  const voting: Option<Voting> = deriveVoting(ledgerState);
  const organizer = deriveOrganizer(localState, voting);
  const voter = deriveVoter(localState, voting);
  const beneficiaryAndVoting = pipe(
    voting,
    option.map((votingState) => ({
      beneficiary: deriveBeneficiary(localState, votingState),
      voting: votingState,
    })),
  );

  return pipe(
    beneficiaryAndVoting,
    option.fold(
      (): DaoState => {
        return {
          state: States.setup,
          pot: ledgerState.pot !== null ? Number(ledgerState.pot) : null,
          actions,
          organizer,
          voter,
          tokenType,
        };
      },
      ({ beneficiary, voting }): DaoState => {
        return {
          state: States.initialized,
          pot: Number(ledgerState.pot),
          voting,
          organizer,
          voter,
          beneficiary,
          actions,
          tokenType,
        };
      },
    ),
  );
};
