import { either } from 'fp-ts';
import { Either } from 'fp-ts/Either';
import { combineLatest, firstValueFrom, map, Observable, of, pairwise, shareReplay, tap } from 'rxjs';
import * as uuid from 'uuid';
import {
  Action,
  ActionId,
  Actions,
  AsyncActionStates,
  BeneficiaryStates,
  DaoAPI,
  DaoConfig,
  DaoState,
  OrganizerStates,
  Proposal,
  States,
  VoterStates,
} from '@midnight-ntwrk/dao-api';
import { Bloc, block, StateUpdate, through } from '@midnight-ntwrk/dao-helpers';
import { deriveDaoState } from './DaoState.js';
import { LedgerState } from './LedgerState.js';
import { LocalState } from './LocalState.js';

type LedgerStateUpdate = StateUpdate<LedgerState>;
type LocalStateUpdate = StateUpdate<LocalState>;

class LedgerBloc extends Bloc<LedgerState> {
  constructor() {
    super(LedgerState.initial);
  }

  commit(update: LedgerStateUpdate): Promise<void> {
    return firstValueFrom(this.updateState(update));
  }
}

class LocalBloc extends Bloc<LocalState> {
  constructor(organizer: boolean, address: string) {
    super(LocalState.initial(organizer, address));
  }

  commit(update: LocalStateUpdate): Promise<void> {
    return firstValueFrom(this.updateState(update));
  }
}

// With this we can inject and test failures in various ways
export type FailAction = (state: DaoState, action: Action) => Promise<Either<string, void>>;
export const FailAction = block(() => {
  const never: FailAction = () => Promise.resolve(either.right(undefined));
  return { never };
});

export interface Clock {
  now: () => Date;
}
export const Clock = block(() => {
  const real: Clock = {
    now: () => new Date(),
  };

  return { real };
});

export class FakeInMemoryDao {
  static prepare(delays: () => Promise<void>, clock: Clock, daoConfig: DaoConfig): Promise<FakeInMemoryDao> {
    return new Promise((resolve) => {
      const ledgerBloc = new LedgerBloc();
      resolve(new FakeInMemoryDao(ledgerBloc, delays, clock, daoConfig));
    });
  }

  constructor(
    private readonly ledgerBloc: LedgerBloc,
    private readonly delays: () => Promise<void>,
    private readonly clock: Clock,
    private readonly daoConfig: DaoConfig,
  ) {
    if (daoConfig.seedCoins < 0 || daoConfig.buyInCoins < 0) {
      throw new Error('Seed and buy in coins in config need to be non-negative integers');
    }
  }

  join(options: { asOrganizer: boolean; address: string; failAction: FailAction }): Promise<DaoAPI> {
    const localBloc = new LocalBloc(options.asOrganizer, options.address);
    const daoAPI = new FakeInMemoryDaoAPI(
      this.ledgerBloc,
      localBloc,
      this.delays,
      options.failAction,
      this.clock,
      this.daoConfig,
    );
    return Promise.resolve(daoAPI);
  }
}

export class FakeInMemoryDaoAPI implements DaoAPI {
  config$: Observable<DaoConfig>;
  state$: Observable<DaoState>;

  constructor(
    private readonly ledgerBloc: LedgerBloc,
    private readonly localBloc: LocalBloc,
    private readonly delay: () => Promise<void>,
    private readonly failAction: FailAction,
    private readonly clock: Clock,
    private readonly daoConfig: DaoConfig,
  ) {
    this.config$ = of(daoConfig);
    this.ledgerBloc.state$
      .pipe(
        pairwise(),
        tap(async ([prev, next]) => {
          if (prev.state === 'final' && next.state === 'setup') {
            await this.localBloc.commit(LocalState.resetToSetup());
          }
        }),
      )
      .subscribe();
    this.state$ = combineLatest([this.ledgerBloc.state$, this.localBloc.state$]).pipe(
      map(([ledgerState, localState]): DaoState => deriveDaoState(ledgerState, localState)),
      shareReplay(1),
    );
  }

  advance = (): Promise<ActionId> => {
    const actionId: ActionId = uuid.v4();
    const now = this.clock.now();

    void firstValueFrom(this.state$).then((state) => {
      if (state.organizer.state !== OrganizerStates.canAdvance) {
        return this.localBloc.commit(
          LocalState.addAction({
            id: actionId,
            action: Actions.advance,
            startedAt: now,
            status: AsyncActionStates.error,
            error: "Can't advance. Either you're not organizer or current status of contract doesn't allow for that",
          }),
        );
      } else {
        return this.localBloc
          .commit(
            LocalState.addAction({
              id: actionId,
              action: Actions.advance,
              startedAt: now,
              status: AsyncActionStates.inProgress,
            }),
          )
          .then(() => this.delay())
          .then(() => this.ledgerBloc.commit(LedgerState.advance()))
          .then(() =>
            this.localBloc.commit(
              LocalState.updateAction((action) => ({ ...action, status: AsyncActionStates.success }))(actionId),
            ),
          );
      }
    });

    return Promise.resolve(actionId);
  };

  initProposal = (proposal: Proposal): Promise<ActionId> => {
    const actionId: ActionId = uuid.v4();
    const now = this.clock.now();

    void firstValueFrom(this.state$).then((state) => {
      if (state.organizer.state !== OrganizerStates.canInitProposal) {
        return this.localBloc.commit(
          LocalState.addAction({
            id: actionId,
            action: Actions.initProposal,
            startedAt: now,
            status: AsyncActionStates.error,
            error: "Can't init. Either you're not organizer or the proposal is already initiated",
          }),
        );
      } else {
        return this.localBloc
          .commit(
            LocalState.addAction({
              id: actionId,
              action: Actions.initProposal,
              startedAt: now,
              status: AsyncActionStates.inProgress,
            }),
          )
          .then(() => this.delay())
          .then(() => this.ledgerBloc.commit(LedgerState.initProposal(proposal, BigInt(this.daoConfig.seedCoins))))
          .then(() =>
            this.localBloc.commit(
              LocalState.updateAction((action) => ({ ...action, status: AsyncActionStates.success }))(actionId),
            ),
          );
      }
    });

    return Promise.resolve(actionId);
  };

  buyIn = (amount: bigint): Promise<ActionId> => {
    const actionId: ActionId = uuid.v4();
    const now = this.clock.now();

    void firstValueFrom(this.state$).then(() => {
      if (amount < 1n || amount >= 2n ** 64n) {
        return this.localBloc.commit(
          LocalState.addAction({
            id: actionId,
            action: Actions.buyIn,
            startedAt: now,
            status: AsyncActionStates.error,
            error: 'Amount of tokens bought needs to be positive',
          }),
        );
      } else {
        return this.localBloc
          .commit(
            LocalState.addAction({
              id: actionId,
              action: Actions.buyIn,
              startedAt: now,
              status: AsyncActionStates.inProgress,
            }),
          )
          .then(() => this.delay())
          .then(() => this.ledgerBloc.commit(LedgerState.boughtIn(BigInt(this.daoConfig.buyInCoins) * amount)))
          .then(() =>
            this.localBloc.commit(
              through(
                LocalState.updateAction((action) => ({ ...action, status: AsyncActionStates.success }))(actionId),
                LocalState.boughtIn(amount),
              ),
            ),
          );
      }
    });

    return Promise.resolve(actionId);
  };

  cashOut(): Promise<ActionId> {
    const actionId = uuid.v4();
    const now = this.clock.now();

    void firstValueFrom(this.state$).then((state) => {
      if (state.state === States.initialized && state.beneficiary.state === BeneficiaryStates.finalCanCashOut) {
        return this.localBloc
          .commit(
            LocalState.addAction({
              id: actionId,
              action: Actions.cashOut,
              startedAt: now,
              status: AsyncActionStates.inProgress,
            }),
          )
          .then(() => this.delay())
          .then(() => this.ledgerBloc.commit(LedgerState.cashedOut()))
          .then(() =>
            this.localBloc.commit(
              LocalState.updateAction((action) => ({ ...action, status: AsyncActionStates.success }))(actionId),
            ),
          );
      } else {
        return this.localBloc.commit(
          LocalState.addAction({
            id: actionId,
            action: Actions.cashOut,
            startedAt: now,
            status: AsyncActionStates.error,
            error: 'Cannot cash out. You are not a beneficiary or the proposal has not yet been completed.',
          }),
        );
      }
    });

    return Promise.resolve(actionId);
  }

  voteCommit(ballot: boolean): Promise<ActionId> {
    const actionId: ActionId = uuid.v4();
    const now = this.clock.now();

    void firstValueFrom(this.state$).then((state) => {
      if (state.voter.state !== VoterStates.canCommit) {
        return this.localBloc.commit(
          LocalState.addAction({
            id: actionId,
            action: Actions.commit,
            startedAt: now,
            status: AsyncActionStates.error,
            error: "Can't commit vote.",
          }),
        );
      } else {
        return this.localBloc
          .commit(
            LocalState.addAction({
              id: actionId,
              action: Actions.commit,
              startedAt: now,
              status: AsyncActionStates.inProgress,
            }),
          )
          .then(() => this.delay())
          .then(() => this.ledgerBloc.commit(LedgerState.voteCommited()))
          .then(() =>
            this.localBloc.commit(
              through(
                LocalState.updateAction((action) => ({ ...action, status: AsyncActionStates.success }))(actionId),
                LocalState.voteCommitted(ballot),
              ),
            ),
          );
      }
    });

    return Promise.resolve(actionId);
  }

  voteReveal(): Promise<ActionId> {
    const actionId: ActionId = uuid.v4();
    const now = this.clock.now();

    void firstValueFrom(this.state$).then((state) => {
      if (state.voter.state === VoterStates.canReveal) {
        const ballot = state.voter.ballot;
        return this.localBloc
          .commit(
            LocalState.addAction({
              id: actionId,
              action: Actions.reveal,
              startedAt: now,
              status: AsyncActionStates.inProgress,
            }),
          )
          .then(() => this.delay())
          .then(() => this.ledgerBloc.commit(LedgerState.voteRevealed(ballot)))
          .then(() =>
            this.localBloc.commit(
              through(
                LocalState.updateAction((action) => ({ ...action, status: AsyncActionStates.success }))(actionId),
                LocalState.voteRevealed(),
              ),
            ),
          );
      } else {
        return this.localBloc.commit(
          LocalState.addAction({
            id: actionId,
            action: Actions.reveal,
            startedAt: now,
            status: AsyncActionStates.error,
            error: 'Cannot reveal your vote.',
          }),
        );
      }
    });
    return Promise.resolve(actionId);
  }
}
