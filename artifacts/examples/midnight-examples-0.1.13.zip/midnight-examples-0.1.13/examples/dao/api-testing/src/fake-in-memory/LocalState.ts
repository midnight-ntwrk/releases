import { option } from 'fp-ts';
import { Option } from 'fp-ts/Option';
import { ActionId, AsyncAction } from '@midnight-ntwrk/dao-api';
import { block, ElementType, StateUpdate } from '@midnight-ntwrk/dao-helpers';

const LocalStages = ['initial', 'committed', 'revealed'] as const;
type LocalStage = ElementType<typeof LocalStages>;

export interface LocalState {
  stage: LocalStage;
  boughtVotingTokens: bigint;
  committed: boolean;
  organizer: boolean;
  address: string;
  ballot: Option<boolean>;
  lastAction: Option<ActionId>;
  actions: Record<ActionId, AsyncAction>;
}
export const LocalState = block(() => {
  const initial = (organizer: boolean, address: string): LocalState => ({
    stage: 'initial',
    boughtVotingTokens: 0n,
    committed: false,
    organizer,
    address,
    ballot: option.none,
    lastAction: option.none,
    actions: {},
  });
  const addAction =
    (action: AsyncAction) =>
    (state: LocalState): LocalState => ({
      ...state,
      lastAction: option.some(action.id),
      actions: { ...state.actions, [action.id]: action },
    });
  const updateAction =
    (update: StateUpdate<AsyncAction>) =>
    (id: ActionId) =>
    (state: LocalState): LocalState => ({
      ...state,
      actions: {
        ...state.actions,
        [id]: update(state.actions[id]),
      },
    });

  const boughtIn =
    (amount: bigint) =>
    (state: LocalState): LocalState => {
      return {
        ...state,
        boughtVotingTokens: state.boughtVotingTokens + amount,
      };
    };

  const voteCommitted =
    (ballot: boolean) =>
    (state: LocalState): LocalState => {
      return {
        ...state,
        stage: 'committed',
        committed: true,
        ballot: option.some(ballot),
      };
    };

  const voteRevealed =
    () =>
    (state: LocalState): LocalState => {
      return {
        ...state,
        stage: 'revealed',
      };
    };

  const resetToSetup =
    () =>
    (state: LocalState): LocalState => ({
      ...state,
      stage: 'initial',
      committed: false,
      ballot: option.none,
    });

  return { initial, addAction, updateAction, boughtIn, voteCommitted, voteRevealed, resetToSetup };
});
