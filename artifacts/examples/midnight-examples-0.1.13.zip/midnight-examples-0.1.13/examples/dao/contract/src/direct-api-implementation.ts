import { CircuitContext, CircuitResults, tokenType } from '@midnight-ntwrk/compact-runtime';
import { Action, ActionId, Actions, AsyncActionStates, DaoAPI, DaoConfig, DaoState, Proposal } from '@midnight-ntwrk/dao-api';
import { block, pipe, Resource } from '@midnight-ntwrk/dao-helpers';
import { createCoinInfo, encodeCoinInfo, nativeToken } from '@midnight-ntwrk/ledger';
import { StateWithZswap } from '@midnight-ntwrk/midnight-js-contracts';
import * as crypto from 'node:crypto';
import * as pino from 'pino';
import { catchError, combineLatest, concat, concatMap, lastValueFrom, map, Observable, shareReplay, take, tap } from 'rxjs';
import { costsToConfig } from './config.js';
import { ContractPrivateState, PrivateStateBloc } from './contract-private-state.js';
import { deriveDAOState } from './dao-state.js';
import { EphemeralStateBloc } from './ephemeral-state.js';
import { LedgerStateBloc } from './ledger-state.js';
import * as Contract from './managed/micro-dao/contract/index.cjs';

export type PrivateState = StateWithZswap<ContractPrivateState>;

type DerivedLedgerState = {
  circuitContext: CircuitContext<unknown>;
  ledgerState: Contract.Ledger;
};
type CallContext = {
  circuitContext: CircuitContext<PrivateState>;
  contract: Contract.Contract<PrivateState>;
  config: DaoConfig;
};
export type DirectAPIParams = {
  contract: Contract.Contract<PrivateState>;
  ledger: LedgerStateBloc;
  priv: PrivateStateBloc<PrivateState>;
  ephemeral: EphemeralStateBloc;
  logger: pino.Logger;
  coinPublicKey: Uint8Array;
};

/**
 * Direct, in-memory implementation of the DAO API
 *
 * It's a good base e.g. for testing contract logic in a way abstracted from details of interacting with the runtime
 * With a bit of additional effort it can also be used as a way to test the UI with actual contract, but without
 * interacting with a chain, which takes quite a lot of time.
 *
 * Whole class can be mostly split into 3 parts:
 *   - state management and derivation - most of it is located in constructor and can be traced back through assignment to `this.$state`
 *     It takes 3 stream of state, and combines them into a single, coherent state, through a function called `deriveDAOState`:
 *       - "ledger", shared one - the same that normally is stored on-chain, as part of ledger
 *       - "priv", private one - which needs to be persisted, but should not leave participant's machine
 *       - "ephemeral" - data about ongoing actions, to prevent e.g. calling the same circuit for the second time before getting confirmation about previous call
 *
 *   - circuit call management - `callCircuit` method - it makes sure proper context is being created and the state updates are properly disseminated
 *   - actual calls to circuits - the methods with names referring to contract's circuits - they are just thin, circuit-specific wrappers around `callCircuit` method
 */
export class DirectAPI implements DaoAPI {
  static init(this: void, params: DirectAPIParams): Resource<DirectAPI> {
    return Resource.from(() => new DirectAPI(params));
  }

  config$: Observable<DaoConfig>;
  state$: Observable<DaoState>;
  #ledgerState$: Observable<DerivedLedgerState>;
  #contract: Contract.Contract<PrivateState>;
  #ledger: LedgerStateBloc;
  #private: PrivateStateBloc<PrivateState>;
  #ephemeral: EphemeralStateBloc;
  #logger: pino.Logger;
  #coinPublicKey: Uint8Array;

  private constructor({ contract, ledger, priv, ephemeral, logger, coinPublicKey }: DirectAPIParams) {
    this.#contract = contract;
    this.#coinPublicKey = coinPublicKey;
    this.#ledger = ledger;
    this.#ledgerState$ = this.#ledger.state$.pipe(
      map((s) => ({ circuitContext: s, ledgerState: Contract.ledger(s.transactionContext.state) })),
    );
    this.config$ = this.#ledgerState$.pipe(
      map((ledgerState): DaoConfig => {
        const costs = ledgerState.ledgerState.costs;
        return costsToConfig(costs);
      }),
    );
    this.#private = priv;
    this.#ephemeral = ephemeral;
    this.#logger = logger;
    this.state$ = combineLatest([this.#ledgerState$, this.#private.contractState$, this.#ephemeral.state$]).pipe(
      tap({
        next: ([contract, priv, ephemeral]) =>
          this.#logger.trace({
            message: 'Combining states',
            contract,
            priv,
            ephemeral,
          }),
      }),
      map(([ledger, priv, ephemeral]) =>
        deriveDAOState(ledger.ledgerState, priv, ephemeral, coinPublicKey, this.#ledger.address),
      ),
      tap({
        next: (state) => {
          this.#logger.debug('Got new state');
          this.#logger.trace({ state }, 'New state');
        },
        error: (error: unknown) => {
          this.#logger.error(error, 'Got a state error');
        },
        complete: () => {
          this.#logger.debug('DAO state completed');
        },
      }),
      shareReplay(1),
    );
  }

  advance(): Promise<ActionId> {
    return this.callCircuit({
      action: Actions.advance,
      circuit: (context) => context.contract.impureCircuits.advance(context.circuitContext),
    });
  }

  buyIn(amount: bigint): Promise<ActionId> {
    return this.callCircuit({
      action: Actions.buyIn,
      circuit: (context) => {
        const buyInCoin = encodeCoinInfo(createCoinInfo(nativeToken(), BigInt(context.config.buyInCoins) * amount));

        debugger;
        return context.contract.impureCircuits.buy_in(context.circuitContext, buyInCoin, amount);
      },
    });
  }

  cashOut(): Promise<ActionId> {
    return this.callCircuit({
      action: Actions.cashOut,
      circuit: (context) => context.contract.impureCircuits.cash_out(context.circuitContext),
    });
  }

  async initProposal(proposal: Proposal): Promise<ActionId> {
    return this.callCircuit({
      action: Actions.initProposal,
      circuit: (context) => {
        const seedCoin = encodeCoinInfo(createCoinInfo(nativeToken(), BigInt(context.config.seedCoins)));

        this.#logger.trace(seedCoin, 'Pot seed coin');

        return context.contract.impureCircuits.set_topic(
          context.circuitContext,
          proposal.topic,
          { bytes: Buffer.from(proposal.beneficiary, 'hex') },
          seedCoin,
        );
      },
    });
  }

  voteCommit(ballot: boolean): Promise<ActionId> {
    return this.callCircuit({
      action: Actions.commit,
      circuit: (context) => {
        const votingTokenType = tokenType(
          Contract.pureCircuits.dao_token_domain_separator(),
          context.circuitContext.transactionContext.address,
        );
        const votingCoin = encodeCoinInfo(createCoinInfo(votingTokenType, 1n));
        return context.contract.impureCircuits.vote_commit(context.circuitContext, ballot, votingCoin);
      },
    });
  }

  voteReveal(): Promise<ActionId> {
    return this.callCircuit({
      action: Actions.reveal,
      circuit: (context) => context.contract.impureCircuits.vote_reveal(context.circuitContext),
    });
  }

  callCircuit<T>(params: {
    action: Action;
    circuit: (context: CallContext) => CircuitResults<PrivateState, T>;
  }): Promise<ActionId> {
    const actionId = crypto.randomUUID();
    const now = new Date();
    this.#logger.debug({ action: params.action, actionId }, `${params.action} execution starting`);

    const action = pipe(
      this.#ephemeral.addAction({
        id: actionId,
        action: params.action,
        startedAt: now,
        status: AsyncActionStates.inProgress,
      }),
      concatMap(() => combineLatest([this.#ledgerState$, this.#private.state$, this.config$] as const)),
      take(1),
      map(([contractState, privateState, config]: [DerivedLedgerState, PrivateState, DaoConfig]): CallContext => {
        // Prepare the circuit context in a very similar way to what is done in unit tests
        const executionContext: CircuitContext<PrivateState> = {
          ...contractState.circuitContext,
          currentPrivateState: privateState,
        };
        return {
          contract: this.#contract,
          config,
          circuitContext: executionContext,
        };
      }),
      concatMap((context: CallContext) => {
        const result = params.circuit(context);

        this.#logger.debug({ action: params.action, actionId }, `${params.action} execution succeeded`);
        this.#logger.trace({ action: params.action, actionId, result }, `${params.action} result`);

        const resultContext: CircuitContext<PrivateState> = result.context;

        this.#logger.trace(
          {
            action: params.action,
            actionId,
            pot: block(() => {
              const raw = Contract.ledger(resultContext.transactionContext.state).pot;
              return {
                nonce: Buffer.from(raw.nonce).toString('hex'),
                mt_index: raw.mt_index,
                value: raw.value,
              };
            }),
          },
          'Pot in the result',
        );
        return concat(
          this.#ledger.set(result.context),
          this.#private.set(resultContext.currentPrivateState),
          this.#ephemeral.succeedAction(actionId),
        );
      }),
      catchError((error: Error) => {
        this.#logger.error({ err: error, action: params.action, actionId }, `${params.action} execution failed`);
        return this.#ephemeral.failAction(actionId, error.message);
      }),
    );
    void lastValueFrom(action); //Run the action

    return Promise.resolve(actionId);
  }
}
