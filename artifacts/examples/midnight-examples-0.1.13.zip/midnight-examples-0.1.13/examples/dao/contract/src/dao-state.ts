import { ContractAddress, tokenType } from '@midnight-ntwrk/compact-runtime';
import {
  Actions,
  AsyncAction,
  AsyncActionStates,
  Beneficiary,
  BeneficiaryStates,
  DaoState,
  Organizer,
  OrganizerStates,
  States,
  Voter,
  VoterStates,
  Voting,
  VotingStates,
} from '@midnight-ntwrk/dao-api';
import * as Contract from './managed/micro-dao/contract/index.cjs';
import { block } from '@midnight-ntwrk/dao-helpers';
import { ContractPrivateState } from './contract-private-state.js';
import { EphemeralState } from './ephemeral-state.js';

/**
 * Combines all pieces of state into API-compatible one
 *
 * Particularly - for each role in the proposal, there is a different state machine, which dictates what can be done.
 * Functions below check the ledger state enum, local state enum and credentials (public key, coin public key) to verify
 * what roles are assigned to current party
 *
 * Together with contract itself, this is one of places that needs a lot of attention to ensure that all possible
 * combinations of states are handled as the resulting state is treated as source of truth for upper layers of a DApp.
 * @param ledgerState - The on-chain ledger state
 * @param privateState - Local, persistent, private state
 * @param ephemeralState - Local, temporary state
 * @param coinPublicKey - Coin public key obtained from wallet
 * @param contractAddress - Address of the contract
 */
export const deriveDAOState = (
  ledgerState: Contract.Ledger,
  privateState: ContractPrivateState,
  ephemeralState: EphemeralState,
  coinPublicKey: Uint8Array,
  contractAddress: ContractAddress,
): DaoState => {
  const actions = ephemeralState.actions;
  const voting = deriveVotingState(ledgerState);
  const organizer = deriveOrganizerState(ledgerState.organizer, voting, ephemeralState, privateState);
  const potValue = ledgerState.potHasCoin ? Number(ledgerState.pot.value) : null;
  const voter = deriveVoterState(ledgerState, voting, privateState, ephemeralState);
  const beneficiary = deriveBeneficiaryState(voting, ephemeralState, coinPublicKey);
  const calculatedTokenType = tokenType(Contract.pureCircuits.dao_token_domain_separator(), contractAddress);
  return voting === null
    ? {
        state: States.setup,
        actions,
        organizer,
        voter,
        pot: potValue,
        tokenType: calculatedTokenType,
      }
    : {
        state: States.initialized,
        voting,
        actions,
        organizer,
        voter,
        pot: potValue || 0,
        beneficiary,
        tokenType: calculatedTokenType,
      };
};

export function deriveVotingState(contractState: Contract.Ledger): Voting | null {
  const getVotingDetails = () => {
    return {
      votesNo: Number(contractState.no),
      votesYes: Number(contractState.yes),
      proposal: {
        topic: contractState.topic.value,
        beneficiary: Buffer.from(contractState.beneficiary.value.bytes).toString('hex'),
      },
      committed: Number(contractState.committedVotes.firstFree()),
      revealed: Number(contractState.revealedParticipants.size()),
    };
  };
  switch (contractState.state) {
    case Contract.LedgerState.setup:
      return null;
    case Contract.LedgerState.commit:
      return { ...getVotingDetails(), state: VotingStates.commit };
    case Contract.LedgerState.reveal:
      return { ...getVotingDetails(), state: VotingStates.reveal };
    case Contract.LedgerState.final: {
      const details = getVotingDetails();
      return {
        ...details,
        state: details.votesYes > details.votesNo ? VotingStates.finalCashOut : VotingStates.finalNegative,
      };
    }
  }
}

export function deriveOrganizerState(
  organizerPk: Uint8Array,
  voting: Voting | null,
  ephemeral: EphemeralState,
  privateState: ContractPrivateState,
): Organizer {
  const localPk = Buffer.from(Contract.pureCircuits.public_key(privateState.dappSecretKey));
  const lastAction = ephemeral.actions.latest ? ephemeral.actions.all[ephemeral.actions.latest] : null;
  if (!localPk.equals(Buffer.from(organizerPk))) {
    return {
      state: OrganizerStates.notAnOrganizer,
    };
  } else {
    if (voting === null) {
      if (lastAction && lastAction.status === AsyncActionStates.inProgress && lastAction.action === Actions.initProposal) {
        return {
          state: OrganizerStates.initInProgress,
          actionId: lastAction.id,
        };
      } else {
        return {
          state: OrganizerStates.canInitProposal,
        };
      }
    } else {
      switch (voting.state) {
        case VotingStates.commit:
        case VotingStates.reveal:
        case VotingStates.finalNegative:
          if (lastAction && lastAction.status === AsyncActionStates.inProgress && lastAction.action === Actions.advance) {
            return {
              state: OrganizerStates.advanceInProgress,
              actionId: lastAction.id,
            };
          } else {
            return {
              state: OrganizerStates.canAdvance,
            };
          }
        case VotingStates.finalCashOut:
          return {
            state: OrganizerStates.cannotAdvance,
          };
      }
    }
  }
}

export function deriveVoterState(
  contractState: Contract.Ledger,
  votingState: Voting | null,
  privateState: ContractPrivateState,
  ephemeral: EphemeralState,
): Voter {
  const currentInProgressAction: AsyncAction | null = block(() => {
    const action = ephemeral.actions.latest ? ephemeral.actions.all[ephemeral.actions.latest] : null;
    return action?.status === AsyncActionStates.inProgress ? action : null;
  });

  if (currentInProgressAction && currentInProgressAction.action === Actions.buyIn) {
    return {
      state: VoterStates.buyingIn,
      actionId: currentInProgressAction.id,
    };
  } else if (!votingState) {
    return {
      state: VoterStates.initial,
      canBuyIn: true,
    };
  } else {
    switch (votingState.state) {
      case VotingStates.commit: {
        const ballot = ContractPrivateState.getBallot(privateState, contractState.round);
        const localState = ContractPrivateState.getLocalState(privateState, contractState.round);

        switch (localState) {
          case Contract.LocalState.initial:
            if (currentInProgressAction && currentInProgressAction.action === Actions.commit) {
              return {
                state: VoterStates.committing,
                actionId: currentInProgressAction.id,
              };
            } else {
              return {
                state: VoterStates.canCommit,
              };
            }
          case Contract.LocalState.committed:
            if (ballot != null) {
              return {
                state: VoterStates.committed,
                ballot,
              };
            } else {
              return {
                state: VoterStates.disenfranchised,
              };
            }
          case Contract.LocalState.revealed:
            return {
              state: VoterStates.disenfranchised,
            };
        }
      }
      case VotingStates.reveal: {
        const localState = ContractPrivateState.getLocalState(privateState, contractState.round);
        const ballot = ContractPrivateState.getBallot(privateState, contractState.round);
        switch (localState) {
          case Contract.LocalState.initial:
            return { state: VoterStates.disenfranchised };
          case Contract.LocalState.committed:
            if (currentInProgressAction && currentInProgressAction.action === Actions.reveal) {
              return {
                state: VoterStates.revealing,
                actionId: currentInProgressAction.id,
              };
            } else {
              if (ballot != null) {
                return {
                  state: VoterStates.canReveal,
                  ballot,
                };
              } else {
                return {
                  state: VoterStates.disenfranchised,
                };
              }
            }
          case Contract.LocalState.revealed:
            return {
              state: VoterStates.revealed,
            };
        }
      }
      case VotingStates.finalNegative:
      case VotingStates.finalCashOut:
        return {
          state: VoterStates.final,
        };
    }
  }
}

export function deriveBeneficiaryState(
  votingState: Voting | null,
  ephemeral: EphemeralState,
  coinPublicKey: Uint8Array,
): Beneficiary {
  if (!votingState) {
    return {
      state: BeneficiaryStates.notBeneficiary,
    };
  }

  const beneficiaryKey = Buffer.from(votingState.proposal.beneficiary, 'hex');
  if (!beneficiaryKey.equals(Buffer.from(coinPublicKey))) {
    return {
      state: BeneficiaryStates.notBeneficiary,
    };
  }

  const lastAction: AsyncAction | undefined | null = ephemeral.actions.latest
    ? ephemeral.actions.all[ephemeral.actions.latest]
    : null;
  switch (votingState.state) {
    case VotingStates.commit:
    case VotingStates.reveal:
      return {
        state: BeneficiaryStates.waitingForFinal,
      };
    case VotingStates.finalNegative:
      return {
        state: BeneficiaryStates.finalCantCashOut,
      };
    case VotingStates.finalCashOut:
      if (lastAction && lastAction.status === AsyncActionStates.inProgress && lastAction.action === Actions.cashOut) {
        return {
          state: BeneficiaryStates.cashingOut,
          actionId: lastAction.id,
        };
      } else {
        return {
          state: BeneficiaryStates.finalCanCashOut,
        };
      }
  }
}
