import { QueryContext, sampleContractAddress } from '@midnight-ntwrk/compact-runtime';
import { DaoAPI, DaoConfig } from '@midnight-ntwrk/dao-api';
import { DAOInstance, GetAPIOptions } from '@midnight-ntwrk/dao-api-testing';
import { Lens, pipe, Resource } from '@midnight-ntwrk/dao-helpers';
import { withZSwapState, withZswapWitnesses } from '@midnight-ntwrk/midnight-js-contracts';
import * as crypto from 'crypto';
import * as pino from 'pino';
import { configToCosts } from './config.js';
import { ContractPrivateState, PrivateStateBloc } from './contract-private-state.js';
import { DirectAPI, DirectAPIParams, PrivateState } from './direct-api-implementation.js';
import { EphemeralStateBloc } from './ephemeral-state.js';
import { LedgerStateBloc } from './ledger-state.js';
import * as Contract from './managed/micro-dao/contract/index.cjs';
import { Witnesses } from './witnesses.js';

type ContractFactory = (coinPublicKey: Uint8Array) => Contract.Contract<PrivateState>;

/**
 * Holds an in-memory "deployed" contract state and allows to join it as multiple parties.
 *
 * Such setup is close semantically to the real network, but also makes it relatively easy to simulate various multi-party scenarios
 */
export class DirectDAOInstance implements DAOInstance {
  static init(config: DaoConfig, logger: pino.Logger): Resource<DirectDAOInstance> {
    const daoInstanceLogger = logger.child({ what: 'DAO Instance' });
    const contractFactory = (coinPublicKey: Uint8Array) =>
      new Contract.Contract<PrivateState>(withZswapWitnesses(Witnesses())(coinPublicKey));
    return pipe(
      Resource.from(() => this.prepareOrganizer(contractFactory, configToCosts(config))),
      Resource.mproduct(({ contractState }) =>
        LedgerStateBloc.init(
          {
            currentPrivateState: undefined,
            originalState: contractState,
            transactionContext: new QueryContext(contractState.data, sampleContractAddress()),
          },
          daoInstanceLogger.child({ what: 'Ledger State' }),
        ),
      ),
      Resource.map(
        ([organizer, ledger]) =>
          new DirectDAOInstance(
            contractFactory,
            ledger,
            { privateState: organizer.privateState, coinAddress: organizer.coinPublicKey },
            daoInstanceLogger,
          ),
      ),
    );
  }

  constructor(
    private readonly contractFactory: ContractFactory,
    private readonly ledger: LedgerStateBloc,
    private readonly organizerState: { privateState: PrivateState; coinAddress: Uint8Array },
    private readonly logger: pino.Logger,
  ) {}

  getAPI(options: GetAPIOptions): Resource<{
    api: DaoAPI;
    address: string;
  }> {
    const state = options.organizer
      ? this.organizerState
      : { privateState: withZSwapState(ContractPrivateState.generate()), coinAddress: crypto.randomBytes(32) };
    const coinAddress = state.coinAddress.toString('hex');

    return pipe(
      PrivateStateBloc.init(
        state.privateState,
        Lens.field('contract'),
        this.logger.child({ what: 'Private State', organizer: options.organizer, address: coinAddress }),
      ),
      Resource.zip(
        EphemeralStateBloc.init(
          this.logger.child({ what: 'Ephemeral State', organizer: options.organizer, address: coinAddress }),
        ),
      ),
      Resource.flatMap(([privateStateBloc, ephemeralStateBloc]: [PrivateStateBloc<PrivateState>, EphemeralStateBloc]) => {
        const params: DirectAPIParams = {
          contract: this.contractFactory(state.coinAddress),
          coinPublicKey: state.coinAddress,
          ledger: this.ledger,
          priv: privateStateBloc,
          ephemeral: ephemeralStateBloc,
          logger: this.logger.child({ what: 'DAO API', organizer: options.organizer, address: coinAddress }),
        };
        return pipe(
          params,
          DirectAPI.init,
          Resource.map((api) => ({ api, address: coinAddress })),
        );
      }),
    );
  }

  static prepareOrganizer(contractFactory: ContractFactory, costs: Contract.Costs) {
    const newPrivateState = withZSwapState(ContractPrivateState.generate());
    const newCoinPublicKey = crypto.randomBytes(32);
    const [privateState, contractState] = contractFactory(newCoinPublicKey).initialState(
      newPrivateState,
      newPrivateState.contract.dappSecretKey,
      costs,
    );
    return {
      contractState,
      privateState,
      coinPublicKey: newCoinPublicKey,
    };
  }
}
