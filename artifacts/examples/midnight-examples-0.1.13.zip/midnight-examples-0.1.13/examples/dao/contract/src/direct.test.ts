import { DaoConfig } from '@midnight-ntwrk/dao-api';
import { runDaoAPITest } from '@midnight-ntwrk/dao-api-testing';
import { Resource } from '@midnight-ntwrk/dao-helpers';
import { webcrypto } from 'node:crypto';
import * as pino from 'pino';
import pinoPretty from 'pino-pretty';
import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import { createWriteStream } from 'node:fs';
import * as jest from '@jest/globals';
import { DirectDAOInstance } from './direct-dao-instance.js';
import { networkId, setNetworkId } from '@midnight-ntwrk/midnight-js-network-id';

// @ts-ignore: It's needed as a basis for crypto in WASM, and yet there are incompatibilities between browser crypto and node.js webcrypto
globalThis.crypto = webcrypto;

// Setting network id is needed to properly serialize many datatypes defined in ledger
// This mechanism prevents transactions from e.g. local development to be accepted on a devnet
setNetworkId(networkId.undeployed);

jest.jest.setTimeout(20_000); // Some property-based tests take a bit longer

// Logs can be very chatty - so collect all of them into this file, but display on stdout only the most severe ones
const logPath = path.resolve(new URL(import.meta.url).pathname, '../../log/test.log');
await fs.mkdir(path.dirname(logPath), { recursive: true });

// @ts-ignore:  pino type definitions don't match for some reason
const pretty: pinoPretty.PrettyStream = pinoPretty({
  colorize: true,
  sync: true,
});
const level = 'trace' as const;
const logger = pino.pino(
  {
    level,
    depthLimit: 20,
  },
  pino.multistream([
    { stream: pretty, level: 'fatal' },
    { stream: createWriteStream(logPath), level },
  ]),
);

// This runs actual tests.
//
// It uses class `DirectDAOInstance` as a means for state synchronization between parties
// `DirectAPI` from `direct-api-implementation.ts` represents a single participant in the contract
runDaoAPITest({
  implementationName: 'Direct contract',
  suite: 'full',
  instance: (config: DaoConfig) => DirectDAOInstance.init(config, logger),
  infrastructure: () => Resource.from(() => undefined),
  logger,
});

jest.afterAll(() => {
  console.log(`${level} logs written to ${logPath}`);
}, 100);
