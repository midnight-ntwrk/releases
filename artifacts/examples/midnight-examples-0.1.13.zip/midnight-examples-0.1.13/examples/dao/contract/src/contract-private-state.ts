import { Bloc, block, Lens, Resource } from '@midnight-ntwrk/dao-helpers';
import * as pino from 'pino';
import { map, Observable } from 'rxjs';
import * as Contract from './managed/micro-dao/contract/index.cjs';

/**
 * Looking from perspective of witness functions defined in the contract, 3 pieces of information are
 * needed in the private state:
 *   - the secret key, so that party credentials to perform action can be verified
 *   - the ballot
 *   - the state of voting
 *
 * The latter 2 are stored on a per-round basis, which nicely simplify state management and possible restoration after
 * long inactivity, etc. - there is no need to watch for any sort of events on contract state
 */
export type ContractPrivateState = {
  dappSecretKey: Buffer;
  statesPerRound: Record<string, { ballot: boolean | null; state: Contract.LocalState }>;
};

/**
 * Operations on private state.
 *
 * This pattern of same-named type and object holding operations has its issues (like IDEs have slightly harder time with
 * navigation, or not allowing for tree shakinig), but allows to nicely group related functions together and things
 * are quite intuitive on call-sites
 */
export const ContractPrivateState = {
  generate: (): ContractPrivateState => {
    return {
      dappSecretKey: crypto.getRandomValues(Buffer.alloc(32)),
      statesPerRound: {},
    };
  },
  putBallot: (state: ContractPrivateState, ballot: boolean, round: bigint): ContractPrivateState => {
    const targetRound = round.toString(10);
    if (targetRound === undefined) {
      return state;
    }

    const currentRoundState = ContractPrivateState.getLocalState(state, round);

    const targetRoundState = {
      state: currentRoundState,
      ballot: ballot,
    };

    return {
      ...state,
      statesPerRound: {
        ...state.statesPerRound,
        [targetRound]: targetRoundState,
      },
    };
  },
  getBallot: (state: ContractPrivateState, round: bigint): boolean | null => {
    return state.statesPerRound[round.toString(10)]?.ballot ?? null;
  },
  getLocalState: (state: ContractPrivateState, round: bigint): Contract.LocalState => {
    return state.statesPerRound[round.toString(10)]?.state ?? Contract.LocalState.initial;
  },
  advanceLocalState: (state: ContractPrivateState, round: bigint): ContractPrivateState => {
    const currentRoundState = ContractPrivateState.getLocalState(state, round);
    const currentRoundBallot = ContractPrivateState.getBallot(state, round);

    const nextState: Contract.LocalState = block(() => {
      switch (currentRoundState) {
        case Contract.LocalState.initial:
          return Contract.LocalState.committed;
        case Contract.LocalState.committed:
          return Contract.LocalState.revealed;
        case Contract.LocalState.revealed:
          return Contract.LocalState.revealed;
      }
    });

    return {
      ...state,
      statesPerRound: {
        ...state.statesPerRound,
        [round.toString(10)]: {
          state: nextState,
          ballot: currentRoundBallot,
        },
      },
    };
  },
};

/**
 * Bloc is a wrapper for holding state. Like an Angular service or Redux or Mobx store
 */
export class PrivateStateBloc<T> extends Bloc<T> {
  static init<T>(
    initialState: T,
    contractStateLens: Lens<T, ContractPrivateState>,
    logger: pino.Logger,
  ): Resource<PrivateStateBloc<T>> {
    return Bloc.asResource(() => new PrivateStateBloc(initialState, contractStateLens, logger));
  }

  #contractStateLens: Lens<T, ContractPrivateState>;
  contractState$: Observable<ContractPrivateState>;

  constructor(initialState: T, contractStateLens: Lens<T, ContractPrivateState>, logger: pino.Logger) {
    super(initialState, logger);
    this.#contractStateLens = contractStateLens;
    this.contractState$ = this.state$.pipe(map((state) => this.#contractStateLens.get(state)));
  }

  set(newState: T): Observable<void> {
    return this.updateState(() => newState);
  }
}
