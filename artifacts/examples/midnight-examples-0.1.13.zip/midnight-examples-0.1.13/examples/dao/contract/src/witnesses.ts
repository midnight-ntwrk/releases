import { WitnessContext } from '@midnight-ntwrk/compact-runtime';
// Should this be a separate package within Midnight.js?
import { NonZSwapWitnesses } from '@midnight-ntwrk/midnight-js-contracts';
import { maybeFromNullable } from './compact-helpers.js';
import { ContractPrivateState } from './contract-private-state.js';
import * as Contract from './managed/micro-dao/contract/index.cjs';

/**
 * Witnesses implementation. It essentially is a thin translation layer between private state and the witnesses interface contract expects.
 *
 * What is important - here is only implementation of contract-specific witnesses, as Zswap witnesses are added separately
 */
export const Witnesses = (): NonZSwapWitnesses<Contract.Witnesses<ContractPrivateState>> => ({
  local_advance_state(context: WitnessContext<Contract.Ledger, ContractPrivateState>): [ContractPrivateState, void] {
    return [ContractPrivateState.advanceLocalState(context.privateState, context.ledger.round), undefined];
  },
  local_path_of_cm(
    context: WitnessContext<Contract.Ledger, ContractPrivateState>,
    cm: Uint8Array,
  ): [ContractPrivateState, Contract.Maybe<Contract.MerkleTreePath<Uint8Array>>] {
    return [
      context.privateState,
      maybeFromNullable(context.ledger.committedVotes.findPathForLeaf(cm), {} as Contract.MerkleTreePath<Uint8Array>),
    ];
  },
  local_record_vote(context: WitnessContext<Contract.Ledger, ContractPrivateState>, vote: boolean): [ContractPrivateState, void] {
    return [ContractPrivateState.putBallot(context.privateState, vote, context.ledger.round), undefined];
  },
  local_secret_key(context: WitnessContext<Contract.Ledger, ContractPrivateState>): [ContractPrivateState, Uint8Array] {
    return [context.privateState, context.privateState.dappSecretKey];
  },
  local_state(context: WitnessContext<Contract.Ledger, ContractPrivateState>): [ContractPrivateState, Contract.LocalState] {
    return [context.privateState, ContractPrivateState.getLocalState(context.privateState, context.ledger.round)];
  },
  local_vote_cast(
    context: WitnessContext<Contract.Ledger, ContractPrivateState>,
  ): [ContractPrivateState, Contract.Maybe<boolean>] {
    return [
      context.privateState,
      maybeFromNullable(ContractPrivateState.getBallot(context.privateState, context.ledger.round), false),
    ];
  },
});
