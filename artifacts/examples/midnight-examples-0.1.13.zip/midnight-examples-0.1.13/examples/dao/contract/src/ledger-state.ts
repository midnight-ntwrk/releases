import { CircuitContext } from '@midnight-ntwrk/compact-runtime';
import { Bloc, Resource } from '@midnight-ntwrk/dao-helpers';
import * as pino from 'pino';

/**
 * Bloc holding the ledger state - here in a form of CircuitContext (because that way result from one execution
 * can be passed as a context to a new one). It is a building block of `DirectDAOInstance`
 */
export class LedgerStateBloc extends Bloc<CircuitContext<unknown>> {
  static init(initialState: CircuitContext<unknown>, logger: pino.Logger): Resource<LedgerStateBloc> {
    return Bloc.asResource(() => new LedgerStateBloc(initialState, logger));
  }

  readonly address: string;
  constructor(initialState: CircuitContext<unknown>, logger: pino.Logger) {
    super({ ...initialState, currentPrivateState: undefined }, logger);
    this.address = initialState.transactionContext.address;
  }

  set(newState: CircuitContext<unknown>) {
    return super.updateState(() => ({ ...newState, currentPrivateState: undefined }), 'set');
  }
}
