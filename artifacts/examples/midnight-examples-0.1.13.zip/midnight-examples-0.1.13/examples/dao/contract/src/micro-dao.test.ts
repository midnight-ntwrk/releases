import { describe, expect, it } from '@jest/globals';
import {
  CircuitContext,
  ContractState,
  encodeCoinPublicKey,
  QueryContext,
  sampleContractAddress,
  WitnessContext,
} from '@midnight-ntwrk/compact-runtime';
import * as ledger from '@midnight-ntwrk/ledger';
import { sampleCoinPublicKey } from '@midnight-ntwrk/ledger';
import { StateWithZswap, withZSwapState, withZswapWitnesses } from '@midnight-ntwrk/midnight-js-contracts';
import { networkId, setNetworkId } from '@midnight-ntwrk/midnight-js-network-id';
import { webcrypto } from 'node:crypto';
import { ContractPrivateState } from './contract-private-state.js';
import * as Contract from './managed/micro-dao/contract/index.cjs';
import { Witnesses } from './witnesses.js';
import { configToCosts, defaultConfig } from './config.js';

// @ts-ignore: It's needed as a basis for crypto in WASM, and yet there are incompatibilities between browser crypto and node.js webcrypto
globalThis.crypto = webcrypto;

// Setting network id is needed to properly serialize many datatypes defined in ledger
// This mechanism prevents transactions from e.g. local development to be accepted on a devnet
setNetworkId(networkId.undeployed);

const dummyAddress = sampleContractAddress();

// A simple test suite, which shows, how to use runtime and contract APIs to test various scenarios
// An actual suite for the DAO contract/DApp is defined in the `api-testing` package and is called from `direct.test.ts` file
describe('Micro DAO', () => {
  // expect(...).toEqual(...), which enforces same type
  function expectEqual<T>(expected: T, actual: T): void {
    return expect(actual).toEqual(expected);
  }

  // Essentially every contract making use of `std`, will also need to define
  // witnesses for zswap-related operations. Midnight.js provides a couple of helpers to make it more convenient
  type PrivateState = StateWithZswap<ContractPrivateState>;
  const generateState = () => ({
    privateState: withZSwapState(ContractPrivateState.generate()),
    coinPublicKey: encodeCoinPublicKey(sampleCoinPublicKey()),
  });

  // Compiled contract is a regular JS class, but requires witnesses to be ready
  const createContract = (coinPublicKey: Uint8Array) =>
    new Contract.Contract<PrivateState>(withZswapWitnesses(Witnesses())(coinPublicKey));

  // Runtime requires a bit of additional structure for running circuits...
  function circuitContext<T>(privateState: T, contractState: ContractState): CircuitContext<T> {
    return {
      originalState: contractState,
      currentPrivateState: privateState,
      transactionContext: new QueryContext(contractState.data, dummyAddress),
    };
  }

  // ... as well as provides witnesses with some additional data, which needs to be prepared, when wanting to call witness directly
  const witnessContext = (
    privateState: PrivateState,
    contractState: ContractState,
  ): WitnessContext<Contract.Ledger, PrivateState> => ({
    privateState,
    ledger: Contract.ledger(contractState.data),
    contractAddress: dummyAddress,
  });

  it('generates initial state deterministically', () => {
    const { privateState, coinPublicKey } = generateState();
    const contract = createContract(coinPublicKey);

    // Contract.initialState is JS representation of `ledger.constructor` from contract code
    const [newPrivateState1, contractState1] = contract.initialState(
      privateState,
      privateState.contract.dappSecretKey,
      configToCosts(defaultConfig),
    );
    const [newPrivateState2, contractState2] = contract.initialState(
      privateState,
      privateState.contract.dappSecretKey,
      configToCosts(defaultConfig),
    );

    expect(newPrivateState1).toBe(newPrivateState2);
    expect(contractState1.serialize()).toEqual(contractState2.serialize());
  });

  it('sets the organizer correctly', () => {
    const { privateState, coinPublicKey } = generateState();
    const contract = createContract(coinPublicKey);
    const [newPrivateState1, contractState1] = contract.initialState(
      privateState,
      privateState.contract.dappSecretKey,
      configToCosts(defaultConfig),
    );

    // Contract.pureCircuits provides access to exported circuits, which are pure functions, without passing context
    // This allows the JS code to re-use functions from contract, e.g. to ensure that certain invariants are met
    const publicKey = Contract.pureCircuits.public_key(
      contract.witnesses.local_secret_key(witnessContext(newPrivateState1, contractState1))[1],
    );

    // Contract.ledger allows to transform state representation used by ledger and runtime into one, that is more intuitive to use from JS
    expectEqual(publicKey, Contract.ledger(contractState1.data).organizer);
  });

  it('allows to set proposal by organiser', () => {
    const { privateState, coinPublicKey } = generateState();
    const contract = createContract(coinPublicKey);
    const initialState = contract.initialState(privateState, privateState.contract.dappSecretKey, configToCosts(defaultConfig));
    const coin = ledger.encodeCoinInfo(ledger.createCoinInfo(ledger.nativeToken(), 10_000_000n));

    // For impure circuits, a context needs to be prepared basing on initial state, rest of arguments relates directly to the ones defined in contract source
    const afterSettingProposal = contract.circuits.set_topic(
      circuitContext(initialState[0], initialState[1]),
      'foo',
      { bytes: coinPublicKey },
      coin,
    );

    const finalState: Contract.Ledger = Contract.ledger(afterSettingProposal.context.transactionContext.state);

    expectEqual(finalState.state, Contract.LedgerState.commit);
    expectEqual(finalState.topic, { is_some: true, value: 'foo' });
  });

  it('allows organiser to advance', () => {
    const { privateState, coinPublicKey } = generateState();
    const contract = createContract(coinPublicKey);
    const initialState = contract.initialState(privateState, privateState.contract.dappSecretKey, configToCosts(defaultConfig));
    const afterSettingProposal = contract.circuits.set_topic(
      circuitContext(initialState[0], initialState[1]),
      'foo',
      { bytes: coinPublicKey },
      ledger.encodeCoinInfo(ledger.createCoinInfo(ledger.nativeToken(), 10_000_000n)),
    );

    // In case a sequence of calls needs to be made, one can just passthrough context from a result
    const afterAdvance = contract.circuits.advance(afterSettingProposal.context);

    const finalState: Contract.Ledger = Contract.ledger(afterAdvance.context.transactionContext.state);

    expectEqual(finalState.state, Contract.LedgerState.reveal);
    expectEqual(finalState.topic, { is_some: true, value: 'foo' });
  });

  it('does not allow other entity to advance', () => {
    const { privateState: organizerPrivateState, coinPublicKey: organizerCoinPublicKey } = generateState();
    const organizerContract = createContract(organizerCoinPublicKey);
    const initialState = organizerContract.initialState(
      organizerPrivateState,
      organizerPrivateState.contract.dappSecretKey,
      configToCosts(defaultConfig),
    );
    const afterSettingProposal = organizerContract.circuits.set_topic(
      circuitContext(initialState[0], initialState[1]),
      'foo',
      { bytes: organizerCoinPublicKey },
      ledger.encodeCoinInfo(ledger.createCoinInfo(ledger.nativeToken(), 10_000_000n)),
    );

    // Simulate a different party interacting with contract:
    const tryAdvance = () => {
      // 1. create dedicated private state
      const newState = generateState();
      // 2. create dedicated contract instance - this is only because of witnesses requirement and need to pass coin public key there
      const newContract = createContract(newState.coinPublicKey);
      // 3. Override `currentPrivateState` in context before making a call
      return newContract.circuits.advance({ ...afterSettingProposal.context, currentPrivateState: newState.privateState });
    };

    expect(tryAdvance).toThrow();
  });
});
