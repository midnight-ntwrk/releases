import { DaoConfig } from '@midnight-ntwrk/dao-api';
import { Costs } from './managed/micro-dao/contract/index.cjs';

export const defaultConfig: DaoConfig = {
  seedCoins: 10_000_000,
  buyInCoins: 2_000_000,
};

export const configToCosts = (config: DaoConfig): Costs => ({
  buy_in_dust: BigInt(config.buyInCoins),
  seed_dust: BigInt(config.seedCoins),
});

export const costsToConfig = (costs: Costs): DaoConfig => ({
  buyInCoins: Number(costs.buy_in_dust),
  seedCoins: Number(costs.seed_dust),
});
