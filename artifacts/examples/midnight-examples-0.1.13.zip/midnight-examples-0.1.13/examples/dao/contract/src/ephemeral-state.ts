import { ActionId, AsyncAction, DaoState } from '@midnight-ntwrk/dao-api';
import { Bloc, Resource } from '@midnight-ntwrk/dao-helpers';
import * as pino from 'pino';

/**
 * Ephemeral state of DAO - manages async actions and their statuses
 * It does not need to be persisted at all, but it is an important
 * piece of data mostly in terms of knowing if there is some local action in-progress
 */
export type EphemeralState = { actions: DaoState['actions'] };

const emptyEphemeralState: EphemeralState = {
  actions: {
    latest: null,
    all: {},
  },
};
const addAction =
  (action: AsyncAction) =>
  (state: EphemeralState): EphemeralState => ({
    actions: {
      latest: action.id,
      all: {
        ...state.actions.all,
        [action.id]: action,
      },
    },
  });

const updateAction =
  (actionId: ActionId, updater: (action: AsyncAction) => AsyncAction) =>
  (state: EphemeralState): EphemeralState => {
    return {
      actions: {
        ...state.actions,
        all: {
          ...state.actions.all,
          [actionId]: updater(state.actions.all[actionId]),
        },
      },
    };
  };
const succeedAction = (id: ActionId) => updateAction(id, AsyncAction.succeeded);
const failAction = (id: ActionId, error: string) => updateAction(id, AsyncAction.failed(error));

export class EphemeralStateBloc extends Bloc<EphemeralState> {
  static init(logger: pino.Logger): Resource<EphemeralStateBloc> {
    return Bloc.asResource(() => new EphemeralStateBloc(emptyEphemeralState, logger));
  }

  constructor(initialState: EphemeralState, logger: pino.Logger) {
    super(initialState, logger);
  }

  addAction(action: AsyncAction) {
    return this.updateState(addAction(action));
  }

  succeedAction(id: ActionId) {
    return this.updateState(succeedAction(id));
  }

  failAction(id: ActionId, error: string) {
    return this.updateState(failAction(id, error));
  }
}
