import './globals'; // This has to be loaded first as it defines global `process`
import React from 'react';
import ReactDOM from 'react-dom/client';
import { ThemeProvider } from '@mui/material';
import CssBaseline from '@mui/material/CssBaseline';
import {
  toLedgerNetworkId,
  toRuntimeNetworkId,
  toZswapNetworkId,
  type NetworkId,
} from '@midnight-ntwrk/midnight-js-network-id';
import * as zswap from '@midnight-ntwrk/zswap';
import * as runtime from '@midnight-ntwrk/compact-runtime';
import * as ledger from '@midnight-ntwrk/ledger';

import App from './App';
import { theme } from './config/theme';

const theNetworkId = import.meta.env.VITE_NETWORK_ID as NetworkId;
zswap.setNetworkId(toZswapNetworkId(theNetworkId));
runtime.setNetworkId(toRuntimeNetworkId(theNetworkId));
ledger.setNetworkId(toLedgerNetworkId(theNetworkId));

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <CssBaseline />
    <ThemeProvider theme={theme}>
      <App />
    </ThemeProvider>
  </React.StrictMode>,
);
