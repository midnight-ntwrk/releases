import { type ReactElement } from 'react';
import { Grid, Box, Typography } from '@mui/material';

import { GameBoardCell } from './GameBoardCell';

interface GameBoardProps {
  picks?: number[];
  isBlueSide: boolean;
  shipPosition?: number;
  currentPick?: number;
  dataTestId?: string;
  handleCellClick?: (position: number) => void;
  title: string;
}

export const GameBoard = ({
  picks = [],
  isBlueSide,
  shipPosition = -1,
  currentPick = -1,
  dataTestId = '',
  handleCellClick,
  title,
}: GameBoardProps): ReactElement => {
  return (
    <Box data-test-id={dataTestId} sx={{ width: '40vw' }}>
      <Typography color="text.primary" fontSize="5vw" textAlign="center">
        {title}
      </Typography>
      <Grid container>
        {[...Array(9).keys()].map((cellPosition: number) => {
          const isShip = shipPosition === cellPosition;
          const isMissed = picks.includes(cellPosition);
          const isTargeted = currentPick === cellPosition;
          return (
            <Grid item xs={4} key={`${isBlueSide ? 'blue' : 'red'}-cell-${cellPosition}`}>
              <GameBoardCell
                dataTestId={`${dataTestId}-cell-${cellPosition}`}
                isBlueSide={isBlueSide}
                isShip={isShip}
                isMissed={isMissed}
                isTargeted={isTargeted}
                handleCellClick={
                  isShip || isMissed || !handleCellClick
                    ? undefined
                    : () => {
                        handleCellClick(cellPosition);
                      }
                }
                key={`${isBlueSide ? 'blue' : 'red'}-cell-${cellPosition}`}
              />
            </Grid>
          );
        })}
      </Grid>
    </Box>
  );
};
