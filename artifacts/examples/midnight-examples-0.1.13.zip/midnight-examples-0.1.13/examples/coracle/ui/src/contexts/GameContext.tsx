import { createContext, type ReactElement, type ReactNode, useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

import { useBackdropContext } from '../hooks';

// TBD: Import from API
type DispatchActionType =
  | { type: 'CREATE_GAME' }
  | { type: 'PICK_POSITION'; payload: number }
  | { type: 'GUESS_POSITION'; payload: number };

// TBD: Import from API
type GameStatusType = 'NO_GAME' | 'INITIAL' | 'BLUE_GUESS' | 'RED_GUESS' | 'RED_WINS' | 'BLUE_WINS';

// TBD: Import from API
type PlayerSideType = 'BLUE' | 'RED';

// TBD: Import from API
interface CoracleState {
  status: GameStatusType | undefined;
  blueGuess: number[];
  redGuess: number[];
  playerPosition?: number;
  playerSide: PlayerSideType;
  isPlayerTurn?: boolean;
  gameAddress?: string;
  playerWon: boolean;
}

export interface GameContextType {
  state: CoracleState | undefined;
  dispatch: (action: DispatchActionType) => void;
}

export const GameContext = createContext<GameContextType | undefined>(undefined);

export const GameProvider = ({ children }: { children: ReactNode }): ReactElement => {
  const [state, setState] = useState<CoracleState>({
    status: 'NO_GAME',
    blueGuess: [],
    redGuess: [],
    playerSide: 'BLUE',
    playerWon: false,
  });

  const { openBackdrop, closeBackdrop } = useBackdropContext();
  const location = useLocation();

  useEffect(() => {
    if (location.pathname !== '/') {
      // TBD: Get game data by game address/id
      setState({ ...state, status: 'INITIAL' });
    }
  }, [location]);

  const createGame = (): void => {
    // TBD: call API to create new game and receive address

    openBackdrop('Creating new game...');
    setTimeout(() => {
      closeBackdrop();
      setState({ ...state, status: 'INITIAL', gameAddress: '123!@#qwe' });
    }, 2000);
  };

  const pickPosition = (position: number): void => {
    // TBD: call API to pick player position
    openBackdrop("Waiting for oppnent's pick!");
    setTimeout(() => {
      closeBackdrop();
      setState({ ...state, status: 'BLUE_GUESS', playerPosition: position });
    }, 2000);
  };

  const guessPosition = (position: number): void => {
    // TBD: call API to guess opponents position
    openBackdrop('You missed, red side turn!');
    setTimeout(() => {
      closeBackdrop();
      setState({ ...state, blueGuess: [...state.blueGuess, position] });
    }, 2000);
  };

  const dispatch = (action: DispatchActionType): void => {
    try {
      switch (action.type) {
        case 'CREATE_GAME': {
          createGame();
          break;
        }
        case 'PICK_POSITION': {
          pickPosition(action.payload);
          break;
        }
        case 'GUESS_POSITION': {
          guessPosition(action.payload);
          break;
        }
      }
    } catch (error) {
      if (error instanceof Error) {
        console.error(error);
      }
    }
  };

  return <GameContext.Provider value={{ state, dispatch }}>{children}</GameContext.Provider>;
};
