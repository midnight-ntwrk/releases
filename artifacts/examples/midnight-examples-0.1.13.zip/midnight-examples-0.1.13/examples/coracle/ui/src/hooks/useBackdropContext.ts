import { useContext } from 'react';

import { BackdropContext, type BackdropContextType } from '../contexts';

export const useBackdropContext = (): BackdropContextType => {
  const state = useContext(BackdropContext);

  if (state === undefined) {
    throw new Error('Context must be called within a provider.');
  }

  return state;
};
