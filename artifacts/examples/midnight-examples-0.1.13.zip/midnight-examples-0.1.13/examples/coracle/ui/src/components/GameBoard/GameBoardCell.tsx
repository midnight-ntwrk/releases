import { type ReactElement } from 'react';
import { Box, useTheme } from '@mui/material';

interface GameBoardCellProps {
  isBlueSide: boolean;
  handleCellClick?: () => void;
  isShip: boolean;
  isMissed: boolean;
  isTargeted: boolean;
  dataTestId?: string;
}

export const GameBoardCell = ({
  isBlueSide,
  handleCellClick,
  isShip = false,
  isMissed = false,
  isTargeted = false,
  dataTestId = '',
}: GameBoardCellProps): ReactElement => {
  const theme = useTheme();

  return (
    <Box
      data-test-id={dataTestId}
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        cursor: handleCellClick ? 'pointer' : 'initial',
        height: '10vw',
        m: '0.5vw',
        border: `3px solid ${isBlueSide ? theme.palette.primary.main : theme.palette.secondary.main}`,
        '&:hover': handleCellClick ? { background: 'rgba(155, 201, 59, 0.2)' } : {},
      }}
      onClick={handleCellClick}
    >
      {isShip && <Box component="img" sx={{ height: '12vw' }} src="/battleship.png" alt="battleship" />}
      {isMissed && <Box component="img" sx={{ height: '12vw' }} src="/cross.png" alt="cross" />}
      {isTargeted && <Box component="img" sx={{ height: '12vw' }} src="/crosshair.png" alt="crosshair" />}
    </Box>
  );
};
