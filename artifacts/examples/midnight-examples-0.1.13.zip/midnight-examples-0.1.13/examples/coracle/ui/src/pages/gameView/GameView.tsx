import { type ReactElement, useState } from 'react';
import { Box, Button, Typography } from '@mui/material';

import { useGameContext } from '../../hooks';
import { GameBoard } from '../../components';

export const GameView = (): ReactElement => {
  const [selectedPosition, setSelectedPosition] = useState<number>(-1);
  const { state, dispatch } = useGameContext();

  const gameInProgress = state?.status !== 'BLUE_WINS' && state?.status !== 'RED_WINS';

  const handlePositionPick = (): void => {
    if (selectedPosition >= 0) {
      dispatch({ type: 'PICK_POSITION', payload: selectedPosition });
      setSelectedPosition(-1);
    }
  };

  const handleShot = (): void => {
    if (selectedPosition >= 0) {
      dispatch({ type: 'GUESS_POSITION', payload: selectedPosition });
      setSelectedPosition(-1);
    }
  };

  return (
    <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
      {state?.status === 'INITIAL' ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
          <GameBoard
            dataTestId="pick-board"
            isBlueSide={true}
            title="Pick position!"
            handleCellClick={(position: number) => {
              setSelectedPosition(position);
            }}
            shipPosition={selectedPosition}
          />
          <Button
            data-test-id="position-pick-button"
            disabled={selectedPosition < 0}
            variant="contained"
            size="large"
            sx={{ px: 6, mr: 2, mt: 3 }}
            onClick={handlePositionPick}
          >
            Ready!
          </Button>
        </Box>
      ) : (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'row' }}>
          <GameBoard
            dataTestId="player-board"
            isBlueSide={true}
            title="Your board"
            shipPosition={state?.playerPosition}
            picks={state?.redGuess}
          />
          {state?.status !== 'BLUE_WINS' && state?.status !== 'RED_WINS' ? (
            <Button
              data-test-id="shoot-button"
              disabled={selectedPosition < 0}
              variant="contained"
              size="large"
              sx={{ px: 6, mx: 2, mt: 3 }}
              onClick={handleShot}
            >
              Shoot!
            </Button>
          ) : (
            <Box sx={{ display: 'flex', width: '15vw', flexDirection: 'column', textAlign: 'center' }}>
              <Typography color="text.primary" variant="h5" textAlign="center">
                {' '}
                {state?.status === 'RED_WINS' ? 'Red' : 'Blue'} wins!
              </Typography>
              <Button
                data-test-id="cashout-button"
                disabled={!state?.playerWon}
                variant="contained"
                size="large"
                sx={{ px: 6, mx: 2, mt: 3 }}
                onClick={handleShot}
              >
                Cashout
              </Button>
            </Box>
          )}
          <GameBoard
            dataTestId="opponent-board"
            isBlueSide={false}
            title="Opponent's board"
            currentPick={selectedPosition}
            picks={state?.blueGuess}
            handleCellClick={
              gameInProgress
                ? (position: number) => {
                    setSelectedPosition(position);
                  }
                : undefined
            }
          />
        </Box>
      )}
    </Box>
  );
};
