import { type ReactElement } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Button, Typography } from '@mui/material';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';

import { useGameContext } from '../../hooks/useGameContext';

export const CreateGame = (): ReactElement => {
  const navigate = useNavigate();

  const { state, dispatch } = useGameContext();

  const handleGameCreate = (): void => {
    dispatch({ type: 'CREATE_GAME' });
  };
  return (
    <Box sx={{ height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      {state?.status === 'NO_GAME' && (
        <Button
          variant="contained"
          size="large"
          sx={{ px: 6, mr: 2 }}
          onClick={handleGameCreate}
          data-test-id="create-game-button"
        >
          Create new game
        </Button>
      )}
      {state?.gameAddress != null && (
        <Typography
          variant="h3"
          color="text.primary"
          sx={{ cursor: 'pointer' }}
          onClick={() => {
            navigate(`/${state.gameAddress ?? ''}`);
          }}
        >
          Your game address is: {state.gameAddress}
          <ContentCopyIcon sx={{ fontSize: '2.5rem', ml: 2 }} />
        </Typography>
      )}
    </Box>
  );
};
