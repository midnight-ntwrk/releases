import { createContext, type ReactElement, type ReactNode, useState } from 'react';

import { BackdropLoader } from '../components';

export interface BackdropContextType {
  openBackdrop: (message?: string) => void;
  closeBackdrop: (message?: string) => void;
}

export const BackdropContext = createContext<BackdropContextType | undefined>(undefined);

export const BackdropProvider = ({ children }: { children: ReactNode }): ReactElement => {
  const [backdropInfo, setBackdropInfo] = useState<string>('');
  const [isOpen, setIsOpen] = useState<boolean>(false);

  const openBackdrop = (message?: string): void => {
    setBackdropInfo(message ?? '');
    setIsOpen(true);
  };

  const closeBackdrop = (): void => {
    setIsOpen(false);
  };

  return (
    <BackdropContext.Provider value={{ openBackdrop, closeBackdrop }}>
      {isOpen && <BackdropLoader title={backdropInfo} />}
      {children}
    </BackdropContext.Provider>
  );
};
