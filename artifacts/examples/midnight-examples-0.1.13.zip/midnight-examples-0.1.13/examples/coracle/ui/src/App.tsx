import { type ReactElement } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { Box, useTheme } from '@mui/material';

import { CreateGame } from './pages/createGame';
import { GameView } from './pages/gameView';
import { GameProvider, BackdropProvider } from './contexts';

const App = (): ReactElement => {
  const theme = useTheme();

  return (
    <Box sx={{ background: theme.palette.background.default, minHeight: '100vh' }}>
      <Router>
        <BackdropProvider>
          <GameProvider>
            <Routes>
              <Route path="/" element={<CreateGame />} />
              <Route path="/*" element={<GameView />} />
            </Routes>
          </GameProvider>
        </BackdropProvider>
      </Router>
    </Box>
  );
};

export default App;
