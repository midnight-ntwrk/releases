import { useContext } from 'react';

import { GameContext, type GameContextType } from '../contexts';

export const useGameContext = (): GameContextType => {
  const state = useContext(GameContext);

  if (state === undefined) {
    throw new Error('Context must be called within a provider.');
  }

  return state;
};
