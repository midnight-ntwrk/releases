# Coracle example

Example smart contract for simplified battleship game.

## Game rules

* Each player has its own board
* Each player places its own coracle on the board
* Each turn player tries to guess the opponent's coracle position
* If the opponent position is guessed the game opponent's only option is to admit defeat
* The winner can withdraw the prize

### Players board

|   |   |   |
|---|---|---|
| 1 | 2 | 3 |
| 4 | 5 | 6 |
| 7 | 8 | 9 |

## Quick start

Execute all actions from [Running tests](#running-tests)

## Tests

### Running tests

In terminal execute commands:

```sh
yarn                # Build the project
yarn compact         # Transpile the Compact program
yarn test           # Run tests
```

To limit actions just to those related to coracle example
add `--filter counter`:

```sh
turbo build --filter coracle
turbo test --filter coracle
```

### Overview

Tests are divided into three types:

* Predefined scenarios
* Model based tests
* Property based tests

### Tech stack

* Tests runner: [Jest](https://jestjs.io/)
* Model based tests library: [XState](https://xstate.js.org/)

### Predefined scenarios

All test scenarios can be simply predefined according to analysis of requirements.

### Model based tests

All property based tests are located [here](contract/src/test/coracle.model.based.test.ts)

To view the model in IDE please install the [VSCode plugin](https://marketplace.visualstudio.com/items?itemName=statelyai.stately-vscode)

Model based tests are suitable for verification of correctness of flows in the smart contract.
They are not designed to verify negative scenarios in application.

#### Test model

For the smart contract there's the [test model](contract/src/test/coracle.model.ts) defined

![Test model screenshot](contract/docs/images/testmodel.png)

#### Details

Model test can be started with initial context.
The context is used to setup specific preconditions for the test.
In our case the scenario configuration is held in:

```ts
export interface GameContext {
  scenario: string;             // scenario name, i.e. "Randomly generated" 
  roundNumber: number;          // player round number
  red_position: bigint;         // position of the red player's coracle
  blue_position: bigint;        // position of the blue player's coracle
  red_guess: bigint[];          // guessses of the red player 
  blue_guess: bigint[];         // guesses of the blue player
}
```

All guesses are prepared before test execution.
Each time test is executed, we can see the context being printed out in summary, so we are able to see all the steps (including guesses) that both players supposed to do.

All scenarios are executed through below code snippet.
For each of predefined game contexts located in [getGameContexts](contract/src/test/coracle.model.based.test.ts) new model is created and then all shortest paths to **game_ends** state are exercised.

```ts
describe('Model based tests', () => {
  const initialContexts = getContexts();
  initialContexts.forEach((initialContext: GameContext) => {
    const testModel = createTestModel(getTestMachine().withContext(initialContext));
    const testPlans = testModel.getShortestPathsTo((state) => state.value === 'game_ends');
    testPlans.forEach((testPath) => {
      it(testPath.description, async () => {
        ...
      }
    }
  }
});
```

All long taking actions should be handled by events. State is the moment where nothing changes.

### Troubleshooting

If tests fails and you see:

```text
thrown: "Exceeded timeout of 90000 ms for a test.
    Use jest.setTimeout(newTimeout) to increase the timeout value, if this is a long-running test."
```

consider changing number of parallel process used by Jest - in [jest.config.json](contract/jest.config.json) e.g.

```json
{
  "maxWorkers": "1"
}
```

or changing the test timeout itself.
