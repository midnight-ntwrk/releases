export type ValuesOf<T> = T[keyof T];

export const block = <T>(thunk: () => T): T => thunk();
