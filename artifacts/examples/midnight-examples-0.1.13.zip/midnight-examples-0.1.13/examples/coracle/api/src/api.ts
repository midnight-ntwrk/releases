import { either } from 'fp-ts';
import * as t from 'io-ts';
import type { Observable } from 'rxjs';

import { ValuesOf, block } from './helpers.js';

export const PlayerSides = {
  blue: 'blue',
  red: 'red',
} as const;
export const PlayerSideCodec = t.union([t.literal(PlayerSides.blue), t.literal(PlayerSides.red)]);
export type PlayerSide = t.TypeOf<typeof PlayerSideCodec>;

export const AsyncActionStates = {
  inProgress: 'in_progress',
  error: 'error',
  success: 'success',
} as const;
export type AsyncActionState = ValuesOf<typeof AsyncActionStates>;

export const Actions = {
  start: 'start',
  guess: 'guess',
  concede: 'concede',
  withdraw: 'withdraw',
} as const;
export const ActionCodec = t.union([
  t.literal(Actions.start),
  t.literal(Actions.guess),
  t.literal(Actions.concede),
  t.literal(Actions.withdraw),
]);
export type Action = t.TypeOf<typeof ActionCodec>;

export const ActionIdCodec = t.string;
export type ActionId = t.TypeOf<typeof ActionIdCodec>;

export const DateCodec = t.string.pipe(
  block(() => {
    const validate: t.Validate<string, Date> = (str, context) => {
      const candidate = new Date(str);
      if (candidate.toString() === 'Invalid Date') {
        return either.left([
          {
            value: str,
            context,
            message: `Could not parse ${str} to a Date object`,
          },
        ]);
      } else {
        return either.right(candidate);
      }
    };

    return new t.Type<Date, string, string>(
      'date',
      (value): value is Date => value instanceof Date,
      validate,
      (date) => date.toISOString(),
    );
  }),
);

const AsyncActionCommons = t.type({
  id: ActionIdCodec,
  action: ActionCodec,
  startedAt: DateCodec,
});

export const AsyncActionCodec = t.intersection([
  AsyncActionCommons,
  t.union([
    t.type({
      status: t.literal(AsyncActionStates.inProgress),
    }),
    t.type({
      status: t.literal(AsyncActionStates.error),
      error: t.string,
    }),
    t.type({
      status: t.literal(AsyncActionStates.success),
    }),
  ]),
]);
export type AsyncAction = t.TypeOf<typeof AsyncActionCodec>;
export const successfulAsyncAction = (action: AsyncAction): AsyncAction => ({
  ...action,
  status: 'success',
});
export const failedAsyncAction =
  (error: string) =>
  (action: AsyncAction): AsyncAction => ({
    ...action,
    status: 'error',
    error,
  });

export const CellPositions = {
  1: 1n,
  2: 2n,
  3: 3n,
  4: 4n,
  5: 5n,
  6: 6n,
  7: 7n,
  8: 8n,
  9: 9n,
} as const;
export const CellPositionCodec = t.keyof(CellPositions);
export type CellPositionNumbers = t.TypeOf<typeof CellPositionCodec>;
export type CellPosition = ValuesOf<typeof CellPositions>;

export const GameStates = {
  initial: 'initial',
  redStarted: 'red_started',
  blueStarted: 'blue_started',
  redTurn: 'red_turn',
  blueTurn: 'blue_turn',
  redWins: 'red_wins',
  blueWins: 'blue_wins',
} as const;
export const GameStateCodec = t.union([
  t.literal(GameStates.initial),
  t.literal(GameStates.redStarted),
  t.literal(GameStates.blueStarted),
  t.literal(GameStates.redTurn),
  t.literal(GameStates.blueTurn),
  t.literal(GameStates.redWins),
  t.literal(GameStates.blueWins),
]);
export type GameState = t.TypeOf<typeof GameStateCodec>;

export const States = {
  setup: 'setup',
  gameStarted: 'game_started',
  spectator: 'spectator',
} as const;

export const CommonStateCodec = t.type({
  actions: t.type({
    latest: t.union([ActionIdCodec, t.null]),
    all: t.record(ActionIdCodec, AsyncActionCodec),
  }),
});

export const CoracleStateCodec = t.intersection([
  CommonStateCodec,
  t.union([
    t.type({
      state: t.literal(States.setup),
    }),
    t.type({
      state: t.literal(States.spectator),
    }),
    t.type({
      state: t.literal(States.gameStarted),
      gameState: GameStateCodec,
      playerPosition: CellPositionCodec,
      playerSide: PlayerSideCodec,
      lastGuess: t.union([t.null, CellPositionCodec]),
      isPlayerTurn: t.boolean,
      playerWon: t.union([t.null, t.boolean]),
    }),
  ]),
]);
export type CoracleState = t.TypeOf<typeof CoracleStateCodec>;

export const CoracleConfigCodec = t.type({
  deposit: t.number,
  wager: t.number,
});
export type CoracleConfig = t.TypeOf<typeof CoracleConfigCodec>;

export interface CoracleAPI {
  config: CoracleConfig;
  state$: Observable<CoracleState>;
  start: (cellPosition: CellPosition) => Promise<ActionId>;
  guess: (cellPosition: CellPosition) => Promise<ActionId>;
  concede: () => Promise<ActionId>;
  withdraw: () => Promise<ActionId>;
}
