import { CoraclePrivateState, Ledger, pureCircuits, State } from '@midnight-ntwrk/coracle-contract';
import { CellPositionNumbers, CoracleState, GameStates, PlayerSides, States } from '@midnight-ntwrk/coracle-api';
import { EphemeralState } from './ephemeral-state-bloc.js';

const isBlue = (ledgerState: Ledger, privateState: CoraclePrivateState): boolean =>
  pureCircuits.is_blue(privateState.secretKey, ledgerState.blue);

const isRed = (ledgerState: Ledger, privateState: CoraclePrivateState): boolean =>
  pureCircuits.is_red(privateState.secretKey, ledgerState.red);

const isPlayerAlive = (ledgerState: Ledger, privateState: CoraclePrivateState): boolean =>
  pureCircuits.is_player_alive(privateState.board, ledgerState.guess.value);

const toCellPosition = (position: bigint): CellPositionNumbers => {
  if (1 <= position && position <= 9) {
    return position as unknown as CellPositionNumbers;
  }
  throw new Error(`bug found: unexpected board position ${position}`);
};

const playerWon = (ledgerState: Ledger, privateState: CoraclePrivateState): false | null => {
  let won = null;
  if (ledgerState.guess.is_some) {
    if (!isPlayerAlive(ledgerState, privateState)) {
      won = false as const;
    }
  }
  return won;
};

export const deriveCoracleState = (
  ledgerState: Ledger,
  privateState: CoraclePrivateState,
  ephemeralState: EphemeralState,
): CoracleState => {
  const actions = ephemeralState.actions;
  const playerIsRed = isRed(ledgerState, privateState);
  const playerIsBlue = isBlue(ledgerState, privateState);
  if (ledgerState.state == State.no_game) {
    return { actions, state: States.setup };
  } else if (!playerIsRed && !playerIsBlue) {
    return { actions, state: States.spectator };
  } else {
    const state = States.gameStarted;
    const playerPosition = toCellPosition(privateState.board.contents.position);
    const playerSide = playerIsRed ? PlayerSides.red : PlayerSides.blue;
    switch (ledgerState.state) {
      case State.red_started:
        return {
          actions,
          state,
          gameState: GameStates.redStarted,
          playerPosition,
          playerSide,
          lastGuess: null,
          isPlayerTurn: !playerIsRed,
          playerWon: null,
        };
      case State.blue_started:
        return {
          actions,
          state,
          gameState: GameStates.blueStarted,
          playerPosition,
          playerSide,
          lastGuess: null,
          isPlayerTurn: playerIsBlue,
          playerWon: null,
        };
      case State.blue_turn:
        return {
          actions,
          state,
          gameState: GameStates.blueTurn,
          playerPosition,
          playerSide,
          lastGuess: ledgerState.guess.is_some ? toCellPosition(ledgerState.guess.value) : null,
          isPlayerTurn: playerIsBlue,
          playerWon: playerWon(ledgerState, privateState),
        };
      case State.red_turn:
        return {
          actions,
          state,
          gameState: GameStates.redTurn,
          playerPosition,
          playerSide,
          lastGuess: toCellPosition(ledgerState.guess.value),
          isPlayerTurn: playerIsRed,
          playerWon: playerWon(ledgerState, privateState),
        };
      case State.red_wins:
        return {
          actions,
          state,
          gameState: GameStates.redWins,
          playerPosition,
          lastGuess: toCellPosition(ledgerState.guess.value),
          playerSide,
          isPlayerTurn: playerIsRed,
          playerWon: playerIsRed,
        };
      case State.blue_wins:
        return {
          actions,
          state,
          gameState: GameStates.blueWins,
          playerPosition,
          lastGuess: toCellPosition(ledgerState.guess.value),
          playerSide,
          isPlayerTurn: playerIsBlue,
          playerWon: playerIsBlue,
        };
      default:
        throw new Error('bug found: unexpected state case');
    }
  }
};
