import { MidnightProviders } from '@midnight-ntwrk/midnight-js-types';
import { Cryptography } from './cryptography.js';
import { Logger } from 'pino';
import { Witnesses, CoraclePrivateState, Contract } from '@midnight-ntwrk/coracle-contract';
import { SubscribablePrivateStateProvider } from './private-state-decorator.js';
import { DeployedContract, StateWithZswap, SubmittedCallTx } from '@midnight-ntwrk/midnight-js-contracts';
import { EphemeralStateBloc } from './ephemeral-state-bloc.js';

export type PrivateStates = {
  coraclePrivateState: CoraclePrivateState;
};

export type CoracleContract = Contract<StateWithZswap<CoraclePrivateState>, Witnesses<StateWithZswap<CoraclePrivateState>>>;

export type CoracleCircuitKeys = Exclude<keyof CoracleContract['impureCircuits'], number | symbol>;

export type CoracleProviders = MidnightProviders<CoracleCircuitKeys, PrivateStates> & {
  privateStateProvider: SubscribablePrivateStateProvider<PrivateStates>;
};

export type AppProviders = {
  crypto: Cryptography;
  logger: Logger;
  ephemeralStateBloc: EphemeralStateBloc;
};

export type DeployedCoracleContract = DeployedContract<PrivateStates, 'coraclePrivateState', CoracleContract>;

export type SubmittedCoracleCallTx = SubmittedCallTx<PrivateStates, 'coraclePrivateState', CoracleContract, CoracleCircuitKeys>;
