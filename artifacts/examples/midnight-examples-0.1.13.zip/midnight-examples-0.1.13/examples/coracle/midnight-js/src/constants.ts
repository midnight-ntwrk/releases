import { CoracleConfig } from '@midnight-ntwrk/coracle-api';

export const DEFAULT_CORACLE_CONFIG: CoracleConfig = {
  wager: 100,
  deposit: 500_000,
};
