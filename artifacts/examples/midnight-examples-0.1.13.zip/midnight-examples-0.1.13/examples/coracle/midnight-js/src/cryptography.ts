export type Cryptography = {
  randomBytes: (length: number) => Uint8Array;
  randomBigUint: () => bigint;
  randomSk: () => Uint8Array;
  randomUUID: () => string;
};

export const DEFAULT_SK_LENGTH = 32;

export const webCryptoCryptography = (crypto: Crypto): Cryptography => {
  const randomBytes = (length: number): Uint8Array => {
    const out = new Uint8Array(length);
    crypto.getRandomValues(out);
    return out;
  };

  return {
    randomBytes,
    randomBigUint: () => BigInt(crypto.getRandomValues(new BigUint64Array(1))[0]),
    randomSk: (): Uint8Array => randomBytes(DEFAULT_SK_LENGTH),
    randomUUID: () => crypto.randomUUID(),
  };
};
