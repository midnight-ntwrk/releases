import { AsyncAction, ActionId, CoracleState, failedAsyncAction, successfulAsyncAction } from '@midnight-ntwrk/coracle-api';
import { Bloc, Resource } from '@midnight-ntwrk/coracle-helpers';
import { Logger } from 'pino';

/**
 * Ephemeral state of coracle - manages async actions and their statuses
 * It does not need to be persisted at all, but it is an important
 * piece of data mostly in terms of knowing if there is some local action in-progress
 */
export type EphemeralState = { actions: CoracleState['actions'] };

const emptyEphemeralState: EphemeralState = {
  actions: {
    latest: null,
    all: {},
  },
};

const addAction =
  (action: AsyncAction) =>
  (state: EphemeralState): EphemeralState => ({
    actions: {
      latest: action.id,
      all: {
        ...state.actions.all,
        [action.id]: action,
      },
    },
  });

const updateAction =
  (actionId: ActionId, updater: (action: AsyncAction) => AsyncAction) =>
  (state: EphemeralState): EphemeralState => {
    return {
      actions: {
        ...state.actions,
        all: {
          ...state.actions.all,
          [actionId]: updater(state.actions.all[actionId]),
        },
      },
    };
  };

const succeedAction = (id: ActionId) => updateAction(id, successfulAsyncAction);

const failAction = (id: ActionId, error: string) => updateAction(id, failedAsyncAction(error));

export class EphemeralStateBloc extends Bloc<EphemeralState> {
  static init(logger: Logger): Resource<EphemeralStateBloc> {
    return Bloc.asResource(() => new EphemeralStateBloc(emptyEphemeralState, logger));
  }

  constructor(initialState: EphemeralState, logger: Logger) {
    super(initialState, logger);
  }

  addAction(action: AsyncAction) {
    return this.updateState(addAction(action));
  }

  succeedAction(id: ActionId) {
    return this.updateState(succeedAction(id));
  }

  failAction(id: ActionId, error: string) {
    return this.updateState(failAction(id, error));
  }
}
