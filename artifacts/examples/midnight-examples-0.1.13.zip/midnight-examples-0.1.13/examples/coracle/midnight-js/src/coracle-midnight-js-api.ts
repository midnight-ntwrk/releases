import {
  AppProviders,
  CoracleCircuitKeys,
  CoracleContract,
  CoracleProviders,
  DeployedCoracleContract,
  PrivateStates,
  SubmittedCoracleCallTx,
} from './common-types.js';
import { deployContract, findDeployedContract, StateWithZswap, withZswapWitnesses } from '@midnight-ntwrk/midnight-js-contracts';
import {
  Contract,
  CoraclePrivateState,
  createCoraclePrivateState,
  ledger,
  Witnesses,
  witnesses,
} from '@midnight-ntwrk/coracle-contract';
import { ContractAddress, ContractState, encodeCoinInfo, encodeCoinPublicKey } from '@midnight-ntwrk/compact-runtime';
import { Cryptography } from './cryptography.js';
import { WalletProvider } from '@midnight-ntwrk/midnight-js-types';
import { Action, ActionId, CellPosition, CoracleAPI, CoracleConfig, CoracleState } from '@midnight-ntwrk/coracle-api';
import * as Rx from 'rxjs';
import { toHex } from './utils.js';
import { deriveCoracleState } from './derive-coracle-state.js';
import { createCoinInfo, nativeToken } from '@midnight-ntwrk/ledger';

export const createCoracleContract =
  (crypto: Cryptography) =>
  (walletProvider: WalletProvider): CoracleContract =>
    new Contract(withZswapWitnesses(witnesses(crypto.randomBigUint))(encodeCoinPublicKey(walletProvider.coinPublicKey)));

export const coraclePrivateStateFromCrypto = (crypto: Cryptography): CoraclePrivateState =>
  createCoraclePrivateState(crypto.randomBigUint)(crypto.randomSk());

export const getCoraclePrivateState = (providers: CoracleProviders): Promise<CoraclePrivateState | null> =>
  providers.privateStateProvider.get('coraclePrivateState');

export const contractStatesEqual = (a: ContractState, b: ContractState) => {
  if (!a && !b) {
    return true;
  } else if (a && b) {
    return toHex(a.serialize()) === toHex(b.serialize());
  } else {
    return false;
  }
};

export class CoracleMidnightJSAPI implements CoracleAPI {
  static async deploy(
    config: CoracleConfig,
    providers: CoracleProviders,
    appProviders: AppProviders,
  ): Promise<CoracleMidnightJSAPI> {
    // TODO: MN.js should infer these type parameters, not require them to be passed explicitly.
    const deployedContract = await deployContract<
      PrivateStates,
      'coraclePrivateState',
      Witnesses<StateWithZswap<CoraclePrivateState>>,
      CoracleContract,
      CoracleCircuitKeys
    >(
      providers,
      'coraclePrivateState',
      coraclePrivateStateFromCrypto(appProviders.crypto),
      createCoracleContract(appProviders.crypto)(providers.walletProvider),
    );
    return new CoracleMidnightJSAPI(config, deployedContract, providers, appProviders);
  }

  static async join(
    config: CoracleConfig,
    providers: CoracleProviders,
    appProviders: AppProviders,
    contractAddress: ContractAddress,
  ): Promise<CoracleMidnightJSAPI> {
    const existingPrivateState = await getCoraclePrivateState(providers);
    // TODO: MN.js should infer these type parameters, not require them to be passed explicitly.
    const deployedContract = await findDeployedContract<
      PrivateStates,
      'coraclePrivateState',
      Witnesses<StateWithZswap<CoraclePrivateState>>,
      CoracleContract,
      CoracleCircuitKeys
    >(providers, contractAddress, createCoracleContract(appProviders.crypto)(providers.walletProvider), {
      privateStateKey: 'coraclePrivateState',
      initialPrivateState: existingPrivateState ?? coraclePrivateStateFromCrypto(appProviders.crypto),
    });
    return new CoracleMidnightJSAPI(config, deployedContract, providers, appProviders);
  }

  readonly contractAddress: ContractAddress;
  readonly state$: Rx.Observable<CoracleState>;
  constructor(
    public readonly config: CoracleConfig,
    private readonly deployedContract: DeployedCoracleContract,
    private readonly providers: CoracleProviders,
    private readonly appProviders: AppProviders,
  ) {
    this.config = config;
    this.contractAddress = deployedContract.finalizedDeployTxData.contractAddress;
    this.state$ = Rx.combineLatest([
      this.providers.publicDataProvider.contractStateObservable(this.contractAddress, { type: 'latest' }).pipe(
        Rx.distinctUntilChanged(contractStatesEqual),
        Rx.map((contractState) => ledger(contractState.data)),
      ),
      this.providers.privateStateProvider
        .state$('coraclePrivateState')
        .pipe(Rx.filter((privateState): privateState is CoraclePrivateState => privateState !== null)),
      this.appProviders.ephemeralStateBloc.state$,
    ]).pipe(
      Rx.map(([contractState, privateState, ephemeralState]) => deriveCoracleState(contractState, privateState, ephemeralState)),
      Rx.shareReplay({
        bufferSize: 1,
        refCount: true,
      }),
    );
  }

  start(startPosition: CellPosition): Promise<ActionId> {
    return this.buildAndSubmitCallTx('start', () =>
      this.deployedContract.contractCircuitsInterface.start(
        startPosition,
        this.coinInfo(this.config.wager),
        this.coinInfo(this.config.deposit),
      ),
    );
  }

  guess(position: CellPosition): Promise<ActionId> {
    return this.buildAndSubmitCallTx('guess', () => this.deployedContract.contractCircuitsInterface.guess(position));
  }

  concede(): Promise<ActionId> {
    return this.buildAndSubmitCallTx('concede', () => this.deployedContract.contractCircuitsInterface.concede());
  }

  withdraw(): Promise<ActionId> {
    return this.buildAndSubmitCallTx('withdraw', () => this.deployedContract.contractCircuitsInterface.withdraw());
  }

  private coinInfo(value: number) {
    return encodeCoinInfo(createCoinInfo(nativeToken(), BigInt(value)));
  }

  private buildAndSubmitCallTx(action: Action, submitTx: () => Promise<SubmittedCoracleCallTx>): Promise<ActionId> {
    const actionId = this.appProviders.crypto.randomUUID();
    void Rx.firstValueFrom(
      this.appProviders.ephemeralStateBloc
        .addAction({
          action,
          status: 'in_progress' as const,
          startedAt: new Date(),
          id: actionId,
        })
        .pipe(
          Rx.concatMap(() => submitTx()),
          Rx.concatMap(() => this.appProviders.ephemeralStateBloc.succeedAction(actionId)),
          Rx.catchError((err: Error) => this.appProviders.ephemeralStateBloc.failAction(actionId, err.message)),
        ),
    );
    return Promise.resolve(actionId);
  }
}
