import * as process from 'process';
import dotenv from 'dotenv';

dotenv.config();

export class Services {
  static readonly CORACLE_URL: string | undefined = process.env.CORACLE_URL;
  static readonly JIRA_URL: string | undefined = process.env.JIRA_URL;
}
