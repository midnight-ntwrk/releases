import type { Locator, Page } from '@playwright/test';

export class CommonBoardPage {
  readonly page: Page;

  readonly playerBoard: Locator;
  readonly playerBoardTitle: Locator;
  readonly opponentBoard: Locator;
  readonly opponentBoardTitle: Locator;
  readonly shootButton: Locator;

  readonly playerBoardCellOne: Locator;
  readonly playerBoardCellTwo: Locator;
  readonly playerBoardCellThree: Locator;
  readonly playerBoardCellFour: Locator;
  readonly playerBoardCellFive: Locator;
  readonly playerBoardCellSix: Locator;
  readonly playerBoardCellSeven: Locator;
  readonly playerBoardCellEight: Locator;
  readonly playerBoardCellNine: Locator;

  readonly playerBoardCellOneWithShip: Locator;
  readonly playerBoardCellTwoWithShip: Locator;
  readonly playerBoardCellThreeWithShip: Locator;
  readonly playerBoardCellFourWithShip: Locator;
  readonly playerBoardCellFiveWithShip: Locator;
  readonly playerBoardCellSixWithShip: Locator;
  readonly playerBoardCellSevenWithShip: Locator;
  readonly playerBoardCellEightWithShip: Locator;
  readonly playerBoardCellNineWithShip: Locator;

  readonly opponentBoardCellOne: Locator;
  readonly opponentBoardCellTwo: Locator;
  readonly opponentBoardCellThree: Locator;
  readonly opponentBoardCellFour: Locator;
  readonly opponentBoardCellFive: Locator;
  readonly opponentBoardCellSix: Locator;
  readonly opponentBoardCellSeven: Locator;
  readonly opponentBoardCellEight: Locator;
  readonly opponentBoardCellNine: Locator;

  readonly opponentBoardCellOneWithImage: Locator;
  readonly opponentBoardCellTwoWithImage: Locator;
  readonly opponentBoardCellThreeWithImage: Locator;
  readonly opponentBoardCellFourWithImage: Locator;
  readonly opponentBoardCellFiveWithImage: Locator;
  readonly opponentBoardCellSixWithImage: Locator;
  readonly opponentBoardCellSevenWithImage: Locator;
  readonly opponentBoardCellEightWithImage: Locator;
  readonly opponentBoardCellNineWithImage: Locator;

  readonly opponentBoardCellOneWithCrosshair: Locator;
  readonly opponentBoardCellTwoWithCrosshair: Locator;
  readonly opponentBoardCellThreeWithCrosshair: Locator;
  readonly opponentBoardCellFourWithCrosshair: Locator;
  readonly opponentBoardCellFiveWithCrosshair: Locator;
  readonly opponentBoardCellSixWithCrosshair: Locator;
  readonly opponentBoardCellSevenWithCrosshair: Locator;
  readonly opponentBoardCellEightWithCrosshair: Locator;
  readonly opponentBoardCellNineWithCrosshair: Locator;

  readonly opponentBoardCellOneWithCross: Locator;
  readonly opponentBoardCellTwoWithCross: Locator;
  readonly opponentBoardCellThreeWithCross: Locator;
  readonly opponentBoardCellFourWithCross: Locator;
  readonly opponentBoardCellFiveWithCross: Locator;
  readonly opponentBoardCellSixWithCross: Locator;
  readonly opponentBoardCellSevenWithCross: Locator;
  readonly opponentBoardCellEightWithCross: Locator;
  readonly opponentBoardCellNineWithCross: Locator;

  constructor(page: Page) {
    this.page = page;

    this.playerBoard = page.locator('[data-test-id="player-board"]');
    this.playerBoardTitle = page.locator('[data-test-id="player-board"] p');
    this.opponentBoard = page.locator('[data-test-id="opponent-board"]');
    this.opponentBoardTitle = page.locator('[data-test-id="opponent-board"] p');
    this.shootButton = page.locator('[data-test-id="shoot-button"]');

    this.playerBoardCellOne = page.locator('[data-test-id="player-board-cell-0"]');
    this.playerBoardCellTwo = page.locator('[data-test-id="player-board-cell-1"]');
    this.playerBoardCellThree = page.locator('[data-test-id="player-board-cell-2"]');
    this.playerBoardCellFour = page.locator('[data-test-id="player-board-cell-3"]');
    this.playerBoardCellFive = page.locator('[data-test-id="player-board-cell-4"]');
    this.playerBoardCellSix = page.locator('[data-test-id="player-board-cell-5"]');
    this.playerBoardCellSeven = page.locator('[data-test-id="player-board-cell-6"]');
    this.playerBoardCellEight = page.locator('[data-test-id="player-board-cell-7"]');
    this.playerBoardCellNine = page.locator('[data-test-id="player-board-cell-8"]');

    this.playerBoardCellOneWithShip = page.locator('[data-test-id="player-board-cell-0"] img[src="/battleship.png"]');
    this.playerBoardCellTwoWithShip = page.locator('[data-test-id="player-board-cell-1"] img[src="/battleship.png"]');
    this.playerBoardCellThreeWithShip = page.locator('[data-test-id="player-board-cell-2"] img[src="/battleship.png"]');
    this.playerBoardCellFourWithShip = page.locator('[data-test-id="player-board-cell-3"] img[src="/battleship.png"]');
    this.playerBoardCellFiveWithShip = page.locator('[data-test-id="player-board-cell-4"] img[src="/battleship.png"]');
    this.playerBoardCellSixWithShip = page.locator('[data-test-id="player-board-cell-5"] img[src="/battleship.png"]');
    this.playerBoardCellSevenWithShip = page.locator('[data-test-id="player-board-cell-6"] img[src="/battleship.png"]');
    this.playerBoardCellEightWithShip = page.locator('[data-test-id="player-board-cell-7"] img[src="/battleship.png"]');
    this.playerBoardCellNineWithShip = page.locator('[data-test-id="player-board-cell-8"] img[src="/battleship.png"]');

    this.opponentBoardCellOne = page.locator('[data-test-id="opponent-board-cell-0"]');
    this.opponentBoardCellTwo = page.locator('[data-test-id="opponent-board-cell-1"]');
    this.opponentBoardCellThree = page.locator('[data-test-id="opponent-board-cell-2"]');
    this.opponentBoardCellFour = page.locator('[data-test-id="opponent-board-cell-3"]');
    this.opponentBoardCellFive = page.locator('[data-test-id="opponent-board-cell-4"]');
    this.opponentBoardCellSix = page.locator('[data-test-id="opponent-board-cell-5"]');
    this.opponentBoardCellSeven = page.locator('[data-test-id="opponent-board-cell-6"]');
    this.opponentBoardCellEight = page.locator('[data-test-id="opponent-board-cell-7"]');
    this.opponentBoardCellNine = page.locator('[data-test-id="opponent-board-cell-8"]');

    this.opponentBoardCellOneWithImage = page.locator('[data-test-id="opponent-board-cell-0"] img');
    this.opponentBoardCellTwoWithImage = page.locator('[data-test-id="opponent-board-cell-1"] img');
    this.opponentBoardCellThreeWithImage = page.locator('[data-test-id="opponent-board-cell-2"] img');
    this.opponentBoardCellFourWithImage = page.locator('[data-test-id="opponent-board-cell-3"] img');
    this.opponentBoardCellFiveWithImage = page.locator('[data-test-id="opponent-board-cell-4"] img');
    this.opponentBoardCellSixWithImage = page.locator('[data-test-id="opponent-board-cell-5"] img');
    this.opponentBoardCellSevenWithImage = page.locator('[data-test-id="opponent-board-cell-6"] img');
    this.opponentBoardCellEightWithImage = page.locator('[data-test-id="opponent-board-cell-7"] img');
    this.opponentBoardCellNineWithImage = page.locator('[data-test-id="opponent-board-cell-8"] img');

    this.opponentBoardCellOneWithCrosshair = page.locator('[data-test-id="opponent-board-cell-0"] img[src="/crosshair.png"]');
    this.opponentBoardCellTwoWithCrosshair = page.locator('[data-test-id="opponent-board-cell-1"] img[src="/crosshair.png"]');
    this.opponentBoardCellThreeWithCrosshair = page.locator('[data-test-id="opponent-board-cell-2"] img[src="/crosshair.png"]');
    this.opponentBoardCellFourWithCrosshair = page.locator('[data-test-id="opponent-board-cell-3"] img[src="/crosshair.png"]');
    this.opponentBoardCellFiveWithCrosshair = page.locator('[data-test-id="opponent-board-cell-4"] img[src="/crosshair.png"]');
    this.opponentBoardCellSixWithCrosshair = page.locator('[data-test-id="opponent-board-cell-5"] img[src="/crosshair.png"]');
    this.opponentBoardCellSevenWithCrosshair = page.locator('[data-test-id="opponent-board-cell-6"] img[src="/crosshair.png"]');
    this.opponentBoardCellEightWithCrosshair = page.locator('[data-test-id="opponent-board-cell-7"] img[src="/crosshair.png"]');
    this.opponentBoardCellNineWithCrosshair = page.locator('[data-test-id="opponent-board-cell-8"] img[src="/crosshair.png"]');

    this.opponentBoardCellOneWithCross = page.locator('[data-test-id="opponent-board-cell-0"] img[src="/cross.png"]');
    this.opponentBoardCellTwoWithCross = page.locator('[data-test-id="opponent-board-cell-1"] img[src="/cross.png"]');
    this.opponentBoardCellThreeWithCross = page.locator('[data-test-id="opponent-board-cell-2"] img[src="/cross.png"]');
    this.opponentBoardCellFourWithCross = page.locator('[data-test-id="opponent-board-cell-3"] img[src="/cross.png"]');
    this.opponentBoardCellFiveWithCross = page.locator('[data-test-id="opponent-board-cell-4"] img[src="/cross.png"]');
    this.opponentBoardCellSixWithCross = page.locator('[data-test-id="opponent-board-cell-5"] img[src="/cross.png"]');
    this.opponentBoardCellSevenWithCross = page.locator('[data-test-id="opponent-board-cell-6"] img[src="/cross.png"]');
    this.opponentBoardCellEightWithCross = page.locator('[data-test-id="opponent-board-cell-7"] img[src="/cross.png"]');
    this.opponentBoardCellNineWithCross = page.locator('[data-test-id="opponent-board-cell-8"] img[src="/cross.png"]');
  }
}
