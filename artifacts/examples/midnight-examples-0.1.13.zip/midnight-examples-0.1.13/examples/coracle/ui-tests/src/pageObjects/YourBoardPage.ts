import type { Locator, Page } from '@playwright/test';

export class YourBoardPage {
  readonly page: Page;

  readonly pickBoard: Locator;
  readonly pickPositionTitle: Locator;
  readonly readyButton: Locator;

  readonly cellOne: Locator;
  readonly cellTwo: Locator;
  readonly cellThree: Locator;
  readonly cellFour: Locator;
  readonly cellFive: Locator;
  readonly cellSix: Locator;
  readonly cellSeven: Locator;
  readonly cellEight: Locator;
  readonly cellNine: Locator;

  readonly cellOneWithShip: Locator;
  readonly cellTwoWithShip: Locator;
  readonly cellThreeWithShip: Locator;
  readonly cellFourWithShip: Locator;
  readonly cellFiveWithShip: Locator;
  readonly cellSixWithShip: Locator;
  readonly cellSevenWithShip: Locator;
  readonly cellEightWithShip: Locator;
  readonly cellNineWithShip: Locator;

  constructor(page: Page) {
    this.page = page;

    this.pickBoard = page.locator('[data-test-id="pick-board"]');
    this.pickPositionTitle = page.locator('[data-test-id="pick-board"] p');
    this.readyButton = page.locator('[data-test-id="position-pick-button"]');

    this.cellOne = page.locator('[data-test-id="pick-board-cell-0"]');
    this.cellTwo = page.locator('[data-test-id="pick-board-cell-1"]');
    this.cellThree = page.locator('[data-test-id="pick-board-cell-2"]');
    this.cellFour = page.locator('[data-test-id="pick-board-cell-3"]');
    this.cellFive = page.locator('[data-test-id="pick-board-cell-4"]');
    this.cellSix = page.locator('[data-test-id="pick-board-cell-5"]');
    this.cellSeven = page.locator('[data-test-id="pick-board-cell-6"]');
    this.cellEight = page.locator('[data-test-id="pick-board-cell-7"]');
    this.cellNine = page.locator('[data-test-id="pick-board-cell-8"]');

    this.cellOneWithShip = page.locator('[data-test-id="pick-board-cell-0"] img[src="/battleship.png"]');
    this.cellTwoWithShip = page.locator('[data-test-id="pick-board-cell-1"] img[src="/battleship.png"]');
    this.cellThreeWithShip = page.locator('[data-test-id="pick-board-cell-2"] img[src="/battleship.png"]');
    this.cellFourWithShip = page.locator('[data-test-id="pick-board-cell-3"] img[src="/battleship.png"]');
    this.cellFiveWithShip = page.locator('[data-test-id="pick-board-cell-4"] img[src="/battleship.png"]');
    this.cellSixWithShip = page.locator('[data-test-id="pick-board-cell-5"] img[src="/battleship.png"]');
    this.cellSevenWithShip = page.locator('[data-test-id="pick-board-cell-6"] img[src="/battleship.png"]');
    this.cellEightWithShip = page.locator('[data-test-id="pick-board-cell-7"] img[src="/battleship.png"]');
    this.cellNineWithShip = page.locator('[data-test-id="pick-board-cell-8"] img[src="/battleship.png"]');
  }
}
