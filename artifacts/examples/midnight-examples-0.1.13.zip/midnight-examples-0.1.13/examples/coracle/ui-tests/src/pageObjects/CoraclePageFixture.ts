/* eslint-disable  @typescript-eslint/no-unsafe-argument */
/* eslint-disable  @typescript-eslint/no-unsafe-call */
import { test as baseTest } from '@playwright/test';
import { InitialPage } from './InitialPage.js';
import { YourBoardPage } from './YourBoardPage.js';
import { CommonBoardPage } from './CommonBoardPage.js';

const test = baseTest.extend<{
  initialPage: InitialPage;
  yourBoardPage: YourBoardPage;
  commonBoardPage: CommonBoardPage;
}>({
  initialPage: async ({ page }: any, use: any) => {
    await use(new InitialPage(page));
  },
  yourBoardPage: async ({ page }: any, use: any) => {
    await use(new YourBoardPage(page));
  },
  commonBoardPage: async ({ page }: any, use: any) => {
    await use(new CommonBoardPage(page));
  },
});

export default test;
export const expect = test.expect;
// eslint-disable-next-line @typescript-eslint/unbound-method
export const beforeAll = test.beforeAll;
