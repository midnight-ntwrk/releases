export class CoracleConstants {
  static readonly GAME_ADDRESS_TITLE = 'Your game address is: ';
  static readonly PICK_POSITION_TITLE = 'Pick position!';
  static readonly YOUR_BOARD_TITLE = 'Your board';
  static readonly OPPONENT_BOARD_TITLE = "Opponent's board";
}
