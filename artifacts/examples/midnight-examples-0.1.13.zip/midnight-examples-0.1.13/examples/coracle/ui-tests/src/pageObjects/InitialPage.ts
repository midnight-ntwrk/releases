import type { Locator, Page, Response } from '@playwright/test';
import { Services } from '../setup/Services';

export class InitialPage {
  readonly page: Page;
  readonly url: string;
  //readonly spinner: Locator;
  readonly createNewGameButton: Locator;
  readonly gameAddress: Locator;
  readonly copyAddressButton: Locator;

  constructor(page: Page) {
    this.page = page;
    if (Services.CORACLE_URL === undefined) {
      throw new Error('Undefined env variable - CORACLE_URL');
    } else {
      this.url = Services.CORACLE_URL;
    }
    //this.spinner = page.locator('[data-testid="backdrop-loader-spinner"]');
    this.createNewGameButton = page.locator('[data-test-id="create-game-button"]');
    this.gameAddress = page.locator('h3');
    this.copyAddressButton = page.locator('[data-testid="ContentCopyIcon"]');
  }

  async goto(path?: string): Promise<null | Response> {
    if (typeof path !== 'undefined') {
      return await this.page.goto(`${this.url}${path}`);
    }
    return await this.page.goto(`${this.url}`);
  }

  async getGameAddress() {
    return (await this.gameAddress.textContent())!.split(':')[1].trim();
  }
}
