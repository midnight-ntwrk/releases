import type { PlaywrightTestConfig } from '@playwright/test';

const timestamp = new Date().valueOf();

const config: PlaywrightTestConfig = {
  expect: { timeout: 20000 },
  use: {
    headless: !!process.env.CI,
    viewport: { width: 1280, height: 720 },
    ignoreHTTPSErrors: true,
    video: 'on-first-retry',
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
    launchOptions: process.env.CI
      ? {
          headless: true,
        }
      : {
          slowMo: 800,
        },
  },
  testDir: './tests',
  testIgnore: ['*.js'],
  reporter: [
    ['list'],
    ['allure-playwright', { outputFolder: './reports/allureResults' }],
    ['junit', { outputFile: `./reports/testResults_${timestamp}.xml` }],
  ],
  workers: 1,
  outputDir: './reports/playwrightResults',
};

export default config;
