import { allure } from 'allure-playwright';
import test, { expect } from '../src/pageObjects/CoraclePageFixture';
import { Services } from '../src/setup/Services';
import { CoracleConstants } from '../src/setup/CoracleConstants';

test.describe('Coracle dApp. E2E flows.', () => {
  test.setTimeout(30000);

  test('Impossible to select already shoted cell @PM-7155', async ({ page, initialPage, yourBoardPage, commonBoardPage }) => {
    allure.tms('PM-7155', `${Services.JIRA_URL}/PM-7155`);
    allure.epic('Coracle dApp');
    allure.feature('UI');
    allure.story('User story: E2E test for the UI of coracle dapp');

    let gameAddress: string;

    const emptyCells = [
      yourBoardPage.cellOne,
      yourBoardPage.cellTwo,
      yourBoardPage.cellThree,
      yourBoardPage.cellFour,
      yourBoardPage.cellFive,
      yourBoardPage.cellSix,
      yourBoardPage.cellSeven,
      yourBoardPage.cellEight,
      yourBoardPage.cellNine,
    ];

    const cellsWithShip = [
      yourBoardPage.cellOneWithShip,
      yourBoardPage.cellTwoWithShip,
      yourBoardPage.cellThreeWithShip,
      yourBoardPage.cellFourWithShip,
      yourBoardPage.cellFiveWithShip,
      yourBoardPage.cellSixWithShip,
      yourBoardPage.cellSevenWithShip,
      yourBoardPage.cellEightWithShip,
      yourBoardPage.cellNineWithShip,
    ];

    const playerBoardCells = [
      commonBoardPage.playerBoardCellOne,
      commonBoardPage.playerBoardCellTwo,
      commonBoardPage.playerBoardCellThree,
      commonBoardPage.playerBoardCellFour,
      commonBoardPage.playerBoardCellFive,
      commonBoardPage.playerBoardCellSix,
      commonBoardPage.playerBoardCellSeven,
      commonBoardPage.playerBoardCellEight,
      commonBoardPage.playerBoardCellNine,
    ];

    const playerBoardCellsWithShip = [
      commonBoardPage.playerBoardCellOneWithShip,
      commonBoardPage.playerBoardCellTwoWithShip,
      commonBoardPage.playerBoardCellThreeWithShip,
      commonBoardPage.playerBoardCellFourWithShip,
      commonBoardPage.playerBoardCellFiveWithShip,
      commonBoardPage.playerBoardCellSixWithShip,
      commonBoardPage.playerBoardCellSevenWithShip,
      commonBoardPage.playerBoardCellEightWithShip,
      commonBoardPage.playerBoardCellNineWithShip,
    ];

    const opponentBoardCells = [
      commonBoardPage.opponentBoardCellOne,
      commonBoardPage.opponentBoardCellTwo,
      commonBoardPage.opponentBoardCellThree,
      commonBoardPage.opponentBoardCellFour,
      commonBoardPage.opponentBoardCellFive,
      commonBoardPage.opponentBoardCellSix,
      commonBoardPage.opponentBoardCellSeven,
      commonBoardPage.opponentBoardCellEight,
      commonBoardPage.opponentBoardCellNine,
    ];

    const opponentBoardCellsWithImage = [
      commonBoardPage.opponentBoardCellOneWithImage,
      commonBoardPage.opponentBoardCellTwoWithImage,
      commonBoardPage.opponentBoardCellThreeWithImage,
      commonBoardPage.opponentBoardCellFourWithImage,
      commonBoardPage.opponentBoardCellFiveWithImage,
      commonBoardPage.opponentBoardCellSixWithImage,
      commonBoardPage.opponentBoardCellSevenWithImage,
      commonBoardPage.opponentBoardCellEightWithImage,
      commonBoardPage.opponentBoardCellNineWithImage,
    ];

    await test.step('Create new game', async () => {
      await initialPage.goto();
      await expect(initialPage.createNewGameButton).toBeVisible();

      await initialPage.createNewGameButton.click();
      await expect(initialPage.copyAddressButton).toBeVisible();
      expect(await initialPage.gameAddress.textContent()).toContain(CoracleConstants.GAME_ADDRESS_TITLE);
      gameAddress = await initialPage.getGameAddress();
      await initialPage.gameAddress.click();
    });

    await test.step('Verify board`s initial state', async () => {
      await expect(yourBoardPage.pickBoard).toBeVisible();
      expect(page.url()).toContain(gameAddress);
      expect(await yourBoardPage.pickPositionTitle.textContent()).toContain(CoracleConstants.PICK_POSITION_TITLE);

      console.log('All cells are empty');
      for (let i = 0; i < emptyCells.length; i++) {
        await expect(emptyCells[i]).toBeVisible();
        await expect(emptyCells[i]).toHaveCSS('border', '3px solid rgb(0, 159, 183)');
      }

      for (let i = 0; i < cellsWithShip.length; i++) {
        await expect(cellsWithShip[i]).not.toBeVisible();
      }

      console.log('Ready button is disabled');
      await expect(yourBoardPage.readyButton).toBeDisabled();
    });

    await test.step('Place ship', async () => {
      await yourBoardPage.cellOne.click();
      await expect(yourBoardPage.cellOneWithShip).toBeVisible();
      await expect(yourBoardPage.readyButton).toBeEnabled();
    });

    await test.step('Click Ready button', async () => {
      await yourBoardPage.readyButton.click();

      await expect(commonBoardPage.playerBoard).toBeVisible();
      await expect(commonBoardPage.opponentBoard).toBeVisible();
      await expect(commonBoardPage.shootButton).toBeDisabled();
    });

    await test.step('Verify Your board', async () => {
      expect(await commonBoardPage.playerBoardTitle.textContent()).toContain(CoracleConstants.YOUR_BOARD_TITLE);
      for (let i = 0; i < playerBoardCells.length; i++) {
        await expect(playerBoardCells[i]).toBeVisible();
        await expect(playerBoardCells[i]).toHaveCSS('border', '3px solid rgb(0, 159, 183)');
      }
      console.log('Only one cell displays ship');
      await expect(commonBoardPage.playerBoardCellOneWithShip).toBeVisible();
      // 1-st cell with ship, starting count from the 2-nd cell
      for (let i = 1; i < playerBoardCellsWithShip.length; i++) {
        await expect(playerBoardCellsWithShip[i]).not.toBeVisible();
      }
    });

    await test.step('Verify Opponent`s board', async () => {
      expect(await commonBoardPage.opponentBoardTitle.textContent()).toContain(CoracleConstants.OPPONENT_BOARD_TITLE);
      for (let i = 0; i < opponentBoardCells.length; i++) {
        await expect(opponentBoardCells[i]).toBeVisible();
        await expect(opponentBoardCells[i]).toHaveCSS('border', '3px solid rgb(199, 44, 44)');
      }
      console.log('All cells are empty');
      for (let i = 0; i < opponentBoardCellsWithImage.length; i++) {
        await expect(opponentBoardCellsWithImage[i]).not.toBeVisible();
      }
    });
  });
});
