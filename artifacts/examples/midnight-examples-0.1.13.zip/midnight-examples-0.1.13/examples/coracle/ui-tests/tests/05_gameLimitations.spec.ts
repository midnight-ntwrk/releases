import { allure } from 'allure-playwright';
import test, { expect } from '../src/pageObjects/CoraclePageFixture';
import { Services } from '../src/setup/Services';

test.describe('Coracle dApp. E2E flows.', () => {
  test.setTimeout(60000);

  // https://input-output.atlassian.net/browse/PM-7191
  test('Only one ship can be placed on the board @PM-7191', async ({ initialPage, yourBoardPage }) => {
    allure.tms('PM-7191', `${Services.JIRA_URL}/PM-7191`);
    allure.epic('Coracle dApp');
    allure.feature('UI');
    allure.story('User story: E2E test for the UI of coracle dapp');

    const emptyCells = [
      yourBoardPage.cellOne,
      yourBoardPage.cellTwo,
      yourBoardPage.cellThree,
      yourBoardPage.cellFour,
      yourBoardPage.cellFive,
      yourBoardPage.cellSix,
      yourBoardPage.cellSeven,
      yourBoardPage.cellEight,
      yourBoardPage.cellNine,
    ];

    const cellsWithShip = [
      yourBoardPage.cellOneWithShip,
      yourBoardPage.cellTwoWithShip,
      yourBoardPage.cellThreeWithShip,
      yourBoardPage.cellFourWithShip,
      yourBoardPage.cellFiveWithShip,
      yourBoardPage.cellSixWithShip,
      yourBoardPage.cellSevenWithShip,
      yourBoardPage.cellEightWithShip,
      yourBoardPage.cellNineWithShip,
    ];

    await test.step('Create new game', async () => {
      await initialPage.goto();
      await initialPage.createNewGameButton.click();
      await initialPage.gameAddress.click();
    });

    await test.step('Click each cell one by one', async () => {
      for (let i = 0; i < emptyCells.length; i++) {
        await emptyCells[i].click();
        await expect(cellsWithShip[i]).toBeVisible();
        await expect(yourBoardPage.readyButton).toBeEnabled();

        for (let j = 0; j < cellsWithShip.length; j++) {
          if (j !== i) {
            await expect(cellsWithShip[j]).not.toBeVisible();
          }
        }
      }
    });
  });

  // https://input-output.atlassian.net/browse/PM-7192
  test('Only one cell can be selected for the shot @PM-7192', async ({ initialPage, yourBoardPage, commonBoardPage }) => {
    allure.tms('PM-7192', `${Services.JIRA_URL}/PM-7192`);
    allure.epic('Coracle dApp');
    allure.feature('UI');
    allure.story('User story: E2E test for the UI of coracle dapp');

    const opponentEmptyCells = [
      commonBoardPage.opponentBoardCellOne,
      commonBoardPage.opponentBoardCellTwo,
      commonBoardPage.opponentBoardCellThree,
      commonBoardPage.opponentBoardCellFour,
      commonBoardPage.opponentBoardCellFive,
      commonBoardPage.opponentBoardCellSix,
      commonBoardPage.opponentBoardCellSeven,
      commonBoardPage.opponentBoardCellEight,
      commonBoardPage.opponentBoardCellNine,
    ];

    const cellsWithCrosshair = [
      commonBoardPage.opponentBoardCellOneWithCrosshair,
      commonBoardPage.opponentBoardCellTwoWithCrosshair,
      commonBoardPage.opponentBoardCellThreeWithCrosshair,
      commonBoardPage.opponentBoardCellFourWithCrosshair,
      commonBoardPage.opponentBoardCellFiveWithCrosshair,
      commonBoardPage.opponentBoardCellSixWithCrosshair,
      commonBoardPage.opponentBoardCellSevenWithCrosshair,
      commonBoardPage.opponentBoardCellEightWithCrosshair,
      commonBoardPage.opponentBoardCellNineWithCrosshair,
    ];

    await test.step('Create new game', async () => {
      await initialPage.goto();
      await initialPage.createNewGameButton.click();
      await initialPage.gameAddress.click();
    });

    await test.step('Place ship', async () => {
      await yourBoardPage.cellOne.click();
      await yourBoardPage.readyButton.click();
      await expect(commonBoardPage.opponentBoard).toBeVisible();
    });

    await test.step('Opponent`s board: Click each cell one by one', async () => {
      for (let i = 0; i < opponentEmptyCells.length; i++) {
        await opponentEmptyCells[i].click();

        for (let j = 0; j < cellsWithCrosshair.length; j++) {
          if (j !== i) {
            await expect(cellsWithCrosshair[j]).not.toBeVisible();
          }
        }
      }
    });
  });

  // https://input-output.atlassian.net/browse/PM-7194
  test('Impossible to join the game using invalid address @PM-7194', async ({ initialPage, yourBoardPage, commonBoardPage }) => {
    allure.tms('PM-7194', `${Services.JIRA_URL}/PM-7194`);
    allure.epic('Coracle dApp');
    allure.feature('UI');
    allure.story('User story: E2E test for the UI of coracle dapp');

    await test.step('Create new game', async () => {
      // TBD
    });
  });

  // https://input-output.atlassian.net/browse/PM-7196
  // Will be updated
  test('Impossible to select already shoted cell @PM-7196', async ({ initialPage, yourBoardPage, commonBoardPage }) => {
    allure.tms('PM-7196', `${Services.JIRA_URL}/PM-7196`);
    allure.epic('Coracle dApp');
    allure.feature('UI');
    allure.story('User story: E2E test for the UI of coracle dapp');

    const opponentEmptyCells = [
      commonBoardPage.opponentBoardCellOne,
      commonBoardPage.opponentBoardCellTwo,
      commonBoardPage.opponentBoardCellThree,
      commonBoardPage.opponentBoardCellFour,
      commonBoardPage.opponentBoardCellFive,
      commonBoardPage.opponentBoardCellSix,
      commonBoardPage.opponentBoardCellSeven,
      commonBoardPage.opponentBoardCellEight,
      commonBoardPage.opponentBoardCellNine,
    ];

    const cellsWithCrosshair = [
      commonBoardPage.opponentBoardCellOneWithCrosshair,
      commonBoardPage.opponentBoardCellTwoWithCrosshair,
      commonBoardPage.opponentBoardCellThreeWithCrosshair,
      commonBoardPage.opponentBoardCellFourWithCrosshair,
      commonBoardPage.opponentBoardCellFiveWithCrosshair,
      commonBoardPage.opponentBoardCellSixWithCrosshair,
      commonBoardPage.opponentBoardCellSevenWithCrosshair,
      commonBoardPage.opponentBoardCellEightWithCrosshair,
      commonBoardPage.opponentBoardCellNineWithCrosshair,
    ];

    const opponentCellsWithCross = [
      commonBoardPage.opponentBoardCellOneWithCross,
      commonBoardPage.opponentBoardCellTwoWithCross,
      commonBoardPage.opponentBoardCellThreeWithCross,
      commonBoardPage.opponentBoardCellFourWithCross,
      commonBoardPage.opponentBoardCellFiveWithCross,
      commonBoardPage.opponentBoardCellSixWithCross,
      commonBoardPage.opponentBoardCellSevenWithCross,
      commonBoardPage.opponentBoardCellEightWithCross,
      commonBoardPage.opponentBoardCellNineWithCross,
    ];

    await test.step('Create new game', async () => {
      await initialPage.goto();
      await initialPage.createNewGameButton.click();
      await initialPage.gameAddress.click();
    });

    await test.step('Place ship', async () => {
      await yourBoardPage.cellOne.click();
      await yourBoardPage.readyButton.click();
      await expect(commonBoardPage.opponentBoard).toBeVisible();
    });

    await test.step('Opponent`s board: Shoot the same cell', async () => {
      for (let i = 0; i < opponentEmptyCells.length; i++) {
        await opponentEmptyCells[i].click();
        await expect(cellsWithCrosshair[i]).toBeVisible();
        await commonBoardPage.shootButton.click();
        await expect(opponentCellsWithCross[i]).toBeVisible();

        await opponentEmptyCells[i].click();
        await expect(cellsWithCrosshair[i]).not.toBeVisible();
        await expect(opponentCellsWithCross[i]).toBeVisible();
      }
    });
  });
});
