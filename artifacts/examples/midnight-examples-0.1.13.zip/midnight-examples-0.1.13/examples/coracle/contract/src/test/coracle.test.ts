import { describe, expect } from '@jest/globals';
import { decodeCoinInfo } from '@midnight-ntwrk/compact-runtime';
import { withZSwapState } from '@midnight-ntwrk/midnight-js-contracts';
import * as crypto from 'node:crypto';

import { Player, State } from '../managed/coracle/contract/index.cjs';
import {
  CoinAmount,
  coinInfo,
  ContractPrivateState,
  createContract,
  emptyArray,
  emptyBoard,
  emptyCoinInfo,
  SimpleWallet,
} from './coracle-test-setup.js';

const WAGER = CoinAmount.WAGER;
const DEPOSIT = CoinAmount.DEPOSIT;
const wager = coinInfo(WAGER);
const deposit = coinInfo(DEPOSIT);

describe('Coracle smart contract', () => {
  it('generates initial state deterministically', () => {
    const coinPublicKey: Uint8Array = crypto.getRandomValues(Buffer.alloc(32));
    const contract = createContract(coinPublicKey);
    const privateState = withZSwapState(ContractPrivateState.generate());

    const [privState1, contractState1] = contract.initialState(privateState);
    const [privState2, contractState2] = contract.initialState(privateState);

    expect(privState1).toBe(privState2);
    expect(contractState1.serialize()).toEqual(contractState2.serialize());
  });

  it('properly set initial values for game', () => {
    const wallet = new SimpleWallet();
    const initialState = wallet.getLedger();

    expect(initialState.guess.value).toEqual(0n);
    expect(initialState.state).toEqual(State.no_game);

    expect(initialState.red).toEqual(emptyArray);
    expect(initialState.redBoard).toEqual(emptyBoard);
    expect(initialState.redDeposit).toEqual(emptyCoinInfo);

    expect(initialState.blue).toEqual(emptyArray);
    expect(initialState.blueBoard).toEqual(emptyBoard);
    expect(initialState.blueDeposit).toEqual(emptyCoinInfo);

    expect(initialState.pot).toEqual(emptyCoinInfo);
  });

  it('Alice can deploy and run transition red_start', () => {
    const wallet = new SimpleWallet();

    const redPosition = 1n;
    const redStartResult = wallet.redMove().start(redPosition, wager, deposit);
    const redStartResultLedger = redStartResult[0];
    const redStartPlayer = redStartResult[1];
    expect(redStartResultLedger.state).toEqual(State.red_started);

    // red public key is set
    expect(redStartResultLedger.red).not.toEqual(emptyArray);
    // red board is filled, we have commitment on ledger
    expect(redStartResultLedger.redBoard).not.toEqual(emptyBoard);
    expect(redStartResultLedger.redDeposit.value).toEqual(deposit.value);
    expect(redStartResultLedger.pot.value).toEqual(wager.value);

    // blue has not joined
    expect(redStartResultLedger.blue).toEqual(emptyArray);
    expect(redStartResultLedger.blueBoard).toEqual(emptyBoard);
    expect(redStartResultLedger.blueDeposit).toEqual(emptyCoinInfo);

    expect(redStartResultLedger.guess.value).toEqual(0n);

    expect(redStartPlayer).toEqual(Player.red);

    const allCoins = wallet.redPrivateState.zswap.outputs.map((e) => e.coinInfo);
    expect(allCoins).toContainEqual(decodeCoinInfo(wager));
    expect(allCoins).toContainEqual(decodeCoinInfo(deposit));

    expect(wallet.redPrivateState.contract.localBoard.contents.position).toEqual(redPosition);
  });

  it('Alice attempt to cheat by guessing twice', () => {
    const wallet = new SimpleWallet();

    // Red moves - start
    const redPosition = 1n;
    const redStartResultLedger = wallet.redMove().start(redPosition, wager, deposit)[0];

    expect(redStartResultLedger.state).toEqual(State.red_started);

    const redStartPrivState = wallet.redPrivateState;
    expect(redStartPrivState.contract.localBoard.contents.position).toEqual(redPosition);

    // Blue moves - start and guess
    const bluePosition = 7n;
    const blueGuess = redPosition + 1n;
    const blueStartLedger = wallet.blueMove().start(bluePosition, wager, deposit);
    expect(blueStartLedger[1]).toEqual(Player.blue);

    const blueGuessLedger = wallet.blueMove().guess(blueGuess);

    expect(blueGuessLedger.state).toEqual(State.red_turn);

    // Red tries to guess twice
    const redGuess1 = bluePosition + 1n;
    const redGuessLedger = wallet.redMove().guess(redGuess1);
    expect(redGuessLedger.state).toEqual(State.blue_turn);

    const redGuess2 = bluePosition;
    expect(() => wallet.redMove().guess(redGuess2)).toThrow("Not Red's turn");
  });

  it('Bob attempt to cheat by guessing twice', () => {
    const wallet = new SimpleWallet();

    const redPosition = 1n;
    wallet.redMove().start(redPosition, wager, deposit);

    const bluePosition = 7n;
    const blueGuess = redPosition + 1n;
    wallet.blueMove().start(bluePosition, wager, deposit);
    wallet.blueMove().guess(blueGuess);

    wallet.blueMove();
    expect(() => wallet.guess(redPosition)).toThrow("Not Blue's turn");
  });

  it('Alice makes a move and Bob make a move and guess', () => {
    const wallet = new SimpleWallet();

    // Red moves - start
    const redPosition = 1n;
    const redStartResultLedger = wallet.redMove().start(redPosition, wager, deposit)[0];
    expect(redStartResultLedger.state).toEqual(State.red_started);

    const redStartPrivState = wallet.redPrivateState;
    expect(redStartPrivState.contract.localBoard.contents.position).toEqual(redPosition);

    // Blue moves - start and guess
    const bluePosition = 7n;
    const blueGuess = redPosition;
    const blueStartLedger = wallet.blueMove().start(bluePosition, wager, deposit)[0];
    const blueGuessLedger = wallet.blueMove().guess(blueGuess);

    expect(blueGuessLedger.state).toEqual(State.red_turn);
    expect(blueGuessLedger.guess.value).toEqual(redPosition);

    const blueStartPrivateState = wallet.bluePrivateState;
    expect(blueStartPrivateState.contract.localBoard.contents.position).toEqual(bluePosition);

    // Red moves - concade
    const [redConcadeLedger, coin] = wallet.redMove().concede();
    expect(coin.value).toEqual(deposit.value);
    expect(redConcadeLedger.state).toEqual(State.blue_wins);

    // Blue moves - withdraw
    const withdrawnCoins = wallet.blueMove().withdraw()[1];
    expect(withdrawnCoins.deposit.value).toEqual(deposit.value);
    expect(withdrawnCoins.wager.value).toEqual(blueStartLedger.pot.value);
  });

  it('Alice makes a move and Bob make a move and then Alice guess', () => {
    const wallet = new SimpleWallet();

    // Red moves - start
    const redPosition = 1n;
    const redStartResultLedger = wallet.redMove().start(redPosition, wager, deposit)[0];
    expect(redStartResultLedger.state).toEqual(State.red_started);

    const redStartPrivState = wallet.redPrivateState;
    expect(redStartPrivState.contract.localBoard.contents.position).toEqual(redPosition);

    // Blue moves - start and miss
    const bluePosition = 7n;
    const blueGuess = redPosition + 1n;
    const blueStartLedger = wallet.blueMove().start(bluePosition, wager, deposit)[0];
    const blueGuessLedger = wallet.blueMove().guess(blueGuess);

    expect(blueGuessLedger.state).toEqual(State.red_turn);
    expect(blueGuessLedger.guess.value).toEqual(blueGuess);

    const blueStartPrivateState = wallet.bluePrivateState;
    expect(blueStartPrivateState.contract.localBoard.contents.position).toEqual(bluePosition);

    // Red moves - guess
    const redGuessLedger = wallet.redMove().guess(bluePosition);
    expect(redGuessLedger.state).toEqual(State.blue_turn);

    // Blue moves - concade
    const [blueConcadeLedger, coin] = wallet.blueMove().concede();
    expect(coin.value).toEqual(deposit.value);
    expect(blueConcadeLedger.state).toEqual(State.red_wins);

    // Red moves - withdraw
    const withdrawnCoins = wallet.redMove().withdraw()[1];
    expect(withdrawnCoins.deposit.value).toEqual(deposit.value);
    expect(withdrawnCoins.wager.value).toEqual(blueStartLedger.pot.value);
  });

  it.skip('Alice should not be able to start wrong contract setup - same coin for wager and deposit', () => {
    const wallet = new SimpleWallet();

    const redPosition = 1n;

    expect(() => wallet.redMove().start(redPosition, deposit, deposit)).toThrow('Red invalid deposit');
    const redStartResultLedger = wallet.start(redPosition, wager, deposit)[0];
    expect(redStartResultLedger.state).toEqual(State.red_started);
  });

  const cheatingScenario = [
    // can we have more readable error
    // {
    //   name: 'negative wager',
    //   wager: -1n,
    // },
    {
      name: '0 wager',
      wager: 0n,
    },
    {
      name: 'small wager',
      wager: 1n,
    },
  ];

  describe.each(cheatingScenario)(`Alice should not be able to start wrong contract setup`, (scenario) => {
    it.skip(`wager with ${scenario.name} should be failing`, () => {
      const wallet = new SimpleWallet();

      const redPosition = 1n;
      expect(() => wallet.redMove().start(redPosition, coinInfo(scenario.wager), deposit)).toThrow('Red invalid deposit');
      wallet.redMove().start(redPosition, wager, deposit);
    });
  });

  it.skip('Bob should not be able to cheat - same coin in wager and deposit', () => {
    const wallet = new SimpleWallet();

    const redPosition = 1n;
    wallet.redMove().start(redPosition, wager, deposit);

    const bluePosition = 7n;
    const blueGuess = redPosition + 1n;
    expect(() => wallet.blueMove().start(bluePosition, deposit, deposit)).toThrow('Blue, cannot start');

    wallet.blueMove().start(bluePosition, wager, deposit);
    wallet.blueMove().guess(blueGuess);
  });

  describe.each(cheatingScenario)(`Bob should not be able to cheat`, (scenario) => {
    it(`wager with ${scenario.name} should be failing`, () => {
      const wallet = new SimpleWallet();

      const redPosition = 1n;
      wallet.redMove().start(redPosition, wager, deposit);

      const bluePosition = 7n;
      const blueGuess = redPosition + 1n;

      expect(() => wallet.blueMove().start(bluePosition, coinInfo(scenario.wager), deposit)).toThrow(
        'Blue must match Reds wager',
      );

      wallet.blueMove().start(bluePosition, wager, deposit);
      wallet.blueMove().guess(blueGuess);
    });
  });

  it('Bob should set the same wager value as Alice', () => {
    const wallet = new SimpleWallet();

    const redPosition = 1n;
    wallet.redMove().start(redPosition, wager, deposit);

    const bluePosition = 7n;
    const blueGuess = redPosition + 1n;
    expect(() => wallet.blueMove().start(bluePosition, coinInfo(550_000n), deposit)).toThrow('Blue must match Reds wager');

    wallet.blueMove().start(bluePosition, wager, deposit);
    wallet.blueMove().guess(blueGuess);
  });

  it('Bob should set the same deposit value as Alice', () => {
    const wallet = new SimpleWallet();

    const redPosition = 1n;
    wallet.redMove().start(redPosition, wager, deposit);

    const bluePosition = 7n;
    const blueGuess = redPosition + 1n;
    expect(() => wallet.blueMove().start(bluePosition, wager, coinInfo(200_000n))).toThrow('Invalid deposit');

    wallet.blueMove().start(bluePosition, wager, deposit);
    wallet.blueMove().guess(blueGuess);
  });

  it('Alice places position outside board', () => {
    const wallet = new SimpleWallet();

    expect(() => wallet.redMove().start(10n, wager, deposit)).toThrow('Initial board is not valid');
    wallet.redMove().start(9n, wager, deposit);
  });

  it('Bob places position outside board', () => {
    const wallet = new SimpleWallet();

    const redPosition = 1n;
    wallet.redMove().start(redPosition, wager, deposit);

    const blueGuess = redPosition;
    expect(() => wallet.blueMove().start(10n, wager, deposit)).toThrow('Initial board is not valid');

    wallet.blueMove().start(9n, wager, deposit);
    wallet.blueMove().guess(blueGuess);
  });

  it('Bob guess position outside board', () => {
    const wallet = new SimpleWallet();

    const redPosition = 1n;
    wallet.redMove().start(redPosition, wager, deposit);

    const blueGuess = 10n;
    wallet.blueMove();

    wallet.blueMove().start(7n, wager, deposit);
    expect(() => wallet.blueMove().guess(blueGuess)).toThrow('Blue guess is not a valid position');
    wallet.blueMove().guess(2n);
  });

  it('Alice guess position outside board in 2nd move', () => {
    const wallet = new SimpleWallet();

    const redPosition = 1n;
    wallet.redMove().start(redPosition, wager, deposit);

    const blueGuess = redPosition + 1n;
    wallet.blueMove().start(7n, wager, deposit);
    wallet.blueMove().guess(blueGuess);

    expect(() => wallet.redMove().guess(10n)).toThrow('Red guess is not a valid position');
    wallet.redMove().guess(9n);
  });

  it('Bob guess position outside board in 2nd move', () => {
    const wallet = new SimpleWallet();

    const redPosition = 1n;
    wallet.redMove().start(redPosition, wager, deposit);

    const blueGuess = redPosition + 1n;
    wallet.blueMove().start(7n, wager, deposit);
    wallet.blueMove().guess(blueGuess);

    wallet.redMove().guess(5n);
    expect(() => wallet.blueMove().guess(10n)).toThrow('Blue guess is not a valid position');
    wallet.blueMove().guess(9n);
  });

  it('Alice invalid transitions', () => {
    const wallet = new SimpleWallet();

    const redPosition = 1n;
    wallet.redMove().start(redPosition, wager, deposit);

    const blueGuess = redPosition + 1n;
    wallet.blueMove().start(7n, wager, deposit);
    wallet.blueMove().guess(blueGuess);

    expect(() => wallet.redMove().concede()).toThrow('Red player is still alive');
    expect(() => wallet.redMove().withdraw()).toThrow("Red hasn't won");
  });

  it('Bob invalid transitions', () => {
    const wallet = new SimpleWallet();

    const redPosition = 1n;
    wallet.redMove().start(redPosition, wager, deposit);

    const blueGuess = redPosition + 1n;
    wallet.blueMove().start(7n, wager, deposit);
    wallet.blueMove().guess(blueGuess);
    wallet.redMove().guess(5n);
    expect(() => wallet.blueMove().concede()).toThrow('Blue player is still alive');
    expect(() => wallet.blueMove().withdraw()).toThrow("Blue hasn't won");
  });

  it('Alice tries to start 3 times', () => {
    const wallet = new SimpleWallet();
    const firstPlayer = wallet.redMove().start(1n, wager, deposit)[1];
    expect(firstPlayer).toEqual(Player.red);

    const secondPlayer = wallet.redMove().start(2n, wager, deposit)[1];
    expect(secondPlayer).toEqual(Player.blue);
    expect(() => wallet.redMove().start(2n, wager, deposit)).toThrow('The game already has two players');
  });

  it('Bob tries to start twice', () => {
    const wallet = new SimpleWallet();

    const redPosition = 1n;
    wallet.redMove().start(redPosition, wager, deposit);

    const bluePosition = 7n;
    const blueGuess = redPosition + 1n;
    wallet.blueMove().start(bluePosition, wager, deposit);
    wallet.blueMove().guess(blueGuess);

    expect(() => wallet.blueMove().start(bluePosition, wager, deposit)).toThrow('The game already has two players');
  });

  it('Bob can start but is considered first player Red', () => {
    const wallet = new SimpleWallet();

    const bluePosition = 7n;
    wallet.redMove().start(bluePosition, wager, deposit);
  });

  it('Alice cannot guess if she already lost', () => {
    const wallet = new SimpleWallet();

    const redPosition = 1n;
    wallet.redMove().start(redPosition, wager, deposit);

    const bluePosition = 7n;
    const blueGuess = redPosition;
    wallet.blueMove().start(bluePosition, wager, deposit);
    wallet.blueMove().guess(blueGuess);

    expect(() => wallet.redMove().guess(2n)).toThrow('Red player is not alive');
  });

  it('Bob cannot guess if he already lost', () => {
    const wallet = new SimpleWallet();

    const redPosition = 1n;
    wallet.redMove().start(redPosition, wager, deposit);

    const bluePosition = 7n;
    const blueGuess = redPosition + 1n;
    wallet.blueMove().start(bluePosition, wager, deposit);
    wallet.blueMove().guess(blueGuess);

    wallet.redMove().guess(bluePosition);

    expect(() => wallet.blueMove().guess(redPosition + 2n)).toThrow('Blue player is not alive');
  });

  it('Alice can be Blue, Bob can be Red', () => {
    const wallet = new SimpleWallet();

    // Red moves - start
    const redPosition = 1n;
    const redStartResultLedger = wallet.blueMove().start(redPosition, wager, deposit)[0]; // now Blue player is considred red
    expect(redStartResultLedger.state).toEqual(State.red_started);

    const redStartPrivState = wallet.bluePrivateState;
    expect(redStartPrivState.contract.localBoard.contents.position).toEqual(redPosition);

    // Blue moves - start and guess
    const bluePosition = 7n;
    const blueGuess = redPosition + 1n;
    wallet.redMove().start(bluePosition, wager, deposit); // Red player is considered blue
    const blueStartLedge = wallet.redMove().guess(blueGuess);
    expect(blueStartLedge.state).toEqual(State.red_turn);

    wallet.blueMove().guess(2n);
    wallet.redMove().guess(2n);
  });
});
