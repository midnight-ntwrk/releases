/* eslint-disable @typescript-eslint/restrict-template-expressions */
import { jest } from '@jest/globals';

jest.setTimeout(180_000);
