import type { WitnessContext } from '@midnight-ntwrk/compact-runtime';
import type { Board, Committable, Ledger } from './managed/coracle/contract/index.cjs';

export type CoraclePrivateState = {
  readonly secretKey: Uint8Array;
  readonly board: Committable<Board>;
};

export const createCoraclePrivateState = (randomBigUint: () => bigint) => (secretKey: Uint8Array) => ({
  secretKey,
  board: { nonce: randomBigUint(), contents: { position: 0n } },
});

export const witnesses = (randomBigUint: () => bigint) => ({
  local_secret_key: ({ privateState }: WitnessContext<Ledger, CoraclePrivateState>): [CoraclePrivateState, Uint8Array] => [
    privateState,
    privateState.secretKey,
  ],
  local_board: ({ privateState }: WitnessContext<Ledger, CoraclePrivateState>): [CoraclePrivateState, Committable<Board>] => [
    privateState,
    privateState.board,
  ],
  local_set_board: (
    { privateState }: WitnessContext<Ledger, CoraclePrivateState>,
    board: Committable<Board>,
  ): [CoraclePrivateState, void] => [{ ...privateState, board }, undefined],
  fresh_nonce: ({ privateState }: WitnessContext<Ledger, CoraclePrivateState>): [CoraclePrivateState, bigint] => [
    privateState,
    randomBigUint(),
  ],
});
