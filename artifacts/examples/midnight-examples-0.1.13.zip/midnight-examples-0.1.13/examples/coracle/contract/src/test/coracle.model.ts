/* eslint-disable @typescript-eslint/restrict-template-expressions */
import { Logger } from 'tslog';
import { assign, createMachine } from 'xstate';

const log = new Logger({ name: 'coracle_model', minLevel: 3 });

// @ts-expect-error a quick way to get bigint serialize to JSON
// eslint-disable-next-line no-extend-native
BigInt.prototype.toJSON = function () {
  return this.toString();
};

export interface GameContext {
  scenario: string;
  roundNumber: number;
  red_position: bigint;
  blue_position: bigint;
  red_guess: bigint[];
  blue_guess: bigint[];
}

export type GameEvent =
  | { type: 'RED_START' }
  | { type: 'BLUE_START' }
  | { type: 'BLUE_GUESS' }
  | { type: 'RED_GUESS' }
  | { type: 'RED_CONCEDE' }
  | { type: 'RED_CLAIM' }
  | { type: 'RED_ANALYZE' }
  | { type: 'BLUE_CONCEDE' }
  | { type: 'BLUE_CLAIM' }
  | { type: 'BLUE_ANALYZE' };

const getRandomPosition = (): bigint => {
  return 1n + BigInt(Math.floor(Math.random() * 9));
};

const blueGuessed = (c: GameContext, event: GameEvent): boolean => {
  const res = c.blue_guess.slice(0, c.roundNumber).includes(c.red_position);
  log.debug(`Blue guesses: [${c.blue_guess.slice(0, c.roundNumber)}] - ${c.red_position} - ${event.type}  - ${res}`);
  return res;
};

const redGuessed = (c: GameContext, event: GameEvent): boolean => {
  const res = c.red_guess.slice(0, c.roundNumber).includes(c.blue_position);
  log.debug(`Red guesses: [${c.red_guess.slice(0, c.roundNumber)}] - ${c.red_position} - ${event.type} - ${res}`);
  return res;
};

const generateSteps = (destination: bigint): bigint[] => {
  const arr: bigint[] = [];
  while (!arr.includes(destination)) {
    arr.push(getRandomPosition());
  }
  log.debug(`${arr} : ${destination}`);
  return arr;
};

export const getInitialContext = (): GameContext => {
  return {
    scenario: 'Initial',
    roundNumber: 1,
    red_position: 1n,
    blue_position: 9n,
    red_guess: [9n],
    blue_guess: [2n],
  };
};

export const getRandomContext = (): GameContext => {
  const red = getRandomPosition();
  const blue = getRandomPosition();
  return {
    scenario: 'Random',
    roundNumber: 1,
    red_position: red,
    blue_position: blue,
    red_guess: generateSteps(blue),
    blue_guess: generateSteps(red),
  };
};

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
export const getTestMachine = () =>
  /** @xstate-layout N4IgpgJg5mDOIC5QGED2AnAhgYwDZgDoA7VAfSkwFswBiAJQFEARUgZQBUBBO9gbQAYAuolAAHVLACWAF0moiIkAA9EAZgDsATgIAOVQEYALPtUAmQ4Y1n1AGhABPRPoCszgqfWqdlvQDYNluoAvkF2aFh4hOiQpLDSmOjSkDQAQgAyAKoMbFw8pJwAciwA4lmsrALCSCDiUrLyiioIrvwE-s6mOqbd6vya+vp2jgim+trOeqq+vQO+riFhGDj4BNEQpNIAruhE9Mz5BZxpAJoAWgyVirUycgrVTZqq2h6qhpqmztO+pqpDagYEfq+Xz8dQ6d78XyGHQLEDhZZRGJbHZ7FiFI5nC76KpiCQ3Br3RCPZ6eN4fL4-P4jfSmNrAqH8QzOJn8ZzBUJwpaRAgAI1wmzAG22u3SWQOGPOl2q13qd1ATX0YJ0BH0-H4qmc-FMvi60N8VI1BEM3VVatmr3Bvlh8O5fIFQpRouy6JOkuxVzxssaTi86gI-CMhn86mNnzmBrcxtGaoD+n8b301q5KztgoA7pIiLBUplssg0pwAJIAWSluLqt291O6KsMoP6mt8itMBoBQJBYIhUJhHJtKzWpAzWdRpHzRdLQg9FYJ8sQH3UblZ6q66mBOi+EaNJpj5rJSYiKf5guw6HsObFyAA8gVkMwLpPpZ7K4SRh5DFum5o2R0dM5fg41EjbczTjV5+n3BFVhiE8z0YFgrxvO8yxqJ8Z2UJw5l8AgNU0Y1V30LpGX-YZVDbOMO3BUxIWhCDuQoahSCIMAlGkUh0FQTYiAgc9slKBhymQmVn1nBAdEZOkAx0KSvy0EMqRpSNXEMdQximCjNFo-skQAC0zABrbM4NIPiBIfct8TldCEBMENsKmfgdBmVcdUMKlRlpekGSZFk2RCDkSAgOBFD7MApwsqtVD6dw-1MfofihEMdCpABabx3DML9oV-DRNH8TTCBIcgqFCx9p0spoNT9D4MppKZlOhA0sONANNFw9QPk0RzE17ZNEXWOIEiSCAwq9F8vFpGkV36UjvihZw3LGAgJgy2beg+Qx8qg9ZkUsoS0KaLpVF0ZxcLMSwnmsBbxkmaZYzmZxNtTB1dtQ8qnCk5UjAXONNDVN5vAWo7yJUgZWpMP8Np6g9CCeod4FK8KXzGKLOqZAZPm1fx9QAhBSNpYxgVBSjqJ7RZoa2wdM3h8zRpE8wTv9DQCPBRl10sTco0VUEMbm0xHqPUgYJG4SrNGJ5ATeOswRBcwWxxw1Od6BdZqZPmocggchYR2mrKMCZsOUhcdGbZT5vlswjXIomuxo9W6OKxjmNY9jOOG7WRYOtU2i-EEm1cKZfwNdxbqhcHmxDZlNoHaRdKIAzhf2pwfmVL8zr1kxoTN4YxZVYEQbGaa-02+jBTALjqZQsqqw8KKxOZb4Oh6P95Kk46LBOzwHLqtWQiAA */
  createMachine(
    {
      // eslint-disable-next-line @typescript-eslint/consistent-type-assertions, @typescript-eslint/consistent-type-imports
      tsTypes: {} as import('./coracle.model.typegen.js').Typegen0,
      id: 'Coracle',
      initial: 'no_game',
      preserveActionOrder: true,
      predictableActionArguments: true,
      states: {
        no_game: {
          entry: ['newGame'],
          on: {
            RED_START: {
              target: 'red_started',
            },
          },
        },

        red_started: {
          on: {
            BLUE_START: {
              target: 'blue_turn',
            },
          },
        },

        red_turn: {
          on: {
            RED_ANALYZE: [
              {
                target: 'red_cry',
                cond: 'blueGuessed',
              },
              {
                target: 'red_thinks',
              },
            ],
          },
        },

        blue_turn: {
          on: {
            BLUE_ANALYZE: [
              {
                target: 'blue_cry',
                cond: 'redGuessed',
              },
              {
                target: 'game_next_round',
              },
            ],
          },
        },

        blue_wins: {
          on: {
            BLUE_CLAIM: 'game_ends',
          },
        },

        red_wins: {
          on: {
            RED_CLAIM: 'game_ends',
          },
        },

        blue_cry: {
          on: {
            BLUE_CONCEDE: 'red_wins',
          },
        },

        red_cry: {
          on: {
            RED_CONCEDE: {
              target: 'blue_wins',
            },
          },
        },

        game_next_round: {
          entry: 'nextRound',

          on: {
            BLUE_GUESS: 'red_turn',
          },
        },

        red_thinks: {
          on: {
            RED_GUESS: 'blue_turn',
          },
        },

        game_ends: {
          type: 'final',
        },
      },
      context: getInitialContext(),
      schema: {
        context: {} as GameContext, // eslint-disable-line @typescript-eslint/consistent-type-assertions
        events: {} as GameEvent, // eslint-disable-line @typescript-eslint/consistent-type-assertions
      },
    },
    {
      guards: {
        redGuessed: (context: GameContext, event: GameEvent) => redGuessed(context, event),
        blueGuessed: (context: GameContext, event: GameEvent) => blueGuessed(context, event),
      },
      actions: {
        nextRound: assign((context: GameContext) => ({
          roundNumber: context.roundNumber + 1,
        })),
        newGame: assign(() => ({
          roundNumber: 1,
        })),
      },
    },
  );
/* eslint-enable */
