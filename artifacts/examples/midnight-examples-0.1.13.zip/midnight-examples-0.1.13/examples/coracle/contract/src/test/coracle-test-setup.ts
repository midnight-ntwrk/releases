/* eslint-disable @typescript-eslint/no-non-null-assertion */
import { jest } from '@jest/globals';

import {
  type CircuitContext,
  type CircuitResults,
  QueryContext,
  sampleContractAddress,
  type WitnessContext,
} from '@midnight-ntwrk/compact-runtime';
import {
  type NonZSwapWitnesses,
  type StateWithZswap,
  withZSwapState,
  withZswapWitnesses,
} from '@midnight-ntwrk/midnight-js-contracts';
import * as crypto from 'node:crypto';
import {
  type Board,
  type CoinInfo,
  type Commitment,
  type Committable,
  Contract,
  ledger,
  type Ledger,
  type Player,
  type QualifiedCoinInfo,
  type WithdrawnCoins,
  type Witnesses,
} from '../managed/coracle/contract/index.cjs';

jest.setTimeout(180_000);

export function coinInfo(value: bigint): CoinInfo {
  return {
    nonce: crypto.randomBytes(32),
    color: new Uint8Array(32).fill(0),
    value,
  };
}

export const CoinAmount = {
  DEPOSIT: 100_000n,
  WAGER: 500_000n,
} as const;

export function newSecretKey32(user: string): Buffer {
  const sk = `${user}'s secret key`;
  return Buffer.alloc(32, 0, 'utf8').fill(sk, 0, sk.length);
}

export function newRandomBigInt(): bigint {
  return BigInt(crypto.randomInt(1000));
}

export function randomAddress(): string {
  return crypto.randomBytes(32).toString('hex');
}

function localSecretKey(context: WitnessContext<Ledger, ContractPrivateState>): [ContractPrivateState, Uint8Array] {
  const secretKey = context.privateState.secretKey;
  return [context.privateState, secretKey];
}

function localBoard(context: WitnessContext<Ledger, ContractPrivateState>): [ContractPrivateState, Committable<Board>] {
  return [context.privateState, context.privateState.localBoard];
}

function localSetBoard(
  context: WitnessContext<Ledger, ContractPrivateState>,
  board: Committable<Board>,
): [ContractPrivateState, void] {
  return [context.privateState.withLocalBoard(board), undefined];
}

function freshNonce(context: WitnessContext<Ledger, ContractPrivateState>): [ContractPrivateState, bigint] {
  return [context.privateState, newRandomBigInt()];
}

export const userWitnesses = (): NonZSwapWitnesses<Witnesses<ContractPrivateState>> => {
  return {
    local_secret_key: localSecretKey,
    local_board: localBoard,
    local_set_board: localSetBoard,
    fresh_nonce: freshNonce,
  };
};

const witnesses = (coinPublicKey: Uint8Array) => withZswapWitnesses(userWitnesses())(coinPublicKey);

export const emptyArray = new Uint8Array(32);

export const emptyCoinInfo: QualifiedCoinInfo = {
  nonce: emptyArray,
  color: emptyArray,
  value: BigInt(0),
  mt_index: BigInt(0),
};

export const emptyBoard: Commitment = { value: 0n };

export interface LocalBoard {
  nonce: bigint;
  contents: {
    position: bigint;
  };
}

const DefaultLocalBoard: LocalBoard = {
  nonce: newRandomBigInt(),
  contents: {
    position: 0n,
  },
};

export class ContractPrivateState {
  constructor(
    public readonly coinAddress: Buffer,
    public readonly secretKey: Uint8Array,
    public readonly localBoard: Committable<Board>,
  ) {}

  static fromKey(secretKey: Uint8Array): ContractPrivateState {
    const coinAddress = crypto.getRandomValues(Buffer.alloc(32));
    return new ContractPrivateState(coinAddress, secretKey, DefaultLocalBoard);
  }

  static generate(): ContractPrivateState {
    const secretKey: Uint8Array = crypto.getRandomValues(Buffer.alloc(32));
    const coinAddress = crypto.getRandomValues(Buffer.alloc(32));

    return new ContractPrivateState(coinAddress, secretKey, DefaultLocalBoard);
  }

  withLocalBoard(board: Committable<Board>): ContractPrivateState {
    return new ContractPrivateState(this.coinAddress, this.secretKey, board);
  }
}

type PrivateState = StateWithZswap<ContractPrivateState>;

export const createContract = (coinPublicKey: Uint8Array) => new Contract<PrivateState>(witnesses(coinPublicKey));

export interface PlayerBoard {
  value: bigint;
}

export class SimpleWallet {
  readonly contract: Contract<PrivateState, Witnesses<PrivateState>>;
  redPrivateState: PrivateState;
  bluePrivateState: PrivateState;
  contractState: CircuitContext<unknown>;

  // chose player to move
  // for testing valid scenarios we can properly chose private state / contract state without this
  // but to allow testing malicious users behaviour we separate:
  // - chosing player and
  // - what move will be done
  // so players can attempt to cheat
  moveContext: CircuitContext<PrivateState>;

  updateMovePlayerState: (newPrivateState: PrivateState) => void;

  updateRedPrivateState = (newPrivateState: PrivateState): void => {
    this.redPrivateState = newPrivateState;
  };

  updateBluePrivateState = (newPrivateState: PrivateState): void => {
    this.bluePrivateState = newPrivateState;
  };

  redMove(): SimpleWallet {
    this.moveContext = this.buildMoveContext(this.redPrivateState);
    this.updateMovePlayerState = this.updateRedPrivateState;
    return this;
  }

  blueMove(): SimpleWallet {
    this.moveContext = this.buildMoveContext(this.bluePrivateState);
    this.updateMovePlayerState = this.updateBluePrivateState;
    return this;
  }

  private buildMoveContext(privState: PrivateState): CircuitContext<PrivateState> {
    return {
      ...this.contractState,
      currentPrivateState: privState,
    };
  }

  constructor() {
    const coinPublicKey: Uint8Array = crypto.getRandomValues(Buffer.alloc(32));

    this.contract = createContract(coinPublicKey);

    this.redPrivateState = withZSwapState(ContractPrivateState.generate());
    this.bluePrivateState = withZSwapState(ContractPrivateState.generate());

    const initialState = this.contract.initialState(this.bluePrivateState);
    this.contractState = {
      currentPrivateState: undefined,
      originalState: initialState[1],
      transactionContext: new QueryContext(initialState[1].data, sampleContractAddress()),
    };

    // assume next state will be red
    this.moveContext = this.buildMoveContext(this.redPrivateState);
    this.updateMovePlayerState = this.updateRedPrivateState;
  }

  getLedger(): Ledger {
    return ledger(this.contractState.transactionContext.state);
  }

  private updateStateAndGetLedger<T>(circuitResults: CircuitResults<PrivateState, T>): Ledger {
    this.contractState = circuitResults.context;
    this.updateMovePlayerState(circuitResults.context.currentPrivateState);

    return this.getLedger();
  }

  // transitions functions

  start(pos: bigint, wager: CoinInfo, deposit: CoinInfo): [Ledger, Player] {
    const circuitResults = this.contract.impureCircuits.start(this.moveContext, pos, wager, deposit);
    const ledger = this.updateStateAndGetLedger(circuitResults);
    return [ledger, circuitResults.result];
  }

  guess(myGuess: bigint): Ledger {
    const circuitResults = this.contract.impureCircuits.guess(this.moveContext, myGuess);
    return this.updateStateAndGetLedger(circuitResults);
  }

  concede(): [Ledger, CoinInfo] {
    const circuitResults = this.contract.impureCircuits.concede(this.moveContext);
    const ledger = this.updateStateAndGetLedger(circuitResults);
    return [ledger, circuitResults.result];
  }

  withdraw(): [Ledger, WithdrawnCoins] {
    const circuitResults = this.contract.impureCircuits.withdraw(this.moveContext);
    const ledger = this.updateStateAndGetLedger(circuitResults);
    return [ledger, circuitResults.result];
  }
}

export class PlayerBuilder {
  private _position?: bigint;
  private _wager?: bigint;
  private _deposit?: bigint;

  public static factory(): PlayerBuilder {
    return new PlayerBuilder();
  }

  position(position: bigint): this {
    this._position = position;
    return this;
  }

  wager(value: bigint): this {
    this._wager = value;
    return this;
  }

  deposit(value: bigint): this {
    this._deposit = value;
    return this;
  }

  build(): { position: bigint; wager: CoinInfo; deposit: CoinInfo } {
    return {
      position: this._position!,
      wager: coinInfo(this._wager!),
      deposit: coinInfo(this._deposit!),
    };
  }
}
