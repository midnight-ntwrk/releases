// This file was automatically generated. Edits will be overwritten

export interface Typegen0 {
  '@@xstate/typegen': true;
  internalEvents: {
    'xstate.init': { type: 'xstate.init' };
  };
  // eslint-disable-next-line @typescript-eslint/ban-types
  invokeSrcNameMap: {};
  missingImplementations: {
    actions: never;
    delays: never;
    guards: never;
    services: never;
  };
  eventsCausingActions: {
    newGame: 'xstate.init';
    nextRound: 'BLUE_ANALYZE';
  };
  // eslint-disable-next-line @typescript-eslint/ban-types
  eventsCausingDelays: {};
  eventsCausingGuards: {
    blueGuessed: 'RED_ANALYZE';
    redGuessed: 'BLUE_ANALYZE';
  };
  // eslint-disable-next-line @typescript-eslint/ban-types
  eventsCausingServices: {};
  matchesStates:
    | 'blue_cry'
    | 'blue_turn'
    | 'blue_wins'
    | 'game_ends'
    | 'game_next_round'
    | 'no_game'
    | 'red_cry'
    | 'red_started'
    | 'red_thinks'
    | 'red_turn'
    | 'red_wins';
  tags: never;
}
