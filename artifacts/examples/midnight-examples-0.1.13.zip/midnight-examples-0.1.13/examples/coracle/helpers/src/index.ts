import { ValidationError, Errors, Context } from 'io-ts';
import { function as function_ } from 'fp-ts';

export { pipe as through } from 'rxjs';
export * from './types.js';
export * from './bloc.js';
export * from './functions.js';
export * from './resource.js';
export * from './logging.js';
export * from './lens.js';
export const pipe = function_.pipe;

export class DecodingError extends Error {
  constructor(err: Errors) {
    const message = err.map((validationErr) => this.buildValidationErrorMessage(validationErr)).join('\n');

    super(message);
  }

  buildValidationErrorMessage(validationError: ValidationError): string {
    const message = validationError.message !== undefined ? `Due to: ${validationError.message}` : '';
    return `${JSON.stringify(validationError.value)} is not acceptable. ${message}. At
      ${this.stringifyContext(validationError.context)}`;
  }

  stringifyContext(context: Context): string {
    return context
      .map((entry) => `${entry.type.name} at key: ${entry.key} with value: ${JSON.stringify(entry.actual)}`)
      .join('\n');
  }
}
