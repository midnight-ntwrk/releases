/**
 * A functional getter + setter abstraction.
 * Despite deceptively simple API it is quite powerful in kinds
 * of relationships it allows to represent
 * @typeParam S the parent type
 * @typeParam F the focus type we want to access from the parent
 */
export abstract class Lens<S, F> {
  abstract get: (state: S) => F;
  abstract set: (state: S, focus: F) => S;
  update = (state: S, updater: (f: F) => F): S => {
    return this.set(state, updater(this.get(state)));
  };

  /**
   * A lens for a field in an object.
   * @typeParam S Object type, from which field is being focused on
   * @param key A key of the field to focus on
   */
  static field = <S, K extends keyof S>(key: K): Lens<S, S[K]> =>
    new (class extends Lens<S, S[K]> {
      get = (state: S) => state[key];
      set = (state: S, newValue: S[K]) => ({ ...state, [key]: newValue });
    })();
}
