export interface Config {
  readonly organizerUrl: string;
  readonly participantUrl: string;
  readonly contractAddress: string;
  readonly publicKey: string;
  readonly nodeAddress: string;
  readonly indexerAddress: string;
  readonly proofServerAddress: string;
  readonly addedParticipant: string;
}

export class DevnetConfig implements Config {
  organizerUrl = 'https://devnet.d2krd8xqgzb1iv.amplifyapp.com';
  participantUrl = 'https://devnet.d295z856imkdg9.amplifyapp.com';

  contractAddress = '010001074b9b1776f311c300dbdcb14504f16041c4e77dfac5dc11693526d3414dc63d';
  publicKey = 'b7ac5642ff74123d3dc5fccb2c2943e3afee4c759759a79b111ac4f146317b66';

  nodeAddress = 'https://rpc.devnet.midnight.network';
  indexerAddress = 'https://indexer.devnet.midnight.network/api/v1/graphql';
  proofServerAddress = 'http://localhost:6300';

  addedParticipant = 'devnetParticipant';
}

export class AriadneQaConfig implements Config {
  organizerUrl = 'https://ariadneqa.d31t4v4v6uh1gw.amplifyapp.com';
  participantUrl = 'https://ariadneqa.dvklv0k7mgnd4.amplifyapp.com';

  contractAddress = '010001336ea17a4dfd8b440c59f1830050cb740eed7e6ad1afef0ffa5ae77fc2f54d57';
  publicKey = 'c6d84635c55986c31cc1e6bb952f2f22821fa772e08785c702ae1ae0b0190b12';

  nodeAddress = 'https://rpc.ariadne-qa.dev.midnight.network';
  indexerAddress = 'https://indexer.ariadne-qa.dev.midnight.network/api/v1/graphql';
  proofServerAddress = 'http://localhost:6300';

  addedParticipant = 'ariadneQaParticipant';
}

export function getConfig(): Config {
  let config: Config;
  let env = '';
  if (process.env.TEST_ENV !== undefined) {
    env = process.env.TEST_ENV;
  } else {
    throw new Error('TEST_ENV environment variable is not defined.');
  }
  switch (env) {
    case 'devnet':
      config = new DevnetConfig();
      break;
    case 'ariadne-qa':
      config = new AriadneQaConfig();
      break;
    default:
      throw new Error(`Unknown env value=${env}`);
  }
  return config;
}
