# INTERNAL

## Requirements

Node.js - LTS/hydrogen

Or

`nix` - version >= 2.5

We use the `nix` development shell which includes needed components:

- `node` - `lts/hydrogen`
- `yarn` - version is defined in the file `package.json` entry `packageManager`, yarn present in the nix devshell is able to use the version present in the repository
- `turbo` - added to PATH from node_modules, so that sometimes it's easier to use

## Configuration

The internal repository configuration differs from the external one

```yml
npmRegistries:
  "https://npm.pkg.github.com":
    npmAuthToken: <GITHUB_TOKEN>
```

The `compact` package in this repository is used to fetch and provide Compact compiler.
It requires a `GITHUB_TOKEN` environment variable to be present while running commands
like `yarn build` to be able to fetch the compiler.

## Compact compiler

It is being fetched and prepared to be used within packages through `compact` package.
It is a thin wrapper, which does 2 things:
- fetches and unpacks Compact compiler in its build step (so that adding
  it as a dev dependency in workspaces lets turbo ensure the compiler is present)
- provides a bin script, so that workspaces can use the compiler
  like `run-compactc <source> <destination>` in their scripts

For that reason - it's generally advised to run e.g. `npx turbo build` as a first
step or run `yarn build` in `compact` directory before working with contracts.

The version of Compactc is defined through `version` field of `compact` package.json file.

Alternatively - if `COMPACT_HOME` env variable is set - compiler present at directory
pointed by this variable will be used.

## Devshell using nix

To enter a development shell use following command:

```sh
nix develop
```

It offers the basic environment for running the project

### Direnv

This repository defines `.envrc` file, which can be used with [direnv](https://direnv.net/).

This environment file allows for 2 things:
- setup environment variables from `.env` file (if such exists)
- load nix devshell

You can also use editor support for direnv:

- [VSCode direnv plugin](https://github.com/direnv/direnv-vscode)
- [(Neo)Vim direnv plugin](https://github.com/direnv/direnv.vim)
- [Emacs direnv plugin](https://github.com/wbolster/emacs-direnv)

This repository is a monorepo/multi-package repository, which contains some example
dapps in `examples/**` directories. While sharing configuration, etc. is
meant to be minimal between packages, so that it is easy to publish them when needed,
managing competing versions of e.g. Midnight stack is way easier with top-level install, and the top-level `package.json`
file defines most of important dependencies for all workspaces

This repository uses turborepo for managing tasks, their dependencies and caching.

