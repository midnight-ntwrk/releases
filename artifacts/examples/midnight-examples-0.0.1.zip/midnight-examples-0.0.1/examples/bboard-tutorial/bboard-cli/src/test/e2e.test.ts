import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';
import { createLogger } from '../logger-utils.js';
import { currentDir } from '../config.js';
import { parseArgs, type TestConfig } from './commons.js';

const FILE_NAME = fileURLToPath(import.meta.url);
const DIR_NAME = path.dirname(FILE_NAME);

const logDir = path.resolve(currentDir, '..', 'logs', 'tests', `${new Date().toISOString()}.log`);
const logger = await createLogger(logDir);

let testConfig: TestConfig;

describe('E2E BBoard CLI', () => {
  if (process.env.RUN_ENV_TESTS !== undefined) {
    beforeAll(() => {
      testConfig = parseArgs(['seed', 'entry']);
      logger.info(`Test environment: ${testConfig.entrypoint}`);
      logger.info(`Test wallet seed: ${testConfig.seed}`);
    });

    it('should deploy the contract and interact', async () => {
      const steps = [
        {
          input: 'Build wallet from a seed',
          answer: '2',
          condition: (nextInput: string) => {
            return nextInput.includes('Enter your wallet seed');
          },
        },
        {
          input: 'Enter your wallet seed',
          answer: testConfig.seed,
          condition: (nextInput: string) => {
            return nextInput.includes('Your wallet balance is');
          },
        },
        {
          input: 'Deploy a new bulletin board contract',
          answer: '1',
          condition: (nextInput: string) => {
            return nextInput.includes('Deployed contract at address');
          },
        },
        {
          input: 'Display the current ledger state',
          answer: '3',
          condition: (nextInput: string) => {
            return nextInput.includes("Current message is: 'none'");
          },
        },
        {
          input: 'Post a message',
          answer: '1',
          condition: (nextInput: string) => {
            return nextInput.includes('');
          },
        },
        {
          input: 'What message do you want to post?',
          answer: 'TESTNOTE!',
          condition: (nextInput: string) => {
            return nextInput.includes('Posting your message');
          },
        },
        {
          input: 'Display the current private state (known only to this DApp instance)',
          answer: '4',
          condition: (nextInput: string) => {
            return nextInput.includes('Current secret key is');
          },
        },
        {
          input: 'Display the current ledger state',
          answer: '3',
          condition: (nextInput: string) => {
            return nextInput.includes("Current message is: 'TESTNOTE!'");
          },
        },
        {
          input: 'Take down your message',
          answer: '2',
          condition: (nextInput: string) => {
            return nextInput.includes('Taking down your last posted message');
          },
        },
        {
          input: 'Display the current ledger state',
          answer: '3',
          condition: (nextInput: string) => {
            return nextInput.includes("Current message is: 'none'");
          },
        },
        {
          input: 'Exit',
          answer: '5',
        },
      ];

      let progressCondition: ((input: string) => boolean) | undefined;

      const cliProcess = spawn(
        'npx',
        ['ts-node', '--esm', '--experimental-specifier-resolution=node', testConfig.entrypoint],
        {
          cwd: DIR_NAME,
          stdio: ['pipe', 'pipe', 'pipe'],
        },
      );

      const promise = new Promise<void>((resolve: (value: PromiseLike<void> | void) => void) => {
        let step = steps.shift();
        cliProcess?.stdout?.on('data', (data: Buffer) => {
          logger.info(`STEP[Wait for input='${step?.input}', to answer='${step?.answer}']`);
          const output = data.toString();
          logger.info(`[CONSOLE] ${output}`);
          expect(output).not.toContain('ERROR');
          if (progressCondition !== undefined && progressCondition(output)) {
            step = steps.shift();
            progressCondition = undefined;
          }
          if (steps.length === 0) {
            resolve();
          }
          if (step !== undefined && output.includes(step.input)) {
            if (step.answer !== undefined) {
              logger.info(`Thinking and typing... ${step?.answer}`);
              setTimeout(() => {
                cliProcess?.stdin?.write(`${step?.answer}\n`);
              }, 5000);
            }
            progressCondition = step.condition;
          }
        });
        cliProcess?.stderr?.on('data', (err: string) => {
          resolve(Promise.reject(err.toString()));
        });
        cliProcess?.on('error', (err: string) => {
          resolve(Promise.reject(err.toString()));
        });
        cliProcess?.on('exit', (code: number) => {
          expect(code).toBe(0);
          cliProcess?.kill('SIGKILL');
          resolve();
        });
      });
      await expect(promise).resolves.toBeUndefined();
    });
  } else {
    it('dummy test to make Jest runner happy', () => {});
  }
});
