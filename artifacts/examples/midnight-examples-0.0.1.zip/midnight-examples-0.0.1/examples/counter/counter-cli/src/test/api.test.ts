import { parseArgs, type TestConfig } from './commons';
import path from 'path';
import { currentDir } from '../config';
import { createLogger } from '../logger-utils';
import { DockerComposeEnvironment, type StartedDockerComposeEnvironment, Wait } from 'testcontainers';
import * as api from '../api';
import * as Rx from 'rxjs';
import { nativeToken } from '@midnight-ntwrk/ledger';
import { type Wallet } from '@midnight-ntwrk/wallet-api';
import { type Resource } from '@midnight-ntwrk/wallet';
import { type CounterProviders } from '../common-types';

const logDir = path.resolve(currentDir, '..', 'logs', 'tests', `${new Date().toISOString()}.log`);
const logger = await createLogger(logDir);

let env: StartedDockerComposeEnvironment;
let dockerEnv: DockerComposeEnvironment;

let testConfig: TestConfig;
let wallet: Wallet & Resource;
let providers: CounterProviders;

describe('API', () => {
  if (process.env.RUN_ENV_TESTS !== undefined) {
    beforeAll(async () => {
      testConfig = parseArgs(['seed', 'env']);
      logger.info(`Test wallet seed: ${testConfig.seed}`);
      testConfig.dappConfig?.setNetworkId();
      api.setLogger(logger);
      logger.info('Proof server starting...');
      dockerEnv = new DockerComposeEnvironment(path.resolve(currentDir, '..'), 'proof-server.yml').withWaitStrategy(
        'proof-server',
        Wait.forLogMessage('Actix runtime found; starting in Actix runtime', 1),
      );
      env = await dockerEnv.up();
      logger.info('Proof server started');
      logger.info('Setting up wallet');
      wallet = await api.buildWalletAndWaitForFunds(testConfig.dappConfig, testConfig.seed);
      expect(wallet).not.toBeNull();
      const state = await Rx.firstValueFrom(wallet.state());
      expect(state.balances[nativeToken()].valueOf()).toBeGreaterThan(BigInt(0));
      providers = await api.configureProviders(wallet, testConfig.dappConfig);
    });

    afterAll(async () => {
      if (env !== undefined) {
        logger.info('Proof server closing');
        await env.down();
      }
    });

    it('should deploy the contract and increment the counter', async () => {
      const counterContract = await api.deploy(providers);
      expect(counterContract).not.toBeNull();

      const counter = await api.displayCounterValue(providers, counterContract);
      expect(counter.counterValue).toEqual(BigInt(0));

      const response = await api.increment(counterContract);
      expect(response.txHash).toMatch(/[0-9a-f]{64}/);
      expect(response.blockHeight).toBeGreaterThan(BigInt(0));

      const counterAfter = await api.displayCounterValue(providers, counterContract);
      expect(counterAfter.counterValue).toEqual(BigInt(1));
      expect(counterAfter.contractAddress).toEqual(counter.contractAddress);
    });
  } else {
    it('dummy test to make Jest runner happy', () => {});
  }
});
