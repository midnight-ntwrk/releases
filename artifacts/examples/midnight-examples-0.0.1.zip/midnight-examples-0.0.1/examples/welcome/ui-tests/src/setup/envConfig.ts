export interface Config {
  readonly organizerUrl: string;
  readonly participantUrl: string;
  readonly contractAddress: string;
  readonly publicKey: string;
  readonly nodeAddress: string;
  readonly indexerAddress: string;
  readonly proofServerAddress: string;
  readonly addedParticipant: string;
}

export class DevnetConfig implements Config {
  organizerUrl = 'https://devnet.d5tw3udmsvdim.amplifyapp.com';
  participantUrl = 'https://devnet.dzdrx2kur0wyc.amplifyapp.com';

  contractAddress = '010001d4bcb99f2f8a193240d4f13a8f1e7e3f39423dd2625df9f46260f67e32d0ea2b';
  publicKey = '3bf7bc3a3f39f6de02a8b10a0381b8183314726dcaca0923240eb223e14f4846';

  nodeAddress = 'https://rpc.devnet.midnight.network';
  indexerAddress = 'https://indexer.devnet.midnight.network/api/v1/graphql';
  proofServerAddress = 'http://localhost:6300';

  addedParticipant = 'devnetParticipant';
}

export class AriadneQaConfig implements Config {
  organizerUrl = 'https://ariadneqa.d1eb1bt9k8pfgu.amplifyapp.com';
  participantUrl = 'https://ariadneqa.duuj2ex044zdp.amplifyapp.com';

  contractAddress = '010001d52996ea2164b5681ae8f9c53a3f26043748bd096a211ac9829483bba24d1c37';
  publicKey = '172377cddf85a1fe18cdc606206b9175894af8acef2ed9ca93b1003f4017ef33';

  nodeAddress = 'http://node-01.topaz.dev.platform.midnight.network:9944';
  indexerAddress = 'https://pubsub.topaz.dev.platform.midnight.network/api/v1/graphql';
  proofServerAddress = 'http://localhost:6300';

  addedParticipant = 'ariadneQaParticipant';
}

export function getConfig(): Config {
  let config: Config;
  let env = '';
  if (process.env.TEST_ENV !== undefined) {
    env = process.env.TEST_ENV;
  } else {
    throw new Error('TEST_ENV environment variable is not defined.');
  }
  switch (env) {
    case 'devnet':
      config = new DevnetConfig();
      break;
    case 'ariadne-qa':
      config = new AriadneQaConfig();
      break;
    default:
      throw new Error(`Unknown env value=${env}`);
  }
  return config;
}
